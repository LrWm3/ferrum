(get-info :version)
; (:version "4.16.0")
; Started: 2026-10-30 15:00:43
; Silicon.version: 1.1-SNAPSHOT (6b540aa4@(detached))
; Input file: /tmp/ferrum-saturation-experiment/inputs/mut_element_nested_pass.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :model.partial true)
(set-option :smt.qi.max_multi_patterns 1000)
(set-option :smt.qi.eager_threshold 1000)
(set-option :model.partial false)
(set-option :smt.arith.solver 6)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-const $Snap.null $Snap) ; hack
(declare-fun internalCondFrame (Bool $Snap $Snap) $Snap)
(assert (forall ((cnd Bool) (frst $Snap) (scnd $Snap)) (!
    (= (internalCondFrame cnd frst scnd) (ite cnd frst scnd))
    :pattern ((internalCondFrame cnd frst scnd)))))
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(declare-fun $Perm.min ($Perm $Perm) $Perm)
(assert (forall ((p1 $Perm) (p2 $Perm)) (!
    (= ($Perm.min p1 p2) (ite (<= p1 p2) p1 p2))
    :pattern (($Perm.min p1 p2)))))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Int> 0)
(declare-sort Seq<s_ResourceState> 0)
(declare-sort Seq<s_Param> 0)
(declare-sort Set<$Ref> 0)
(declare-sort Set<s_Param> 0)
(declare-sort Set<s_UInt_usize> 0)
(declare-sort Set<s_UInt_u32> 0)
(declare-sort Set<Bool> 0)
(declare-sort Set<$Snap> 0)
(declare-sort ParamTyp_make_generic_s_UInt_usize 0)
(declare-sort s_Ref_immutable 0)
(declare-sort Type 0)
(declare-sort trait_std$col$$col$ptr$col$$col$Pointee 0)
(declare-sort trait_std$col$$col$marker$col$$col$MetaSized 0)
(declare-sort sizedness_visit$col$$col$$lc$closure$oc$1$rc$ 0)
(declare-sort s_Slice 0)
(declare-sort Inhabited 0)
(declare-sort ParamTyp_make_generic_s_Ref_mutable 0)
(declare-sort s_UInt_u32 0)
(declare-sort sizedness_0_Tuple 0)
(declare-sort ParamTyp_make_generic_s_UInt_u32 0)
(declare-sort s_UInt_usize 0)
(declare-sort ParamTyp_make_generic_s_0_Tuple 0)
(declare-sort ParamTyp 0)
(declare-sort ParamTyp_make_generic_s_Slice 0)
(declare-sort sizedness_UInt_u32 0)
(declare-sort sizedness_UInt_usize 0)
(declare-sort s_ResourceState 0)
(declare-sort s_visit$col$$col$$lc$closure$oc$1$rc$ 0)
(declare-sort ReadPerm 0)
(declare-sort sizedness_Slice 0)
(declare-sort sizedness_RawPtr_immutable 0)
(declare-sort s_RawPtr_immutable 0)
(declare-sort sizedness_Ref_immutable 0)
(declare-sort trait_std$col$$col$marker$col$$col$Sized 0)
(declare-sort s_Ref_mutable 0)
(declare-sort ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$ 0)
(declare-sort s_Param 0)
(declare-sort ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$ 0)
(declare-sort s_0_Tuple 0)
(declare-sort s_visit$col$$col$$lc$closure$oc$0$rc$ 0)
(declare-sort sizedness_Ref_mutable 0)
(declare-sort sizedness_Bool 0)
(declare-sort sizedness_visit$col$$col$$lc$closure$oc$0$rc$ 0)
(declare-sort $PSF<indexed_p_Param> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
(declare-fun $SortWrappers.Seq<s_ResourceState>To$Snap (Seq<s_ResourceState>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<s_ResourceState> ($Snap) Seq<s_ResourceState>)
(assert (forall ((x Seq<s_ResourceState>)) (!
    (= x ($SortWrappers.$SnapToSeq<s_ResourceState>($SortWrappers.Seq<s_ResourceState>To$Snap x)))
    :pattern (($SortWrappers.Seq<s_ResourceState>To$Snap x))
    :qid |$Snap.$SnapToSeq<s_ResourceState>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<s_ResourceState>To$Snap($SortWrappers.$SnapToSeq<s_ResourceState> x)))
    :pattern (($SortWrappers.$SnapToSeq<s_ResourceState> x))
    :qid |$Snap.Seq<s_ResourceState>To$SnapToSeq<s_ResourceState>|
    )))
(declare-fun $SortWrappers.Seq<s_Param>To$Snap (Seq<s_Param>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<s_Param> ($Snap) Seq<s_Param>)
(assert (forall ((x Seq<s_Param>)) (!
    (= x ($SortWrappers.$SnapToSeq<s_Param>($SortWrappers.Seq<s_Param>To$Snap x)))
    :pattern (($SortWrappers.Seq<s_Param>To$Snap x))
    :qid |$Snap.$SnapToSeq<s_Param>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<s_Param>To$Snap($SortWrappers.$SnapToSeq<s_Param> x)))
    :pattern (($SortWrappers.$SnapToSeq<s_Param> x))
    :qid |$Snap.Seq<s_Param>To$SnapToSeq<s_Param>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Set<$Ref>To$Snap (Set<$Ref>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Ref> ($Snap) Set<$Ref>)
(assert (forall ((x Set<$Ref>)) (!
    (= x ($SortWrappers.$SnapToSet<$Ref>($SortWrappers.Set<$Ref>To$Snap x)))
    :pattern (($SortWrappers.Set<$Ref>To$Snap x))
    :qid |$Snap.$SnapToSet<$Ref>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Ref>To$Snap($SortWrappers.$SnapToSet<$Ref> x)))
    :pattern (($SortWrappers.$SnapToSet<$Ref> x))
    :qid |$Snap.Set<$Ref>To$SnapToSet<$Ref>|
    )))
(declare-fun $SortWrappers.Set<s_Param>To$Snap (Set<s_Param>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<s_Param> ($Snap) Set<s_Param>)
(assert (forall ((x Set<s_Param>)) (!
    (= x ($SortWrappers.$SnapToSet<s_Param>($SortWrappers.Set<s_Param>To$Snap x)))
    :pattern (($SortWrappers.Set<s_Param>To$Snap x))
    :qid |$Snap.$SnapToSet<s_Param>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<s_Param>To$Snap($SortWrappers.$SnapToSet<s_Param> x)))
    :pattern (($SortWrappers.$SnapToSet<s_Param> x))
    :qid |$Snap.Set<s_Param>To$SnapToSet<s_Param>|
    )))
(declare-fun $SortWrappers.Set<s_UInt_usize>To$Snap (Set<s_UInt_usize>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<s_UInt_usize> ($Snap) Set<s_UInt_usize>)
(assert (forall ((x Set<s_UInt_usize>)) (!
    (= x ($SortWrappers.$SnapToSet<s_UInt_usize>($SortWrappers.Set<s_UInt_usize>To$Snap x)))
    :pattern (($SortWrappers.Set<s_UInt_usize>To$Snap x))
    :qid |$Snap.$SnapToSet<s_UInt_usize>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<s_UInt_usize>To$Snap($SortWrappers.$SnapToSet<s_UInt_usize> x)))
    :pattern (($SortWrappers.$SnapToSet<s_UInt_usize> x))
    :qid |$Snap.Set<s_UInt_usize>To$SnapToSet<s_UInt_usize>|
    )))
(declare-fun $SortWrappers.Set<s_UInt_u32>To$Snap (Set<s_UInt_u32>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<s_UInt_u32> ($Snap) Set<s_UInt_u32>)
(assert (forall ((x Set<s_UInt_u32>)) (!
    (= x ($SortWrappers.$SnapToSet<s_UInt_u32>($SortWrappers.Set<s_UInt_u32>To$Snap x)))
    :pattern (($SortWrappers.Set<s_UInt_u32>To$Snap x))
    :qid |$Snap.$SnapToSet<s_UInt_u32>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<s_UInt_u32>To$Snap($SortWrappers.$SnapToSet<s_UInt_u32> x)))
    :pattern (($SortWrappers.$SnapToSet<s_UInt_u32> x))
    :qid |$Snap.Set<s_UInt_u32>To$SnapToSet<s_UInt_u32>|
    )))
(declare-fun $SortWrappers.Set<Bool>To$Snap (Set<Bool>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Bool> ($Snap) Set<Bool>)
(assert (forall ((x Set<Bool>)) (!
    (= x ($SortWrappers.$SnapToSet<Bool>($SortWrappers.Set<Bool>To$Snap x)))
    :pattern (($SortWrappers.Set<Bool>To$Snap x))
    :qid |$Snap.$SnapToSet<Bool>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Bool>To$Snap($SortWrappers.$SnapToSet<Bool> x)))
    :pattern (($SortWrappers.$SnapToSet<Bool> x))
    :qid |$Snap.Set<Bool>To$SnapToSet<Bool>|
    )))
(declare-fun $SortWrappers.Set<$Snap>To$Snap (Set<$Snap>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Snap> ($Snap) Set<$Snap>)
(assert (forall ((x Set<$Snap>)) (!
    (= x ($SortWrappers.$SnapToSet<$Snap>($SortWrappers.Set<$Snap>To$Snap x)))
    :pattern (($SortWrappers.Set<$Snap>To$Snap x))
    :qid |$Snap.$SnapToSet<$Snap>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Snap>To$Snap($SortWrappers.$SnapToSet<$Snap> x)))
    :pattern (($SortWrappers.$SnapToSet<$Snap> x))
    :qid |$Snap.Set<$Snap>To$SnapToSet<$Snap>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.ParamTyp_make_generic_s_UInt_usizeTo$Snap (ParamTyp_make_generic_s_UInt_usize) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_UInt_usize ($Snap) ParamTyp_make_generic_s_UInt_usize)
(assert (forall ((x ParamTyp_make_generic_s_UInt_usize)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_usize($SortWrappers.ParamTyp_make_generic_s_UInt_usizeTo$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_UInt_usizeTo$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_UInt_usizeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_UInt_usizeTo$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_usize x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_usize x))
    :qid |$Snap.ParamTyp_make_generic_s_UInt_usizeTo$SnapToParamTyp_make_generic_s_UInt_usize|
    )))
(declare-fun $SortWrappers.s_Ref_immutableTo$Snap (s_Ref_immutable) $Snap)
(declare-fun $SortWrappers.$SnapTos_Ref_immutable ($Snap) s_Ref_immutable)
(assert (forall ((x s_Ref_immutable)) (!
    (= x ($SortWrappers.$SnapTos_Ref_immutable($SortWrappers.s_Ref_immutableTo$Snap x)))
    :pattern (($SortWrappers.s_Ref_immutableTo$Snap x))
    :qid |$Snap.$SnapTos_Ref_immutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_Ref_immutableTo$Snap($SortWrappers.$SnapTos_Ref_immutable x)))
    :pattern (($SortWrappers.$SnapTos_Ref_immutable x))
    :qid |$Snap.s_Ref_immutableTo$SnapTos_Ref_immutable|
    )))
(declare-fun $SortWrappers.TypeTo$Snap (Type) $Snap)
(declare-fun $SortWrappers.$SnapToType ($Snap) Type)
(assert (forall ((x Type)) (!
    (= x ($SortWrappers.$SnapToType($SortWrappers.TypeTo$Snap x)))
    :pattern (($SortWrappers.TypeTo$Snap x))
    :qid |$Snap.$SnapToTypeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.TypeTo$Snap($SortWrappers.$SnapToType x)))
    :pattern (($SortWrappers.$SnapToType x))
    :qid |$Snap.TypeTo$SnapToType|
    )))
(declare-fun $SortWrappers.trait_std$col$$col$ptr$col$$col$PointeeTo$Snap (trait_std$col$$col$ptr$col$$col$Pointee) $Snap)
(declare-fun $SortWrappers.$SnapTotrait_std$col$$col$ptr$col$$col$Pointee ($Snap) trait_std$col$$col$ptr$col$$col$Pointee)
(assert (forall ((x trait_std$col$$col$ptr$col$$col$Pointee)) (!
    (= x ($SortWrappers.$SnapTotrait_std$col$$col$ptr$col$$col$Pointee($SortWrappers.trait_std$col$$col$ptr$col$$col$PointeeTo$Snap x)))
    :pattern (($SortWrappers.trait_std$col$$col$ptr$col$$col$PointeeTo$Snap x))
    :qid |$Snap.$SnapTotrait_std$col$$col$ptr$col$$col$PointeeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.trait_std$col$$col$ptr$col$$col$PointeeTo$Snap($SortWrappers.$SnapTotrait_std$col$$col$ptr$col$$col$Pointee x)))
    :pattern (($SortWrappers.$SnapTotrait_std$col$$col$ptr$col$$col$Pointee x))
    :qid |$Snap.trait_std$col$$col$ptr$col$$col$PointeeTo$SnapTotrait_std$col$$col$ptr$col$$col$Pointee|
    )))
(declare-fun $SortWrappers.trait_std$col$$col$marker$col$$col$MetaSizedTo$Snap (trait_std$col$$col$marker$col$$col$MetaSized) $Snap)
(declare-fun $SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$MetaSized ($Snap) trait_std$col$$col$marker$col$$col$MetaSized)
(assert (forall ((x trait_std$col$$col$marker$col$$col$MetaSized)) (!
    (= x ($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$MetaSized($SortWrappers.trait_std$col$$col$marker$col$$col$MetaSizedTo$Snap x)))
    :pattern (($SortWrappers.trait_std$col$$col$marker$col$$col$MetaSizedTo$Snap x))
    :qid |$Snap.$SnapTotrait_std$col$$col$marker$col$$col$MetaSizedTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.trait_std$col$$col$marker$col$$col$MetaSizedTo$Snap($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$MetaSized x)))
    :pattern (($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$MetaSized x))
    :qid |$Snap.trait_std$col$$col$marker$col$$col$MetaSizedTo$SnapTotrait_std$col$$col$marker$col$$col$MetaSized|
    )))
(declare-fun $SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$1$rc$To$Snap (sizedness_visit$col$$col$$lc$closure$oc$1$rc$) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$ ($Snap) sizedness_visit$col$$col$$lc$closure$oc$1$rc$)
(assert (forall ((x sizedness_visit$col$$col$$lc$closure$oc$1$rc$)) (!
    (= x ($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x)))
    :pattern (($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x))
    :qid |$Snap.$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$1$rc$To$Snap($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$ x)))
    :pattern (($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$ x))
    :qid |$Snap.sizedness_visit$col$$col$$lc$closure$oc$1$rc$To$SnapTosizedness_visit$col$$col$$lc$closure$oc$1$rc$|
    )))
(declare-fun $SortWrappers.s_SliceTo$Snap (s_Slice) $Snap)
(declare-fun $SortWrappers.$SnapTos_Slice ($Snap) s_Slice)
(assert (forall ((x s_Slice)) (!
    (= x ($SortWrappers.$SnapTos_Slice($SortWrappers.s_SliceTo$Snap x)))
    :pattern (($SortWrappers.s_SliceTo$Snap x))
    :qid |$Snap.$SnapTos_SliceTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_SliceTo$Snap($SortWrappers.$SnapTos_Slice x)))
    :pattern (($SortWrappers.$SnapTos_Slice x))
    :qid |$Snap.s_SliceTo$SnapTos_Slice|
    )))
(declare-fun $SortWrappers.InhabitedTo$Snap (Inhabited) $Snap)
(declare-fun $SortWrappers.$SnapToInhabited ($Snap) Inhabited)
(assert (forall ((x Inhabited)) (!
    (= x ($SortWrappers.$SnapToInhabited($SortWrappers.InhabitedTo$Snap x)))
    :pattern (($SortWrappers.InhabitedTo$Snap x))
    :qid |$Snap.$SnapToInhabitedTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.InhabitedTo$Snap($SortWrappers.$SnapToInhabited x)))
    :pattern (($SortWrappers.$SnapToInhabited x))
    :qid |$Snap.InhabitedTo$SnapToInhabited|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_Ref_mutableTo$Snap (ParamTyp_make_generic_s_Ref_mutable) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_Ref_mutable ($Snap) ParamTyp_make_generic_s_Ref_mutable)
(assert (forall ((x ParamTyp_make_generic_s_Ref_mutable)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_Ref_mutable($SortWrappers.ParamTyp_make_generic_s_Ref_mutableTo$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_Ref_mutableTo$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_Ref_mutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_Ref_mutableTo$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_Ref_mutable x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_Ref_mutable x))
    :qid |$Snap.ParamTyp_make_generic_s_Ref_mutableTo$SnapToParamTyp_make_generic_s_Ref_mutable|
    )))
(declare-fun $SortWrappers.s_UInt_u32To$Snap (s_UInt_u32) $Snap)
(declare-fun $SortWrappers.$SnapTos_UInt_u32 ($Snap) s_UInt_u32)
(assert (forall ((x s_UInt_u32)) (!
    (= x ($SortWrappers.$SnapTos_UInt_u32($SortWrappers.s_UInt_u32To$Snap x)))
    :pattern (($SortWrappers.s_UInt_u32To$Snap x))
    :qid |$Snap.$SnapTos_UInt_u32To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_UInt_u32To$Snap($SortWrappers.$SnapTos_UInt_u32 x)))
    :pattern (($SortWrappers.$SnapTos_UInt_u32 x))
    :qid |$Snap.s_UInt_u32To$SnapTos_UInt_u32|
    )))
(declare-fun $SortWrappers.sizedness_0_TupleTo$Snap (sizedness_0_Tuple) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_0_Tuple ($Snap) sizedness_0_Tuple)
(assert (forall ((x sizedness_0_Tuple)) (!
    (= x ($SortWrappers.$SnapTosizedness_0_Tuple($SortWrappers.sizedness_0_TupleTo$Snap x)))
    :pattern (($SortWrappers.sizedness_0_TupleTo$Snap x))
    :qid |$Snap.$SnapTosizedness_0_TupleTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_0_TupleTo$Snap($SortWrappers.$SnapTosizedness_0_Tuple x)))
    :pattern (($SortWrappers.$SnapTosizedness_0_Tuple x))
    :qid |$Snap.sizedness_0_TupleTo$SnapTosizedness_0_Tuple|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_UInt_u32To$Snap (ParamTyp_make_generic_s_UInt_u32) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_UInt_u32 ($Snap) ParamTyp_make_generic_s_UInt_u32)
(assert (forall ((x ParamTyp_make_generic_s_UInt_u32)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_u32($SortWrappers.ParamTyp_make_generic_s_UInt_u32To$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_UInt_u32To$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_UInt_u32To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_UInt_u32To$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_u32 x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_UInt_u32 x))
    :qid |$Snap.ParamTyp_make_generic_s_UInt_u32To$SnapToParamTyp_make_generic_s_UInt_u32|
    )))
(declare-fun $SortWrappers.s_UInt_usizeTo$Snap (s_UInt_usize) $Snap)
(declare-fun $SortWrappers.$SnapTos_UInt_usize ($Snap) s_UInt_usize)
(assert (forall ((x s_UInt_usize)) (!
    (= x ($SortWrappers.$SnapTos_UInt_usize($SortWrappers.s_UInt_usizeTo$Snap x)))
    :pattern (($SortWrappers.s_UInt_usizeTo$Snap x))
    :qid |$Snap.$SnapTos_UInt_usizeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_UInt_usizeTo$Snap($SortWrappers.$SnapTos_UInt_usize x)))
    :pattern (($SortWrappers.$SnapTos_UInt_usize x))
    :qid |$Snap.s_UInt_usizeTo$SnapTos_UInt_usize|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_0_TupleTo$Snap (ParamTyp_make_generic_s_0_Tuple) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_0_Tuple ($Snap) ParamTyp_make_generic_s_0_Tuple)
(assert (forall ((x ParamTyp_make_generic_s_0_Tuple)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_0_Tuple($SortWrappers.ParamTyp_make_generic_s_0_TupleTo$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_0_TupleTo$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_0_TupleTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_0_TupleTo$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_0_Tuple x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_0_Tuple x))
    :qid |$Snap.ParamTyp_make_generic_s_0_TupleTo$SnapToParamTyp_make_generic_s_0_Tuple|
    )))
(declare-fun $SortWrappers.ParamTypTo$Snap (ParamTyp) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp ($Snap) ParamTyp)
(assert (forall ((x ParamTyp)) (!
    (= x ($SortWrappers.$SnapToParamTyp($SortWrappers.ParamTypTo$Snap x)))
    :pattern (($SortWrappers.ParamTypTo$Snap x))
    :qid |$Snap.$SnapToParamTypTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTypTo$Snap($SortWrappers.$SnapToParamTyp x)))
    :pattern (($SortWrappers.$SnapToParamTyp x))
    :qid |$Snap.ParamTypTo$SnapToParamTyp|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_SliceTo$Snap (ParamTyp_make_generic_s_Slice) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_Slice ($Snap) ParamTyp_make_generic_s_Slice)
(assert (forall ((x ParamTyp_make_generic_s_Slice)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_Slice($SortWrappers.ParamTyp_make_generic_s_SliceTo$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_SliceTo$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_SliceTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_SliceTo$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_Slice x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_Slice x))
    :qid |$Snap.ParamTyp_make_generic_s_SliceTo$SnapToParamTyp_make_generic_s_Slice|
    )))
(declare-fun $SortWrappers.sizedness_UInt_u32To$Snap (sizedness_UInt_u32) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_UInt_u32 ($Snap) sizedness_UInt_u32)
(assert (forall ((x sizedness_UInt_u32)) (!
    (= x ($SortWrappers.$SnapTosizedness_UInt_u32($SortWrappers.sizedness_UInt_u32To$Snap x)))
    :pattern (($SortWrappers.sizedness_UInt_u32To$Snap x))
    :qid |$Snap.$SnapTosizedness_UInt_u32To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_UInt_u32To$Snap($SortWrappers.$SnapTosizedness_UInt_u32 x)))
    :pattern (($SortWrappers.$SnapTosizedness_UInt_u32 x))
    :qid |$Snap.sizedness_UInt_u32To$SnapTosizedness_UInt_u32|
    )))
(declare-fun $SortWrappers.sizedness_UInt_usizeTo$Snap (sizedness_UInt_usize) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_UInt_usize ($Snap) sizedness_UInt_usize)
(assert (forall ((x sizedness_UInt_usize)) (!
    (= x ($SortWrappers.$SnapTosizedness_UInt_usize($SortWrappers.sizedness_UInt_usizeTo$Snap x)))
    :pattern (($SortWrappers.sizedness_UInt_usizeTo$Snap x))
    :qid |$Snap.$SnapTosizedness_UInt_usizeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_UInt_usizeTo$Snap($SortWrappers.$SnapTosizedness_UInt_usize x)))
    :pattern (($SortWrappers.$SnapTosizedness_UInt_usize x))
    :qid |$Snap.sizedness_UInt_usizeTo$SnapTosizedness_UInt_usize|
    )))
(declare-fun $SortWrappers.s_ResourceStateTo$Snap (s_ResourceState) $Snap)
(declare-fun $SortWrappers.$SnapTos_ResourceState ($Snap) s_ResourceState)
(assert (forall ((x s_ResourceState)) (!
    (= x ($SortWrappers.$SnapTos_ResourceState($SortWrappers.s_ResourceStateTo$Snap x)))
    :pattern (($SortWrappers.s_ResourceStateTo$Snap x))
    :qid |$Snap.$SnapTos_ResourceStateTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_ResourceStateTo$Snap($SortWrappers.$SnapTos_ResourceState x)))
    :pattern (($SortWrappers.$SnapTos_ResourceState x))
    :qid |$Snap.s_ResourceStateTo$SnapTos_ResourceState|
    )))
(declare-fun $SortWrappers.s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap (s_visit$col$$col$$lc$closure$oc$1$rc$) $Snap)
(declare-fun $SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$ ($Snap) s_visit$col$$col$$lc$closure$oc$1$rc$)
(assert (forall ((x s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
    (= x ($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$($SortWrappers.s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x)))
    :pattern (($SortWrappers.s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x))
    :qid |$Snap.$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$ x)))
    :pattern (($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$ x))
    :qid |$Snap.s_visit$col$$col$$lc$closure$oc$1$rc$To$SnapTos_visit$col$$col$$lc$closure$oc$1$rc$|
    )))
(declare-fun $SortWrappers.ReadPermTo$Snap (ReadPerm) $Snap)
(declare-fun $SortWrappers.$SnapToReadPerm ($Snap) ReadPerm)
(assert (forall ((x ReadPerm)) (!
    (= x ($SortWrappers.$SnapToReadPerm($SortWrappers.ReadPermTo$Snap x)))
    :pattern (($SortWrappers.ReadPermTo$Snap x))
    :qid |$Snap.$SnapToReadPermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ReadPermTo$Snap($SortWrappers.$SnapToReadPerm x)))
    :pattern (($SortWrappers.$SnapToReadPerm x))
    :qid |$Snap.ReadPermTo$SnapToReadPerm|
    )))
(declare-fun $SortWrappers.sizedness_SliceTo$Snap (sizedness_Slice) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_Slice ($Snap) sizedness_Slice)
(assert (forall ((x sizedness_Slice)) (!
    (= x ($SortWrappers.$SnapTosizedness_Slice($SortWrappers.sizedness_SliceTo$Snap x)))
    :pattern (($SortWrappers.sizedness_SliceTo$Snap x))
    :qid |$Snap.$SnapTosizedness_SliceTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_SliceTo$Snap($SortWrappers.$SnapTosizedness_Slice x)))
    :pattern (($SortWrappers.$SnapTosizedness_Slice x))
    :qid |$Snap.sizedness_SliceTo$SnapTosizedness_Slice|
    )))
(declare-fun $SortWrappers.sizedness_RawPtr_immutableTo$Snap (sizedness_RawPtr_immutable) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_RawPtr_immutable ($Snap) sizedness_RawPtr_immutable)
(assert (forall ((x sizedness_RawPtr_immutable)) (!
    (= x ($SortWrappers.$SnapTosizedness_RawPtr_immutable($SortWrappers.sizedness_RawPtr_immutableTo$Snap x)))
    :pattern (($SortWrappers.sizedness_RawPtr_immutableTo$Snap x))
    :qid |$Snap.$SnapTosizedness_RawPtr_immutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_RawPtr_immutableTo$Snap($SortWrappers.$SnapTosizedness_RawPtr_immutable x)))
    :pattern (($SortWrappers.$SnapTosizedness_RawPtr_immutable x))
    :qid |$Snap.sizedness_RawPtr_immutableTo$SnapTosizedness_RawPtr_immutable|
    )))
(declare-fun $SortWrappers.s_RawPtr_immutableTo$Snap (s_RawPtr_immutable) $Snap)
(declare-fun $SortWrappers.$SnapTos_RawPtr_immutable ($Snap) s_RawPtr_immutable)
(assert (forall ((x s_RawPtr_immutable)) (!
    (= x ($SortWrappers.$SnapTos_RawPtr_immutable($SortWrappers.s_RawPtr_immutableTo$Snap x)))
    :pattern (($SortWrappers.s_RawPtr_immutableTo$Snap x))
    :qid |$Snap.$SnapTos_RawPtr_immutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_RawPtr_immutableTo$Snap($SortWrappers.$SnapTos_RawPtr_immutable x)))
    :pattern (($SortWrappers.$SnapTos_RawPtr_immutable x))
    :qid |$Snap.s_RawPtr_immutableTo$SnapTos_RawPtr_immutable|
    )))
(declare-fun $SortWrappers.sizedness_Ref_immutableTo$Snap (sizedness_Ref_immutable) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_Ref_immutable ($Snap) sizedness_Ref_immutable)
(assert (forall ((x sizedness_Ref_immutable)) (!
    (= x ($SortWrappers.$SnapTosizedness_Ref_immutable($SortWrappers.sizedness_Ref_immutableTo$Snap x)))
    :pattern (($SortWrappers.sizedness_Ref_immutableTo$Snap x))
    :qid |$Snap.$SnapTosizedness_Ref_immutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_Ref_immutableTo$Snap($SortWrappers.$SnapTosizedness_Ref_immutable x)))
    :pattern (($SortWrappers.$SnapTosizedness_Ref_immutable x))
    :qid |$Snap.sizedness_Ref_immutableTo$SnapTosizedness_Ref_immutable|
    )))
(declare-fun $SortWrappers.trait_std$col$$col$marker$col$$col$SizedTo$Snap (trait_std$col$$col$marker$col$$col$Sized) $Snap)
(declare-fun $SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$Sized ($Snap) trait_std$col$$col$marker$col$$col$Sized)
(assert (forall ((x trait_std$col$$col$marker$col$$col$Sized)) (!
    (= x ($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$Sized($SortWrappers.trait_std$col$$col$marker$col$$col$SizedTo$Snap x)))
    :pattern (($SortWrappers.trait_std$col$$col$marker$col$$col$SizedTo$Snap x))
    :qid |$Snap.$SnapTotrait_std$col$$col$marker$col$$col$SizedTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.trait_std$col$$col$marker$col$$col$SizedTo$Snap($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$Sized x)))
    :pattern (($SortWrappers.$SnapTotrait_std$col$$col$marker$col$$col$Sized x))
    :qid |$Snap.trait_std$col$$col$marker$col$$col$SizedTo$SnapTotrait_std$col$$col$marker$col$$col$Sized|
    )))
(declare-fun $SortWrappers.s_Ref_mutableTo$Snap (s_Ref_mutable) $Snap)
(declare-fun $SortWrappers.$SnapTos_Ref_mutable ($Snap) s_Ref_mutable)
(assert (forall ((x s_Ref_mutable)) (!
    (= x ($SortWrappers.$SnapTos_Ref_mutable($SortWrappers.s_Ref_mutableTo$Snap x)))
    :pattern (($SortWrappers.s_Ref_mutableTo$Snap x))
    :qid |$Snap.$SnapTos_Ref_mutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_Ref_mutableTo$Snap($SortWrappers.$SnapTos_Ref_mutable x)))
    :pattern (($SortWrappers.$SnapTos_Ref_mutable x))
    :qid |$Snap.s_Ref_mutableTo$SnapTos_Ref_mutable|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap (ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$ ($Snap) ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$)
(assert (forall ((x ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$ x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$ x))
    :qid |$Snap.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$To$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$|
    )))
(declare-fun $SortWrappers.s_ParamTo$Snap (s_Param) $Snap)
(declare-fun $SortWrappers.$SnapTos_Param ($Snap) s_Param)
(assert (forall ((x s_Param)) (!
    (= x ($SortWrappers.$SnapTos_Param($SortWrappers.s_ParamTo$Snap x)))
    :pattern (($SortWrappers.s_ParamTo$Snap x))
    :qid |$Snap.$SnapTos_ParamTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_ParamTo$Snap($SortWrappers.$SnapTos_Param x)))
    :pattern (($SortWrappers.$SnapTos_Param x))
    :qid |$Snap.s_ParamTo$SnapTos_Param|
    )))
(declare-fun $SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap (ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$) $Snap)
(declare-fun $SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$ ($Snap) ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$)
(assert (forall ((x ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
    (= x ($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x)))
    :pattern (($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap x))
    :qid |$Snap.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$Snap($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$ x)))
    :pattern (($SortWrappers.$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$ x))
    :qid |$Snap.ParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$To$SnapToParamTyp_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$|
    )))
(declare-fun $SortWrappers.s_0_TupleTo$Snap (s_0_Tuple) $Snap)
(declare-fun $SortWrappers.$SnapTos_0_Tuple ($Snap) s_0_Tuple)
(assert (forall ((x s_0_Tuple)) (!
    (= x ($SortWrappers.$SnapTos_0_Tuple($SortWrappers.s_0_TupleTo$Snap x)))
    :pattern (($SortWrappers.s_0_TupleTo$Snap x))
    :qid |$Snap.$SnapTos_0_TupleTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_0_TupleTo$Snap($SortWrappers.$SnapTos_0_Tuple x)))
    :pattern (($SortWrappers.$SnapTos_0_Tuple x))
    :qid |$Snap.s_0_TupleTo$SnapTos_0_Tuple|
    )))
(declare-fun $SortWrappers.s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap (s_visit$col$$col$$lc$closure$oc$0$rc$) $Snap)
(declare-fun $SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$ ($Snap) s_visit$col$$col$$lc$closure$oc$0$rc$)
(assert (forall ((x s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
    (= x ($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$($SortWrappers.s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x)))
    :pattern (($SortWrappers.s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x))
    :qid |$Snap.$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.s_visit$col$$col$$lc$closure$oc$0$rc$To$Snap($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$ x)))
    :pattern (($SortWrappers.$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$ x))
    :qid |$Snap.s_visit$col$$col$$lc$closure$oc$0$rc$To$SnapTos_visit$col$$col$$lc$closure$oc$0$rc$|
    )))
(declare-fun $SortWrappers.sizedness_Ref_mutableTo$Snap (sizedness_Ref_mutable) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_Ref_mutable ($Snap) sizedness_Ref_mutable)
(assert (forall ((x sizedness_Ref_mutable)) (!
    (= x ($SortWrappers.$SnapTosizedness_Ref_mutable($SortWrappers.sizedness_Ref_mutableTo$Snap x)))
    :pattern (($SortWrappers.sizedness_Ref_mutableTo$Snap x))
    :qid |$Snap.$SnapTosizedness_Ref_mutableTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_Ref_mutableTo$Snap($SortWrappers.$SnapTosizedness_Ref_mutable x)))
    :pattern (($SortWrappers.$SnapTosizedness_Ref_mutable x))
    :qid |$Snap.sizedness_Ref_mutableTo$SnapTosizedness_Ref_mutable|
    )))
(declare-fun $SortWrappers.sizedness_BoolTo$Snap (sizedness_Bool) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_Bool ($Snap) sizedness_Bool)
(assert (forall ((x sizedness_Bool)) (!
    (= x ($SortWrappers.$SnapTosizedness_Bool($SortWrappers.sizedness_BoolTo$Snap x)))
    :pattern (($SortWrappers.sizedness_BoolTo$Snap x))
    :qid |$Snap.$SnapTosizedness_BoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_BoolTo$Snap($SortWrappers.$SnapTosizedness_Bool x)))
    :pattern (($SortWrappers.$SnapTosizedness_Bool x))
    :qid |$Snap.sizedness_BoolTo$SnapTosizedness_Bool|
    )))
(declare-fun $SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$0$rc$To$Snap (sizedness_visit$col$$col$$lc$closure$oc$0$rc$) $Snap)
(declare-fun $SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$ ($Snap) sizedness_visit$col$$col$$lc$closure$oc$0$rc$)
(assert (forall ((x sizedness_visit$col$$col$$lc$closure$oc$0$rc$)) (!
    (= x ($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x)))
    :pattern (($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$0$rc$To$Snap x))
    :qid |$Snap.$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.sizedness_visit$col$$col$$lc$closure$oc$0$rc$To$Snap($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$ x)))
    :pattern (($SortWrappers.$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$ x))
    :qid |$Snap.sizedness_visit$col$$col$$lc$closure$oc$0$rc$To$SnapTosizedness_visit$col$$col$$lc$closure$oc$0$rc$|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.$PSF<indexed_p_Param>To$Snap ($PSF<indexed_p_Param>) $Snap)
(declare-fun $SortWrappers.$SnapTo$PSF<indexed_p_Param> ($Snap) $PSF<indexed_p_Param>)
(assert (forall ((x $PSF<indexed_p_Param>)) (!
    (= x ($SortWrappers.$SnapTo$PSF<indexed_p_Param>($SortWrappers.$PSF<indexed_p_Param>To$Snap x)))
    :pattern (($SortWrappers.$PSF<indexed_p_Param>To$Snap x))
    :qid |$Snap.$SnapTo$PSF<indexed_p_Param>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PSF<indexed_p_Param>To$Snap($SortWrappers.$SnapTo$PSF<indexed_p_Param> x)))
    :pattern (($SortWrappers.$SnapTo$PSF<indexed_p_Param> x))
    :qid |$Snap.$PSF<indexed_p_Param>To$SnapTo$PSF<indexed_p_Param>|
    )))
; ////////// Symbols
(declare-fun Set_card (Set<$Ref>) Int)
(declare-const Set_empty Set<$Ref>)
(declare-fun Set_in ($Ref Set<$Ref>) Bool)
(declare-fun Set_singleton ($Ref) Set<$Ref>)
(declare-fun Set_unionone (Set<$Ref> $Ref) Set<$Ref>)
(declare-fun Set_union (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_intersection (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_difference (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_subset (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_equal (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_skolem_diff (Set<$Ref> Set<$Ref>) $Ref)
(declare-fun Set_card (Set<s_Param>) Int)
(declare-const Set_empty Set<s_Param>)
(declare-fun Set_in (s_Param Set<s_Param>) Bool)
(declare-fun Set_singleton (s_Param) Set<s_Param>)
(declare-fun Set_unionone (Set<s_Param> s_Param) Set<s_Param>)
(declare-fun Set_union (Set<s_Param> Set<s_Param>) Set<s_Param>)
(declare-fun Set_intersection (Set<s_Param> Set<s_Param>) Set<s_Param>)
(declare-fun Set_difference (Set<s_Param> Set<s_Param>) Set<s_Param>)
(declare-fun Set_subset (Set<s_Param> Set<s_Param>) Bool)
(declare-fun Set_equal (Set<s_Param> Set<s_Param>) Bool)
(declare-fun Set_skolem_diff (Set<s_Param> Set<s_Param>) s_Param)
(declare-fun Set_card (Set<s_UInt_usize>) Int)
(declare-const Set_empty Set<s_UInt_usize>)
(declare-fun Set_in (s_UInt_usize Set<s_UInt_usize>) Bool)
(declare-fun Set_singleton (s_UInt_usize) Set<s_UInt_usize>)
(declare-fun Set_unionone (Set<s_UInt_usize> s_UInt_usize) Set<s_UInt_usize>)
(declare-fun Set_union (Set<s_UInt_usize> Set<s_UInt_usize>) Set<s_UInt_usize>)
(declare-fun Set_intersection (Set<s_UInt_usize> Set<s_UInt_usize>) Set<s_UInt_usize>)
(declare-fun Set_difference (Set<s_UInt_usize> Set<s_UInt_usize>) Set<s_UInt_usize>)
(declare-fun Set_subset (Set<s_UInt_usize> Set<s_UInt_usize>) Bool)
(declare-fun Set_equal (Set<s_UInt_usize> Set<s_UInt_usize>) Bool)
(declare-fun Set_skolem_diff (Set<s_UInt_usize> Set<s_UInt_usize>) s_UInt_usize)
(declare-fun Set_card (Set<s_UInt_u32>) Int)
(declare-const Set_empty Set<s_UInt_u32>)
(declare-fun Set_in (s_UInt_u32 Set<s_UInt_u32>) Bool)
(declare-fun Set_singleton (s_UInt_u32) Set<s_UInt_u32>)
(declare-fun Set_unionone (Set<s_UInt_u32> s_UInt_u32) Set<s_UInt_u32>)
(declare-fun Set_union (Set<s_UInt_u32> Set<s_UInt_u32>) Set<s_UInt_u32>)
(declare-fun Set_intersection (Set<s_UInt_u32> Set<s_UInt_u32>) Set<s_UInt_u32>)
(declare-fun Set_difference (Set<s_UInt_u32> Set<s_UInt_u32>) Set<s_UInt_u32>)
(declare-fun Set_subset (Set<s_UInt_u32> Set<s_UInt_u32>) Bool)
(declare-fun Set_equal (Set<s_UInt_u32> Set<s_UInt_u32>) Bool)
(declare-fun Set_skolem_diff (Set<s_UInt_u32> Set<s_UInt_u32>) s_UInt_u32)
(declare-fun Set_card (Set<Bool>) Int)
(declare-const Set_empty Set<Bool>)
(declare-fun Set_in (Bool Set<Bool>) Bool)
(declare-fun Set_singleton (Bool) Set<Bool>)
(declare-fun Set_unionone (Set<Bool> Bool) Set<Bool>)
(declare-fun Set_union (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_intersection (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_difference (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_subset (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_equal (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_skolem_diff (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_card (Set<$Snap>) Int)
(declare-const Set_empty Set<$Snap>)
(declare-fun Set_in ($Snap Set<$Snap>) Bool)
(declare-fun Set_singleton ($Snap) Set<$Snap>)
(declare-fun Set_unionone (Set<$Snap> $Snap) Set<$Snap>)
(declare-fun Set_union (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_intersection (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_difference (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_subset (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_equal (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_skolem_diff (Set<$Snap> Set<$Snap>) $Snap)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
(declare-fun Seq_length (Seq<s_ResourceState>) Int)
(declare-const Seq_empty Seq<s_ResourceState>)
(declare-fun Seq_singleton (s_ResourceState) Seq<s_ResourceState>)
(declare-fun Seq_append (Seq<s_ResourceState> Seq<s_ResourceState>) Seq<s_ResourceState>)
(declare-fun Seq_index (Seq<s_ResourceState> Int) s_ResourceState)
(declare-fun Seq_update (Seq<s_ResourceState> Int s_ResourceState) Seq<s_ResourceState>)
(declare-fun Seq_take (Seq<s_ResourceState> Int) Seq<s_ResourceState>)
(declare-fun Seq_drop (Seq<s_ResourceState> Int) Seq<s_ResourceState>)
(declare-fun Seq_contains (Seq<s_ResourceState> s_ResourceState) Bool)
(declare-fun Seq_contains_trigger (Seq<s_ResourceState> s_ResourceState) Bool)
(declare-fun Seq_skolem (Seq<s_ResourceState> s_ResourceState) Int)
(declare-fun Seq_equal (Seq<s_ResourceState> Seq<s_ResourceState>) Bool)
(declare-fun Seq_skolem_diff (Seq<s_ResourceState> Seq<s_ResourceState>) Int)
(declare-fun Seq_length (Seq<s_Param>) Int)
(declare-const Seq_empty Seq<s_Param>)
(declare-fun Seq_singleton (s_Param) Seq<s_Param>)
(declare-fun Seq_append (Seq<s_Param> Seq<s_Param>) Seq<s_Param>)
(declare-fun Seq_index (Seq<s_Param> Int) s_Param)
(declare-fun Seq_update (Seq<s_Param> Int s_Param) Seq<s_Param>)
(declare-fun Seq_take (Seq<s_Param> Int) Seq<s_Param>)
(declare-fun Seq_drop (Seq<s_Param> Int) Seq<s_Param>)
(declare-fun Seq_contains (Seq<s_Param> s_Param) Bool)
(declare-fun Seq_contains_trigger (Seq<s_Param> s_Param) Bool)
(declare-fun Seq_skolem (Seq<s_Param> s_Param) Int)
(declare-fun Seq_equal (Seq<s_Param> Seq<s_Param>) Bool)
(declare-fun Seq_skolem_diff (Seq<s_Param> Seq<s_Param>) Int)
(declare-fun s_UInt_u32_cons<s_UInt_u32> (Int) s_UInt_u32)
(declare-fun s_UInt_u32_value<Int> (s_UInt_u32) Int)
(declare-const s_0_Tuple_cons<s_0_Tuple> s_0_Tuple)
(declare-fun s_0_Tuple_tag<Int> (s_0_Tuple) Int)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> (s_Ref_immutable) s_visit$col$$col$$lc$closure$oc$0$rc$)
(declare-fun get_s_visit$col$$col$$lc$closure$oc$0$rc$_s_visit$col$$col$$lc$closure$oc$0$rc$_0<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$0$rc$) s_Ref_immutable)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_tag<Int> (s_visit$col$$col$$lc$closure$oc$0$rc$) Int)
(declare-fun std$col$$col$marker$col$$col$Sized_impl<Bool> (Type) Bool)
(declare-fun s_Ref_mutable_cons<s_Ref_mutable> ($Ref s_Param s_Param) s_Ref_mutable)
(declare-fun get_s_Ref_mutable_s_Ref_mutable_0<Ref> (s_Ref_mutable) $Ref)
(declare-fun get_s_Ref_mutable_s_Ref_mutable_1<s_Param> (s_Ref_mutable) s_Param)
(declare-fun get_s_Ref_mutable_s_Ref_mutable_2<s_Param> (s_Ref_mutable) s_Param)
(declare-fun s_Ref_mutable_tag<Int> (s_Ref_mutable) Int)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> (s_Ref_immutable s_Ref_immutable) s_visit$col$$col$$lc$closure$oc$1$rc$)
(declare-fun get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_0<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$1$rc$) s_Ref_immutable)
(declare-fun get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_1<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$1$rc$) s_Ref_immutable)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_tag<Int> (s_visit$col$$col$$lc$closure$oc$1$rc$) Int)
(declare-const read<Perm> $Perm)
(declare-const s_0_Tuple_type<Type> Type)
(declare-fun s_Ref_mutable_type<Type> (Type) Type)
(declare-fun s_Slice_type<Type> (Type) Type)
(declare-const s_UInt_u32_type<Type> Type)
(declare-const s_UInt_usize_type<Type> Type)
(declare-fun s_Ref_immutable_type<Type> (Type) Type)
(declare-fun s_RawPtr_immutable_type<Type> (Type) Type)
(declare-const s_Bool_type<Type> Type)
(declare-const s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type> Type)
(declare-const s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type> Type)
(declare-fun Unknown_type<Type> (Int) Type)
(declare-fun get_Type_s_Ref_mutable_typaram_U$1<Type> (Type) Type)
(declare-fun get_Type_s_Slice_typaram_T$0<Type> (Type) Type)
(declare-fun get_Type_s_Ref_immutable_typaram_U$1<Type> (Type) Type)
(declare-fun get_Type_s_RawPtr_immutable_typaram_T$0<Type> (Type) Type)
(declare-fun get_Type_id<Int> (Type) Int)
(declare-fun Type_tag<Int> (Type) Int)
(declare-fun inhabited<Bool> (Type) Bool)
(declare-fun std$col$$col$marker$col$$col$MetaSized_impl<Bool> (Type) Bool)
(declare-fun s_Ref_immutable_cons<s_Ref_immutable> ($Ref s_Param s_Param) s_Ref_immutable)
(declare-fun get_s_Ref_immutable_s_Ref_immutable_0<Ref> (s_Ref_immutable) $Ref)
(declare-fun get_s_Ref_immutable_s_Ref_immutable_1<s_Param> (s_Ref_immutable) s_Param)
(declare-fun get_s_Ref_immutable_s_Ref_immutable_2<s_Param> (s_Ref_immutable) s_Param)
(declare-fun s_Ref_immutable_tag<Int> (s_Ref_immutable) Int)
(declare-fun s_Slice_index<s_Param> (s_Slice Int) s_Param)
(declare-fun s_Slice_index_ref<Ref> ($Ref Int Type) $Ref)
(declare-fun s_Slice_from_seq<s_Slice> (Seq<s_Param>) s_Slice)
(declare-fun s_Slice_to_seq<Seq<s_Param>> (s_Slice Int) Seq<s_Param>)
(declare-fun std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> (Type) Type)
(declare-fun std$col$$col$ptr$col$$col$Pointee_impl<Bool> (Type) Bool)
(declare-fun s_Param_typ<Type> (s_Param) Type)
(declare-fun s_Param_has_typ<Bool> (s_Param Type) Bool)
(declare-fun s_RawPtr_immutable_cons<s_RawPtr_immutable> ($Ref s_Param) s_RawPtr_immutable)
(declare-fun get_s_RawPtr_immutable_s_RawPtr_immutable_0<Ref> (s_RawPtr_immutable) $Ref)
(declare-fun get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> (s_RawPtr_immutable) s_Param)
(declare-fun s_RawPtr_immutable_tag<Int> (s_RawPtr_immutable) Int)
(declare-fun s_UInt_usize_cons<s_UInt_usize> (Int) s_UInt_usize)
(declare-fun s_UInt_usize_value<Int> (s_UInt_usize) Int)
(declare-const ResourceEmpty<s_ResourceState> s_ResourceState)
(declare-fun ResourceReference<s_ResourceState> (s_Param s_ResourceState) s_ResourceState)
(declare-fun ResourceFields<s_ResourceState> (Seq<s_ResourceState>) s_ResourceState)
(declare-fun ResourceUnknown<s_ResourceState> (Int) s_ResourceState)
(declare-fun get_s_ResourceState_resource_stored<s_Param> (s_ResourceState) s_Param)
(declare-fun get_s_ResourceState_resource_nested<s_ResourceState> (s_ResourceState) s_ResourceState)
(declare-fun get_s_ResourceState_resource_fields<Seq<s_ResourceState>> (s_ResourceState) Seq<s_ResourceState>)
(declare-fun get_s_ResourceState_resource_unknown<Int> (s_ResourceState) Int)
(declare-fun s_ResourceState_tag<Int> (s_ResourceState) Int)
(declare-fun make_generic_s_Slice<s_Param> (s_Slice Type) s_Param)
(declare-fun make_generic_s_UInt_usize<s_Param> (s_UInt_usize) s_Param)
(declare-fun make_generic_s_0_Tuple<s_Param> (s_0_Tuple) s_Param)
(declare-fun make_generic_s_Ref_mutable<s_Param> (s_Ref_mutable Type) s_Param)
(declare-fun make_generic_s_UInt_u32<s_Param> (s_UInt_u32) s_Param)
(declare-fun make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> (s_visit$col$$col$$lc$closure$oc$0$rc$) s_Param)
(declare-fun make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> (s_visit$col$$col$$lc$closure$oc$1$rc$) s_Param)
(declare-fun s_Param_Unknown<s_Param> (Int) s_Param)
(declare-fun get_s_Param_make_concrete_s_Slice<s_Slice> (s_Param) s_Slice)
(declare-fun get_s_Param_make_generic_s_Slice_typaram_T$0<Type> (s_Param) Type)
(declare-fun get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (s_Param) s_UInt_usize)
(declare-fun get_s_Param_make_concrete_s_0_Tuple<s_0_Tuple> (s_Param) s_0_Tuple)
(declare-fun get_s_Param_make_concrete_s_Ref_mutable<s_Ref_mutable> (s_Param) s_Ref_mutable)
(declare-fun get_s_Param_make_generic_s_Ref_mutable_typaram_U$1<Type> (s_Param) Type)
(declare-fun get_s_Param_make_concrete_s_UInt_u32<s_UInt_u32> (s_Param) s_UInt_u32)
(declare-fun get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$<s_visit$col$$col$$lc$closure$oc$0$rc$> (s_Param) s_visit$col$$col$$lc$closure$oc$0$rc$)
(declare-fun get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$<s_visit$col$$col$$lc$closure$oc$1$rc$> (s_Param) s_visit$col$$col$$lc$closure$oc$1$rc$)
(declare-fun get_s_Param_s_Param_Unknown_id<Int> (s_Param) Int)
(declare-fun s_Param_tag<Int> (s_Param) Int)
; /predicate_snap_functions_declarations.smt2 [indexed_p_Param: Snap]
(declare-fun $PSF.domain_indexed_p_Param ($PSF<indexed_p_Param>) Set<$Snap>)
(declare-fun $PSF.has_domain_indexed_p_Param ($PSF<indexed_p_Param>) Bool)
(declare-fun $PSF.lookup_indexed_p_Param ($PSF<indexed_p_Param> $Snap) $Snap)
(declare-fun $PSF.after_indexed_p_Param ($PSF<indexed_p_Param> $PSF<indexed_p_Param>) Bool)
(declare-fun $PSF.loc_indexed_p_Param ($Snap $Snap) Bool)
(declare-fun $PSF.perm_indexed_p_Param ($PPM $Snap) $Perm)
(declare-const $psfTOP_indexed_p_Param $PSF<indexed_p_Param>)
; Declaring symbols related to program functions (from program analysis)
(declare-fun mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize ($Snap s_RawPtr_immutable) s_UInt_usize)
(declare-fun mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%limited ($Snap s_RawPtr_immutable) s_UInt_usize)
(declare-fun mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%stateless (s_RawPtr_immutable) Bool)
(declare-fun mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition ($Snap s_RawPtr_immutable) Bool)
(declare-fun mir_binop_Eq_UInt_usize_UInt_usize ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Eq_UInt_usize_UInt_usize%limited ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Eq_UInt_usize_UInt_usize%stateless (s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Eq_UInt_usize_UInt_usize%precondition ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun p_Param_snap ($Snap $Ref Type) s_Param)
(declare-fun p_Param_snap%limited ($Snap $Ref Type) s_Param)
(declare-fun p_Param_snap%stateless ($Ref Type) Bool)
(declare-fun p_Param_snap%precondition ($Snap $Ref Type) Bool)
(declare-fun p_Ref_mutable_arbitrary_value ($Snap $Ref s_Param Type) s_Ref_mutable)
(declare-fun p_Ref_mutable_arbitrary_value%limited ($Snap $Ref s_Param Type) s_Ref_mutable)
(declare-fun p_Ref_mutable_arbitrary_value%stateless ($Ref s_Param Type) Bool)
(declare-fun p_Ref_mutable_arbitrary_value%precondition ($Snap $Ref s_Param Type) Bool)
(declare-fun f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len ($Snap s_Ref_immutable Type) s_UInt_usize)
(declare-fun f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited ($Snap s_Ref_immutable Type) s_UInt_usize)
(declare-fun f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%stateless (s_Ref_immutable Type) Bool)
(declare-fun f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition ($Snap s_Ref_immutable Type) Bool)
(declare-fun p_0_Tuple_snap ($Snap $Ref) s_0_Tuple)
(declare-fun p_0_Tuple_snap%limited ($Snap $Ref) s_0_Tuple)
(declare-fun p_0_Tuple_snap%stateless ($Ref) Bool)
(declare-fun p_0_Tuple_snap%precondition ($Snap $Ref) Bool)
(declare-fun mir_binop_Eq_UInt_u32_UInt_u32 ($Snap s_UInt_u32 s_UInt_u32) Bool)
(declare-fun mir_binop_Eq_UInt_u32_UInt_u32%limited ($Snap s_UInt_u32 s_UInt_u32) Bool)
(declare-fun mir_binop_Eq_UInt_u32_UInt_u32%stateless (s_UInt_u32 s_UInt_u32) Bool)
(declare-fun mir_binop_Eq_UInt_u32_UInt_u32%precondition ($Snap s_UInt_u32 s_UInt_u32) Bool)
(declare-fun p_UInt_u32_snap ($Snap $Ref) s_UInt_u32)
(declare-fun p_UInt_u32_snap%limited ($Snap $Ref) s_UInt_u32)
(declare-fun p_UInt_u32_snap%stateless ($Ref) Bool)
(declare-fun p_UInt_u32_snap%precondition ($Snap $Ref) Bool)
(declare-fun p_RawPtr_immutable_snap ($Snap $Ref Type) s_RawPtr_immutable)
(declare-fun p_RawPtr_immutable_snap%limited ($Snap $Ref Type) s_RawPtr_immutable)
(declare-fun p_RawPtr_immutable_snap%stateless ($Ref Type) Bool)
(declare-fun p_RawPtr_immutable_snap%precondition ($Snap $Ref Type) Bool)
(declare-fun s_Ref_immutable_unreachable ($Snap Type) s_Ref_immutable)
(declare-fun s_Ref_immutable_unreachable%limited ($Snap Type) s_Ref_immutable)
(declare-fun s_Ref_immutable_unreachable%stateless (Type) Bool)
(declare-fun s_Ref_immutable_unreachable%precondition ($Snap Type) Bool)
(declare-fun p_Bool_snap ($Snap $Ref) Bool)
(declare-fun p_Bool_snap%limited ($Snap $Ref) Bool)
(declare-fun p_Bool_snap%stateless ($Ref) Bool)
(declare-fun p_Bool_snap%precondition ($Snap $Ref) Bool)
(declare-fun s_UInt_u32_unreachable ($Snap) s_UInt_u32)
(declare-fun s_UInt_u32_unreachable%limited ($Snap) s_UInt_u32)
(declare-const s_UInt_u32_unreachable%stateless Bool)
(declare-fun s_UInt_u32_unreachable%precondition ($Snap) Bool)
(declare-fun p_Ref_immutable_snap ($Snap $Ref Type) s_Ref_immutable)
(declare-fun p_Ref_immutable_snap%limited ($Snap $Ref Type) s_Ref_immutable)
(declare-fun p_Ref_immutable_snap%stateless ($Ref Type) Bool)
(declare-fun p_Ref_immutable_snap%precondition ($Snap $Ref Type) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable ($Snap) s_visit$col$$col$$lc$closure$oc$0$rc$)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited ($Snap) s_visit$col$$col$$lc$closure$oc$0$rc$)
(declare-const s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%stateless Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%precondition ($Snap) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_0 ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%stateless ($Ref) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%precondition ($Snap $Ref) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_1 ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%stateless ($Ref) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%precondition ($Snap $Ref) Bool)
(declare-fun s_Ref_mutable_unreachable ($Snap Type) s_Ref_mutable)
(declare-fun s_Ref_mutable_unreachable%limited ($Snap Type) s_Ref_mutable)
(declare-fun s_Ref_mutable_unreachable%stateless (Type) Bool)
(declare-fun s_Ref_mutable_unreachable%precondition ($Snap Type) Bool)
(declare-fun indexed_resource_observation ($Snap s_Param Int) s_Param)
(declare-fun indexed_resource_observation%limited ($Snap s_Param Int) s_Param)
(declare-fun indexed_resource_observation%stateless (s_Param Int) Bool)
(declare-fun indexed_resource_observation%precondition ($Snap s_Param Int) Bool)
(declare-fun p_Ref_mutable_snap ($Snap $Ref Type) s_Ref_mutable)
(declare-fun p_Ref_mutable_snap%limited ($Snap $Ref Type) s_Ref_mutable)
(declare-fun p_Ref_mutable_snap%stateless ($Ref Type) Bool)
(declare-fun p_Ref_mutable_snap%precondition ($Snap $Ref Type) Bool)
(declare-fun s_Slice_unreachable ($Snap Type) s_Slice)
(declare-fun s_Slice_unreachable%limited ($Snap Type) s_Slice)
(declare-fun s_Slice_unreachable%stateless (Type) Bool)
(declare-fun s_Slice_unreachable%precondition ($Snap Type) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable ($Snap) s_visit$col$$col$$lc$closure$oc$1$rc$)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited ($Snap) s_visit$col$$col$$lc$closure$oc$1$rc$)
(declare-const s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%stateless Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%precondition ($Snap) Bool)
(declare-fun p_Slice_snap ($Snap $Ref Type) s_Slice)
(declare-fun p_Slice_snap%limited ($Snap $Ref Type) s_Slice)
(declare-fun p_Slice_snap%stateless ($Ref Type) Bool)
(declare-fun p_Slice_snap%precondition ($Snap $Ref Type) Bool)
(declare-fun mir_binop_Ne_UInt_usize_UInt_usize ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Ne_UInt_usize_UInt_usize%limited ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Ne_UInt_usize_UInt_usize%stateless (s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Ne_UInt_usize_UInt_usize%precondition ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_field_0 ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited ($Snap $Ref) $Ref)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%stateless ($Ref) Bool)
(declare-fun s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%precondition ($Snap $Ref) Bool)
(declare-fun p_Slice_index_frame ($Snap $Ref Int Type) s_Slice)
(declare-fun p_Slice_index_frame%limited ($Snap $Ref Int Type) s_Slice)
(declare-fun p_Slice_index_frame%stateless ($Ref Int Type) Bool)
(declare-fun p_Slice_index_frame%precondition ($Snap $Ref Int Type) Bool)
(declare-fun mir_binop_Lt_UInt_usize_UInt_usize ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Lt_UInt_usize_UInt_usize%limited ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Lt_UInt_usize_UInt_usize%stateless (s_UInt_usize s_UInt_usize) Bool)
(declare-fun mir_binop_Lt_UInt_usize_UInt_usize%precondition ($Snap s_UInt_usize s_UInt_usize) Bool)
(declare-fun s_Bool_unreachable ($Snap) Bool)
(declare-fun s_Bool_unreachable%limited ($Snap) Bool)
(declare-const s_Bool_unreachable%stateless Bool)
(declare-fun s_Bool_unreachable%precondition ($Snap) Bool)
(declare-fun cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len ($Snap s_Ref_immutable Type) s_UInt_usize)
(declare-fun cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited ($Snap s_Ref_immutable Type) s_UInt_usize)
(declare-fun cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%stateless (s_Ref_immutable Type) Bool)
(declare-fun cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition ($Snap s_Ref_immutable Type) Bool)
(declare-fun p_UInt_usize_snap ($Snap $Ref) s_UInt_usize)
(declare-fun p_UInt_usize_snap%limited ($Snap $Ref) s_UInt_usize)
(declare-fun p_UInt_usize_snap%stateless ($Ref) Bool)
(declare-fun p_UInt_usize_snap%precondition ($Snap $Ref) Bool)
(declare-fun s_Param_unreachable ($Snap Type) s_Param)
(declare-fun s_Param_unreachable%limited ($Snap Type) s_Param)
(declare-fun s_Param_unreachable%stateless (Type) Bool)
(declare-fun s_Param_unreachable%precondition ($Snap Type) Bool)
(declare-fun s_0_Tuple_unreachable ($Snap) s_0_Tuple)
(declare-fun s_0_Tuple_unreachable%limited ($Snap) s_0_Tuple)
(declare-const s_0_Tuple_unreachable%stateless Bool)
(declare-fun s_0_Tuple_unreachable%precondition ($Snap) Bool)
(declare-fun s_UInt_usize_unreachable ($Snap) s_UInt_usize)
(declare-fun s_UInt_usize_unreachable%limited ($Snap) s_UInt_usize)
(declare-const s_UInt_usize_unreachable%stateless Bool)
(declare-fun s_UInt_usize_unreachable%precondition ($Snap) Bool)
(declare-fun s_RawPtr_immutable_unreachable ($Snap Type) s_RawPtr_immutable)
(declare-fun s_RawPtr_immutable_unreachable%limited ($Snap Type) s_RawPtr_immutable)
(declare-fun s_RawPtr_immutable_unreachable%stateless (Type) Bool)
(declare-fun s_RawPtr_immutable_unreachable%precondition ($Snap Type) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
(declare-fun p_0_Tuple%trigger ($Snap $Ref) Bool)
(declare-fun p_Ref_mutable%trigger ($Snap $Ref Type) Bool)
(declare-fun p_Param%trigger ($Snap $Ref Type) Bool)
(declare-fun p_Slice%trigger ($Snap $Ref Type) Bool)
(declare-fun p_Slice_index%trigger ($Snap $Ref Int Type) Bool)
(declare-fun p_UInt_usize%trigger ($Snap $Ref) Bool)
(declare-fun p_Ref_immutable%trigger ($Snap $Ref Type) Bool)
(declare-fun p_UInt_u32%trigger ($Snap $Ref) Bool)
(declare-fun p_RawPtr_immutable%trigger ($Snap $Ref Type) Bool)
(declare-fun p_Bool%trigger ($Snap $Ref) Bool)
(declare-fun indexed_p_Param%trigger ($Snap Int Seq<Int> $Ref Type) Bool)
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and
          (not (= s0 (Seq_append s0 s1)))
          (and
            (not (= s1 (Seq_append s0 s1)))
            (and (<= 0 m) (< m (Seq_length s1)))))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((s Seq<s_ResourceState>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[s_ResourceState]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<s_ResourceState>)) 0))
(assert (forall ((s Seq<s_ResourceState>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<s_ResourceState>)))
  :pattern ((Seq_length s))
  :qid |$Seq[s_ResourceState]_prog.Seq_length_zero|)))
(assert (forall ((e s_ResourceState)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[s_ResourceState]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_ResourceState>)))
      (not (= s1 (as Seq_empty  Seq<s_ResourceState>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<s_ResourceState>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<s_ResourceState>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_empty|)))
(assert (forall ((e s_ResourceState)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[s_ResourceState]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[s_ResourceState]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[s_ResourceState]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_ResourceState>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_ResourceState>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_ResourceState>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_ResourceState>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_ResourceState>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_ResourceState>)))
        (and
          (not (= s0 (Seq_append s0 s1)))
          (and
            (not (= s1 (Seq_append s0 s1)))
            (and (<= 0 m) (< m (Seq_length s1)))))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<s_ResourceState>) (i Int) (v s_ResourceState)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[s_ResourceState]_prog.Seq_update_length|)))
(assert (forall ((s Seq<s_ResourceState>) (i Int) (v s_ResourceState) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[s_ResourceState]_prog.Seq_update_index|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[s_ResourceState]_prog.Seq_take_length|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_take_index|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[s_ResourceState]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[s_ResourceState]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<s_ResourceState>) (t Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<s_ResourceState>) (t Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<s_ResourceState>) (t Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<s_ResourceState>) (t Seq<s_ResourceState>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[s_ResourceState]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<s_ResourceState>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_take_all|)))
(assert (forall ((s Seq<s_ResourceState>) (n Int)) (!
  (=>
    (>= n (Seq_length s))
    (= (Seq_drop s n) (as Seq_empty  Seq<s_ResourceState>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[s_ResourceState]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<s_ResourceState>) (x s_ResourceState)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[s_ResourceState]_prog.Seq_contains1|)))
(assert (forall ((s Seq<s_ResourceState>) (x s_ResourceState) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[s_ResourceState]_prog.Seq_contains2|)))
(assert (forall ((s Seq<s_ResourceState>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[s_ResourceState]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<s_ResourceState>) (s1 Seq<s_ResourceState>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[s_ResourceState]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<s_ResourceState>) (b Seq<s_ResourceState>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[s_ResourceState]_prog.Seq_equal_ext|)))
(assert (forall ((x s_ResourceState) (y s_ResourceState)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[s_ResourceState]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<s_Param>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[s_Param]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<s_Param>)) 0))
(assert (forall ((s Seq<s_Param>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<s_Param>)))
  :pattern ((Seq_length s))
  :qid |$Seq[s_Param]_prog.Seq_length_zero|)))
(assert (forall ((e s_Param)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[s_Param]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_Param>)))
      (not (= s1 (as Seq_empty  Seq<s_Param>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[s_Param]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<s_Param>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<s_Param>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[s_Param]_prog.Seq_append_empty|)))
(assert (forall ((e s_Param)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[s_Param]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[s_Param]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[s_Param]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_Param>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_Param>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[s_Param]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_Param>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_Param>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[s_Param]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<s_Param>)))
      (and
        (not (= s1 (as Seq_empty  Seq<s_Param>)))
        (and
          (not (= s0 (Seq_append s0 s1)))
          (and
            (not (= s1 (Seq_append s0 s1)))
            (and (<= 0 m) (< m (Seq_length s1)))))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[s_Param]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<s_Param>) (i Int) (v s_Param)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[s_Param]_prog.Seq_update_length|)))
(assert (forall ((s Seq<s_Param>) (i Int) (v s_Param) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[s_Param]_prog.Seq_update_index|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[s_Param]_prog.Seq_take_length|)))
(assert (forall ((s Seq<s_Param>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[s_Param]_prog.Seq_take_index|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[s_Param]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<s_Param>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[s_Param]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<s_Param>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[s_Param]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<s_Param>) (t Seq<s_Param>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[s_Param]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<s_Param>) (t Seq<s_Param>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[s_Param]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<s_Param>) (t Seq<s_Param>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[s_Param]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<s_Param>) (t Seq<s_Param>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[s_Param]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<s_Param>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[s_Param]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[s_Param]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[s_Param]_prog.Seq_take_all|)))
(assert (forall ((s Seq<s_Param>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<s_Param>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[s_Param]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<s_Param>) (x s_Param)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[s_Param]_prog.Seq_contains1|)))
(assert (forall ((s Seq<s_Param>) (x s_Param) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[s_Param]_prog.Seq_contains2|)))
(assert (forall ((s Seq<s_Param>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[s_Param]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<s_Param>) (s1 Seq<s_Param>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[s_Param]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<s_Param>) (b Seq<s_Param>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[s_Param]_prog.Seq_equal_ext|)))
(assert (forall ((x s_Param) (y s_Param)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[s_Param]_prog.Seq_singleton_contains|)))
(assert (forall ((s Set<$Ref>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Ref]_prog.Set_card_nonneg|)))
(assert (forall ((o $Ref)) (!
  (not (Set_in o (as Set_empty  Set<$Ref>)))
  :pattern ((Set_in o (as Set_empty  Set<$Ref>)))
  :qid |$Set[Ref]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Ref>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<$Ref>)))
    (=> (not (= (Set_card s) 0)) (exists ((x $Ref))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Ref]_prog.Set_card_zero|)))
(assert (forall ((r $Ref)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Ref]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Ref) (o $Ref)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Ref]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Ref)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Ref]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (o $Ref)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Ref]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Ref]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (y $Ref)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Ref]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Ref]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Ref]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Ref]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Ref]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Ref]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Ref]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Ref]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Ref]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Ref]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Ref]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Ref]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Ref]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Ref]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Ref]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (=
    (Set_subset a b)
    (forall ((o $Ref)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Ref]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Ref]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Ref]_prog.Set_equal_ext|)))
(assert (forall ((s Set<s_Param>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[s_Param]_prog.Set_card_nonneg|)))
(assert (forall ((o s_Param)) (!
  (not (Set_in o (as Set_empty  Set<s_Param>)))
  :pattern ((Set_in o (as Set_empty  Set<s_Param>)))
  :qid |$Set[s_Param]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<s_Param>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<s_Param>)))
    (=> (not (= (Set_card s) 0)) (exists ((x s_Param))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[s_Param]_prog.Set_card_zero|)))
(assert (forall ((r s_Param)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[s_Param]_prog.Set_singleton_contains1|)))
(assert (forall ((r s_Param) (o s_Param)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[s_Param]_prog.Set_singleton_contains2|)))
(assert (forall ((r s_Param)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[s_Param]_prog.Set_singleton_card|)))
(assert (forall ((a Set<s_Param>) (x s_Param) (o s_Param)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[s_Param]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<s_Param>) (x s_Param)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[s_Param]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<s_Param>) (x s_Param) (y s_Param)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[s_Param]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<s_Param>) (x s_Param)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_Param]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<s_Param>) (x s_Param)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_Param]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (o s_Param)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[s_Param]_prog.Set_union_contains1|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (y s_Param)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[s_Param]_prog.Set_union_contains2|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (y s_Param)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[s_Param]_prog.Set_union_contains3|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (o s_Param)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[s_Param]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[s_Param]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[s_Param]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[s_Param]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[s_Param]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[s_Param]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (o s_Param)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[s_Param]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>) (y s_Param)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[s_Param]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[s_Param]_prog.Set_diff_card|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (=
    (Set_subset a b)
    (forall ((o s_Param)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[s_Param]_prog.Set_subset_def|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[s_Param]_prog.Set_equal_def|)))
(assert (forall ((a Set<s_Param>) (b Set<s_Param>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[s_Param]_prog.Set_equal_ext|)))
(assert (forall ((s Set<s_UInt_usize>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[s_UInt_usize]_prog.Set_card_nonneg|)))
(assert (forall ((o s_UInt_usize)) (!
  (not (Set_in o (as Set_empty  Set<s_UInt_usize>)))
  :pattern ((Set_in o (as Set_empty  Set<s_UInt_usize>)))
  :qid |$Set[s_UInt_usize]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<s_UInt_usize>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<s_UInt_usize>)))
    (=> (not (= (Set_card s) 0)) (exists ((x s_UInt_usize))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[s_UInt_usize]_prog.Set_card_zero|)))
(assert (forall ((r s_UInt_usize)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[s_UInt_usize]_prog.Set_singleton_contains1|)))
(assert (forall ((r s_UInt_usize) (o s_UInt_usize)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[s_UInt_usize]_prog.Set_singleton_contains2|)))
(assert (forall ((r s_UInt_usize)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[s_UInt_usize]_prog.Set_singleton_card|)))
(assert (forall ((a Set<s_UInt_usize>) (x s_UInt_usize) (o s_UInt_usize)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[s_UInt_usize]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<s_UInt_usize>) (x s_UInt_usize)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[s_UInt_usize]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<s_UInt_usize>) (x s_UInt_usize) (y s_UInt_usize)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[s_UInt_usize]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<s_UInt_usize>) (x s_UInt_usize)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_UInt_usize]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<s_UInt_usize>) (x s_UInt_usize)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_UInt_usize]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (o s_UInt_usize)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[s_UInt_usize]_prog.Set_union_contains1|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (y s_UInt_usize)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[s_UInt_usize]_prog.Set_union_contains2|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (y s_UInt_usize)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[s_UInt_usize]_prog.Set_union_contains3|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (o s_UInt_usize)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[s_UInt_usize]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[s_UInt_usize]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[s_UInt_usize]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[s_UInt_usize]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[s_UInt_usize]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[s_UInt_usize]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (o s_UInt_usize)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[s_UInt_usize]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>) (y s_UInt_usize)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[s_UInt_usize]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[s_UInt_usize]_prog.Set_diff_card|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (=
    (Set_subset a b)
    (forall ((o s_UInt_usize)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[s_UInt_usize]_prog.Set_subset_def|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[s_UInt_usize]_prog.Set_equal_def|)))
(assert (forall ((a Set<s_UInt_usize>) (b Set<s_UInt_usize>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[s_UInt_usize]_prog.Set_equal_ext|)))
(assert (forall ((s Set<s_UInt_u32>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[s_UInt_u32]_prog.Set_card_nonneg|)))
(assert (forall ((o s_UInt_u32)) (!
  (not (Set_in o (as Set_empty  Set<s_UInt_u32>)))
  :pattern ((Set_in o (as Set_empty  Set<s_UInt_u32>)))
  :qid |$Set[s_UInt_u32]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<s_UInt_u32>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<s_UInt_u32>)))
    (=> (not (= (Set_card s) 0)) (exists ((x s_UInt_u32))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[s_UInt_u32]_prog.Set_card_zero|)))
(assert (forall ((r s_UInt_u32)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[s_UInt_u32]_prog.Set_singleton_contains1|)))
(assert (forall ((r s_UInt_u32) (o s_UInt_u32)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[s_UInt_u32]_prog.Set_singleton_contains2|)))
(assert (forall ((r s_UInt_u32)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[s_UInt_u32]_prog.Set_singleton_card|)))
(assert (forall ((a Set<s_UInt_u32>) (x s_UInt_u32) (o s_UInt_u32)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[s_UInt_u32]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<s_UInt_u32>) (x s_UInt_u32)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[s_UInt_u32]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<s_UInt_u32>) (x s_UInt_u32) (y s_UInt_u32)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[s_UInt_u32]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<s_UInt_u32>) (x s_UInt_u32)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_UInt_u32]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<s_UInt_u32>) (x s_UInt_u32)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[s_UInt_u32]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (o s_UInt_u32)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[s_UInt_u32]_prog.Set_union_contains1|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (y s_UInt_u32)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[s_UInt_u32]_prog.Set_union_contains2|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (y s_UInt_u32)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[s_UInt_u32]_prog.Set_union_contains3|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (o s_UInt_u32)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[s_UInt_u32]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[s_UInt_u32]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[s_UInt_u32]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[s_UInt_u32]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[s_UInt_u32]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[s_UInt_u32]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (o s_UInt_u32)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[s_UInt_u32]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>) (y s_UInt_u32)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[s_UInt_u32]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[s_UInt_u32]_prog.Set_diff_card|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (=
    (Set_subset a b)
    (forall ((o s_UInt_u32)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[s_UInt_u32]_prog.Set_subset_def|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[s_UInt_u32]_prog.Set_equal_def|)))
(assert (forall ((a Set<s_UInt_u32>) (b Set<s_UInt_u32>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[s_UInt_u32]_prog.Set_equal_ext|)))
(assert (forall ((s Set<Bool>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Bool]_prog.Set_card_nonneg|)))
(assert (forall ((o Bool)) (!
  (not (Set_in o (as Set_empty  Set<Bool>)))
  :pattern ((Set_in o (as Set_empty  Set<Bool>)))
  :qid |$Set[Bool]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Bool>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Bool>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Bool))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Bool]_prog.Set_card_zero|)))
(assert (forall ((r Bool)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Bool]_prog.Set_singleton_contains1|)))
(assert (forall ((r Bool) (o Bool)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Bool]_prog.Set_singleton_contains2|)))
(assert (forall ((r Bool)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Bool]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Bool>) (x Bool) (o Bool)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Bool]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Bool>) (x Bool)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Bool]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Bool>) (x Bool) (y Bool)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Bool]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Bool>) (x Bool)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Bool]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Bool>) (x Bool)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Bool]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Bool]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Bool]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Bool]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Bool]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Bool]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Bool]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Bool]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Bool]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Bool]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Bool]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Bool]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Bool]_prog.Set_diff_card|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (=
    (Set_subset a b)
    (forall ((o Bool)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Bool]_prog.Set_subset_def|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Bool]_prog.Set_equal_def|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Bool]_prog.Set_equal_ext|)))
(assert (forall ((s Set<$Snap>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Snap]_prog.Set_card_nonneg|)))
(assert (forall ((o $Snap)) (!
  (not (Set_in o (as Set_empty  Set<$Snap>)))
  :pattern ((Set_in o (as Set_empty  Set<$Snap>)))
  :qid |$Set[Snap]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Snap>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<$Snap>)))
    (=> (not (= (Set_card s) 0)) (exists ((x $Snap))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Snap]_prog.Set_card_zero|)))
(assert (forall ((r $Snap)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Snap]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Snap) (o $Snap)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Snap]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Snap)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Snap]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (o $Snap)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Snap]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Snap]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (y $Snap)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Snap]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Snap]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Snap]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Snap]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Snap]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Snap]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Snap]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Snap]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Snap]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Snap]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Snap]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Snap]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Snap]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Snap]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Snap]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (=
    (Set_subset a b)
    (forall ((o $Snap)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Snap]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Snap]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Snap]_prog.Set_equal_ext|)))
(assert (forall ((s s_UInt_u32)) (!
  (= (s_UInt_u32_cons<s_UInt_u32> (s_UInt_u32_value<Int> s)) s)
  :pattern ((s_UInt_u32_value<Int> s))
  :qid |prog.s_UInt_u32_ax_cons|)))
(assert (forall ((s s_UInt_u32)) (!
  (and
    (<= 0 (s_UInt_u32_value<Int> s))
    (<= (s_UInt_u32_value<Int> s) 4294967295))
  :pattern ((s_UInt_u32_value<Int> s))
  :qid |prog.s_UInt_u32_ax_bounds|)))
(assert (forall ((value Int)) (!
  (=>
    (and (<= 0 value) (<= value 4294967295))
    (= (s_UInt_u32_value<Int> (s_UInt_u32_cons<s_UInt_u32> value)) value))
  :pattern ((s_UInt_u32_cons<s_UInt_u32> value))
  :qid |prog.s_UInt_u32_ax_value|)))
(assert (= (s_0_Tuple_tag<Int> (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple)) 0))
(assert (forall ((t s_0_Tuple)) (!
  (= t (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple))
  :pattern ((s_0_Tuple_tag<Int> t))
  )))
(assert (forall ((s_visit$col$$col$$lc$closure$oc$0$rc$_0 s_Ref_immutable)) (!
  (=
    s_visit$col$$col$$lc$closure$oc$0$rc$_0
    (get_s_visit$col$$col$$lc$closure$oc$0$rc$_s_visit$col$$col$$lc$closure$oc$0$rc$_0<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> s_visit$col$$col$$lc$closure$oc$0$rc$_0)))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> s_visit$col$$col$$lc$closure$oc$0$rc$_0))
  )))
(assert (forall ((s_visit$col$$col$$lc$closure$oc$0$rc$_0 s_Ref_immutable)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$0$rc$_tag<Int> (s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> s_visit$col$$col$$lc$closure$oc$0$rc$_0))
    0)
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> s_visit$col$$col$$lc$closure$oc$0$rc$_0))
  )))
(assert (forall ((t s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
  (=
    t
    (s_visit$col$$col$$lc$closure$oc$0$rc$_cons<s_visit$col$$col$$lc$closure$oc$0$rc$> (get_s_visit$col$$col$$lc$closure$oc$0$rc$_s_visit$col$$col$$lc$closure$oc$0$rc$_0<s_Ref_immutable> t)))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_tag<Int> t))
  :pattern ((get_s_visit$col$$col$$lc$closure$oc$0$rc$_s_visit$col$$col$$lc$closure$oc$0$rc$_0<s_Ref_immutable> t))
  )))
(assert (forall ((s_Ref_mutable_0 $Ref) (s_Ref_mutable_1 s_Param) (s_Ref_mutable_2 s_Param)) (!
  (=
    s_Ref_mutable_0
    (get_s_Ref_mutable_s_Ref_mutable_0<Ref> (s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2)))
  :pattern ((s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2))
  )))
(assert (forall ((s_Ref_mutable_0 $Ref) (s_Ref_mutable_1 s_Param) (s_Ref_mutable_2 s_Param)) (!
  (=
    s_Ref_mutable_1
    (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> (s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2)))
  :pattern ((s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2))
  )))
(assert (forall ((s_Ref_mutable_0 $Ref) (s_Ref_mutable_1 s_Param) (s_Ref_mutable_2 s_Param)) (!
  (=
    s_Ref_mutable_2
    (get_s_Ref_mutable_s_Ref_mutable_2<s_Param> (s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2)))
  :pattern ((s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2))
  )))
(assert (forall ((s_Ref_mutable_0 $Ref) (s_Ref_mutable_1 s_Param) (s_Ref_mutable_2 s_Param)) (!
  (=
    (s_Ref_mutable_tag<Int> (s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2))
    0)
  :pattern ((s_Ref_mutable_cons<s_Ref_mutable> s_Ref_mutable_0 s_Ref_mutable_1 s_Ref_mutable_2))
  )))
(assert (forall ((t s_Ref_mutable)) (!
  (=
    t
    (s_Ref_mutable_cons<s_Ref_mutable> (get_s_Ref_mutable_s_Ref_mutable_0<Ref> t) (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> t) (get_s_Ref_mutable_s_Ref_mutable_2<s_Param> t)))
  :pattern ((s_Ref_mutable_tag<Int> t))
  :pattern ((get_s_Ref_mutable_s_Ref_mutable_0<Ref> t))
  :pattern ((get_s_Ref_mutable_s_Ref_mutable_1<s_Param> t))
  :pattern ((get_s_Ref_mutable_s_Ref_mutable_2<s_Param> t))
  )))
(assert (forall ((s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_Ref_immutable) (s_visit$col$$col$$lc$closure$oc$1$rc$_1 s_Ref_immutable)) (!
  (=
    s_visit$col$$col$$lc$closure$oc$1$rc$_0
    (get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_0<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1)))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1))
  )))
(assert (forall ((s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_Ref_immutable) (s_visit$col$$col$$lc$closure$oc$1$rc$_1 s_Ref_immutable)) (!
  (=
    s_visit$col$$col$$lc$closure$oc$1$rc$_1
    (get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_1<s_Ref_immutable> (s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1)))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1))
  )))
(assert (forall ((s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_Ref_immutable) (s_visit$col$$col$$lc$closure$oc$1$rc$_1 s_Ref_immutable)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$1$rc$_tag<Int> (s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1))
    0)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> s_visit$col$$col$$lc$closure$oc$1$rc$_0 s_visit$col$$col$$lc$closure$oc$1$rc$_1))
  )))
(assert (forall ((t s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
  (=
    t
    (s_visit$col$$col$$lc$closure$oc$1$rc$_cons<s_visit$col$$col$$lc$closure$oc$1$rc$> (get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_0<s_Ref_immutable> t) (get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_1<s_Ref_immutable> t)))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_tag<Int> t))
  :pattern ((get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_0<s_Ref_immutable> t))
  :pattern ((get_s_visit$col$$col$$lc$closure$oc$1$rc$_s_visit$col$$col$$lc$closure$oc$1$rc$_1<s_Ref_immutable> t))
  )))
(assert (and (< $Perm.No (as read<Perm>  $Perm)) (< (as read<Perm>  $Perm) $Perm.Write)))
(assert (forall ((x s_0_Tuple)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_0_Tuple<s_Param> x))
    (as s_0_Tuple_type<Type>  Type))
  :pattern ((make_generic_s_0_Tuple<s_Param> x))
  :qid |prog.s_Param_typ_def_make_generic_s_0_Tuple|)))
(assert (forall ((p s_Param)) (!
  (=>
    (= (s_Param_typ<Type> p) (as s_0_Tuple_type<Type>  Type))
    (=
      (make_generic_s_0_Tuple<s_Param> (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple))
      p))
  :pattern ((s_Param_has_typ<Bool> p (as s_0_Tuple_type<Type>  Type)))
  :qid |prog.s_Param_typ_variant_make_generic_s_0_Tuple|)))
(assert (forall ((p s_Param)) (!
  (=
    (get_s_Param_make_concrete_s_0_Tuple<s_0_Tuple> p)
    (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple))
  :pattern ((get_s_Param_make_concrete_s_0_Tuple<s_0_Tuple> p))
  :qid |prog.make_generic_s_0_Tuple_unit|)))
(assert (forall ((U$1 Type)) (!
  (std$col$$col$marker$col$$col$Sized_impl<Bool> (s_Ref_mutable_type<Type> U$1))
  :pattern ((std$col$$col$marker$col$$col$Sized_impl<Bool> (s_Ref_mutable_type<Type> U$1)))
  :qid |prog.s_Ref_mutable_Sized|)))
(assert (forall ((U$1 Type)) (!
  (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Ref_mutable_type<Type> U$1))
  :pattern ((std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Ref_mutable_type<Type> U$1)))
  :qid |prog.s_Ref_mutable_MetaSized|)))
(assert (forall ((x s_Slice) (T$0 Type)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_Slice<s_Param> x T$0))
    (s_Slice_type<Type> T$0))
  :pattern ((make_generic_s_Slice<s_Param> x T$0))
  :qid |prog.s_Param_typ_def_make_generic_s_Slice|)))
(assert (forall ((p s_Param)) (!
  (=>
    (=
      (s_Param_typ<Type> p)
      (s_Slice_type<Type> (get_Type_s_Slice_typaram_T$0<Type> (s_Param_typ<Type> p))))
    (=
      (make_generic_s_Slice<s_Param> (get_s_Param_make_concrete_s_Slice<s_Slice> p) (get_Type_s_Slice_typaram_T$0<Type> (s_Param_typ<Type> p)))
      p))
  :pattern ((get_s_Param_make_concrete_s_Slice<s_Slice> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_Slice|)))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_UInt_u32_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_UInt_u32_type<Type>  Type)))
(assert (forall ((s_Ref_mutable_typaram_U$1 Type)) (!
  (=
    s_Ref_mutable_typaram_U$1
    (get_Type_s_Ref_mutable_typaram_U$1<Type> (s_Ref_mutable_type<Type> s_Ref_mutable_typaram_U$1)))
  :pattern ((s_Ref_mutable_type<Type> s_Ref_mutable_typaram_U$1))
  )))
(assert (forall ((s_Slice_typaram_T$0 Type)) (!
  (=
    s_Slice_typaram_T$0
    (get_Type_s_Slice_typaram_T$0<Type> (s_Slice_type<Type> s_Slice_typaram_T$0)))
  :pattern ((s_Slice_type<Type> s_Slice_typaram_T$0))
  )))
(assert (forall ((s_Ref_immutable_typaram_U$1 Type)) (!
  (=
    s_Ref_immutable_typaram_U$1
    (get_Type_s_Ref_immutable_typaram_U$1<Type> (s_Ref_immutable_type<Type> s_Ref_immutable_typaram_U$1)))
  :pattern ((s_Ref_immutable_type<Type> s_Ref_immutable_typaram_U$1))
  )))
(assert (forall ((s_RawPtr_immutable_typaram_T$0 Type)) (!
  (=
    s_RawPtr_immutable_typaram_T$0
    (get_Type_s_RawPtr_immutable_typaram_T$0<Type> (s_RawPtr_immutable_type<Type> s_RawPtr_immutable_typaram_T$0)))
  :pattern ((s_RawPtr_immutable_type<Type> s_RawPtr_immutable_typaram_T$0))
  )))
(assert (forall ((id Int)) (!
  (= id (get_Type_id<Int> (Unknown_type<Type> id)))
  :pattern ((Unknown_type<Type> id))
  )))
(assert (= (Type_tag<Int> (as s_0_Tuple_type<Type>  Type)) 1))
(assert (forall ((s_Ref_mutable_typaram_U$1 Type)) (!
  (= (Type_tag<Int> (s_Ref_mutable_type<Type> s_Ref_mutable_typaram_U$1)) 5)
  :pattern ((s_Ref_mutable_type<Type> s_Ref_mutable_typaram_U$1))
  )))
(assert (forall ((s_Slice_typaram_T$0 Type)) (!
  (= (Type_tag<Int> (s_Slice_type<Type> s_Slice_typaram_T$0)) 6)
  :pattern ((s_Slice_type<Type> s_Slice_typaram_T$0))
  )))
(assert (= (Type_tag<Int> (as s_UInt_u32_type<Type>  Type)) 7))
(assert (= (Type_tag<Int> (as s_UInt_usize_type<Type>  Type)) 8))
(assert (forall ((s_Ref_immutable_typaram_U$1 Type)) (!
  (= (Type_tag<Int> (s_Ref_immutable_type<Type> s_Ref_immutable_typaram_U$1)) 4)
  :pattern ((s_Ref_immutable_type<Type> s_Ref_immutable_typaram_U$1))
  )))
(assert (forall ((s_RawPtr_immutable_typaram_T$0 Type)) (!
  (=
    (Type_tag<Int> (s_RawPtr_immutable_type<Type> s_RawPtr_immutable_typaram_T$0))
    3)
  :pattern ((s_RawPtr_immutable_type<Type> s_RawPtr_immutable_typaram_T$0))
  )))
(assert (= (Type_tag<Int> (as s_Bool_type<Type>  Type)) 2))
(assert (= (Type_tag<Int> (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type)) 9))
(assert (=
  (Type_tag<Int> (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type))
  10))
(assert (forall ((id Int)) (!
  (= (Type_tag<Int> (Unknown_type<Type> id)) 0)
  :pattern ((Unknown_type<Type> id))
  )))
(assert (forall ((t Type)) (!
  (or
    (or
      (or
        (or
          (or
            (or
              (or
                (or
                  (or
                    (or
                      (= t (as s_0_Tuple_type<Type>  Type))
                      (=
                        t
                        (s_Ref_mutable_type<Type> (get_Type_s_Ref_mutable_typaram_U$1<Type> t))))
                    (=
                      t
                      (s_Slice_type<Type> (get_Type_s_Slice_typaram_T$0<Type> t))))
                  (= t (as s_UInt_u32_type<Type>  Type)))
                (= t (as s_UInt_usize_type<Type>  Type)))
              (=
                t
                (s_Ref_immutable_type<Type> (get_Type_s_Ref_immutable_typaram_U$1<Type> t))))
            (=
              t
              (s_RawPtr_immutable_type<Type> (get_Type_s_RawPtr_immutable_typaram_T$0<Type> t))))
          (= t (as s_Bool_type<Type>  Type)))
        (= t (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type)))
      (= t (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type)))
    (= t (Unknown_type<Type> (get_Type_id<Int> t))))
  :pattern ((Type_tag<Int> t))
  :pattern ((get_Type_id<Int> t))
  )))
(assert (inhabited<Bool> (as s_0_Tuple_type<Type>  Type)))
(assert (forall ((U$1 Type)) (!
  (= (inhabited<Bool> (s_Ref_mutable_type<Type> U$1)) (inhabited<Bool> U$1))
  :pattern ((inhabited<Bool> (s_Ref_mutable_type<Type> U$1)))
  :qid |prog.inhabited_Ref_mutable|)))
(assert (forall ((T$0 Type)) (!
  (inhabited<Bool> (s_Slice_type<Type> T$0))
  :pattern ((inhabited<Bool> (s_Slice_type<Type> T$0)))
  :qid |prog.inhabited_Slice|)))
(assert (inhabited<Bool> (as s_UInt_u32_type<Type>  Type)))
(assert (inhabited<Bool> (as s_UInt_usize_type<Type>  Type)))
(assert (forall ((U$1 Type)) (!
  (= (inhabited<Bool> (s_Ref_immutable_type<Type> U$1)) (inhabited<Bool> U$1))
  :pattern ((inhabited<Bool> (s_Ref_immutable_type<Type> U$1)))
  :qid |prog.inhabited_Ref_immutable|)))
(assert (forall ((T$0 Type)) (!
  (inhabited<Bool> (s_RawPtr_immutable_type<Type> T$0))
  :pattern ((inhabited<Bool> (s_RawPtr_immutable_type<Type> T$0)))
  :qid |prog.inhabited_RawPtr_immutable|)))
(assert (inhabited<Bool> (as s_Bool_type<Type>  Type)))
(assert (forall ((x s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> x))
    (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type))
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> x))
  :qid |prog.s_Param_typ_def_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$|)))
(assert (forall ((p s_Param)) (!
  (=>
    (=
      (s_Param_typ<Type> p)
      (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type))
    (=
      (make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$<s_visit$col$$col$$lc$closure$oc$0$rc$> p))
      p))
  :pattern ((get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$<s_visit$col$$col$$lc$closure$oc$0$rc$> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$|)))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_0_Tuple_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_0_Tuple_type<Type>  Type)))
(assert (forall ((s_Ref_immutable_0 $Ref) (s_Ref_immutable_1 s_Param) (s_Ref_immutable_2 s_Param)) (!
  (=
    s_Ref_immutable_0
    (get_s_Ref_immutable_s_Ref_immutable_0<Ref> (s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2)))
  :pattern ((s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2))
  )))
(assert (forall ((s_Ref_immutable_0 $Ref) (s_Ref_immutable_1 s_Param) (s_Ref_immutable_2 s_Param)) (!
  (=
    s_Ref_immutable_1
    (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> (s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2)))
  :pattern ((s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2))
  )))
(assert (forall ((s_Ref_immutable_0 $Ref) (s_Ref_immutable_1 s_Param) (s_Ref_immutable_2 s_Param)) (!
  (=
    s_Ref_immutable_2
    (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> (s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2)))
  :pattern ((s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2))
  )))
(assert (forall ((s_Ref_immutable_0 $Ref) (s_Ref_immutable_1 s_Param) (s_Ref_immutable_2 s_Param)) (!
  (=
    (s_Ref_immutable_tag<Int> (s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2))
    0)
  :pattern ((s_Ref_immutable_cons<s_Ref_immutable> s_Ref_immutable_0 s_Ref_immutable_1 s_Ref_immutable_2))
  )))
(assert (forall ((t s_Ref_immutable)) (!
  (=
    t
    (s_Ref_immutable_cons<s_Ref_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> t) (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> t) (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> t)))
  :pattern ((s_Ref_immutable_tag<Int> t))
  :pattern ((get_s_Ref_immutable_s_Ref_immutable_0<Ref> t))
  :pattern ((get_s_Ref_immutable_s_Ref_immutable_1<s_Param> t))
  :pattern ((get_s_Ref_immutable_s_Ref_immutable_2<s_Param> t))
  )))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_UInt_usize_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_UInt_usize_type<Type>  Type)))
(assert (forall ((x s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> x))
    (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type))
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> x))
  :qid |prog.s_Param_typ_def_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$|)))
(assert (forall ((p s_Param)) (!
  (=>
    (=
      (s_Param_typ<Type> p)
      (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type))
    (=
      (make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$<s_visit$col$$col$$lc$closure$oc$1$rc$> p))
      p))
  :pattern ((get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$<s_visit$col$$col$$lc$closure$oc$1$rc$> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$|)))
(assert (forall ((x s_UInt_usize)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_UInt_usize<s_Param> x))
    (as s_UInt_usize_type<Type>  Type))
  :pattern ((make_generic_s_UInt_usize<s_Param> x))
  :qid |prog.s_Param_typ_def_make_generic_s_UInt_usize|)))
(assert (forall ((p s_Param)) (!
  (=>
    (= (s_Param_typ<Type> p) (as s_UInt_usize_type<Type>  Type))
    (=
      (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> p))
      p))
  :pattern ((get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_UInt_usize|)))
(assert (forall ((U$1 Type)) (!
  (std$col$$col$marker$col$$col$Sized_impl<Bool> (s_Ref_immutable_type<Type> U$1))
  :pattern ((std$col$$col$marker$col$$col$Sized_impl<Bool> (s_Ref_immutable_type<Type> U$1)))
  :qid |prog.s_Ref_immutable_Sized|)))
(assert (forall ((U$1 Type)) (!
  (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Ref_immutable_type<Type> U$1))
  :pattern ((std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Ref_immutable_type<Type> U$1)))
  :qid |prog.s_Ref_immutable_MetaSized|)))
(assert (forall ((x s_Ref_mutable) (U$1 Type)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_Ref_mutable<s_Param> x U$1))
    (s_Ref_mutable_type<Type> U$1))
  :pattern ((make_generic_s_Ref_mutable<s_Param> x U$1))
  :qid |prog.s_Param_typ_def_make_generic_s_Ref_mutable|)))
(assert (forall ((p s_Param)) (!
  (=>
    (=
      (s_Param_typ<Type> p)
      (s_Ref_mutable_type<Type> (get_Type_s_Ref_mutable_typaram_U$1<Type> (s_Param_typ<Type> p))))
    (=
      (make_generic_s_Ref_mutable<s_Param> (get_s_Param_make_concrete_s_Ref_mutable<s_Ref_mutable> p) (get_Type_s_Ref_mutable_typaram_U$1<Type> (s_Param_typ<Type> p)))
      p))
  :pattern ((get_s_Param_make_concrete_s_Ref_mutable<s_Ref_mutable> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_Ref_mutable|)))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_visit$col$$col$$lc$closure$oc$1$rc$_type<Type>  Type)))
(assert (forall ((s Seq<s_Param>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (s_Slice_index<s_Param> (s_Slice_from_seq<s_Slice> s) i) (Seq_index s i)))
  :pattern ((s_Slice_index<s_Param> (s_Slice_from_seq<s_Slice> s) i))
  :qid |prog.s_Slice_ax_from_seq|)))
(assert (forall ((s s_Slice) (n Int)) (!
  (=> (<= 0 n) (= (Seq_length (s_Slice_to_seq<Seq<s_Param>> s n)) n))
  :pattern ((s_Slice_to_seq<Seq<s_Param>> s n))
  :qid |prog.s_Slice_ax_to_seq_len|)))
(assert (forall ((s s_Slice) (n Int) (i Int)) (!
  (=>
    (and (<= 0 i) (< i n))
    (=
      (Seq_index (s_Slice_to_seq<Seq<s_Param>> s n) i)
      (s_Slice_index<s_Param> s i)))
  :pattern ((Seq_index (s_Slice_to_seq<Seq<s_Param>> s n) i))
  :pattern ((s_Slice_index<s_Param> s i) (s_Slice_to_seq<Seq<s_Param>> s n))
  :qid |prog.s_Slice_ax_to_seq_index|)))
(assert (forall ((Self$0_trait Type)) (!
  (=>
    (std$col$$col$marker$col$$col$Sized_impl<Bool> Self$0_trait)
    (=
      (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> Self$0_trait)
      (as s_0_Tuple_type<Type>  Type)))
  :pattern ((std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> Self$0_trait))
  :qid |prog.std$col$$col$ptr$col$$col$Pointee_sized_metadata|)))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_visit$col$$col$$lc$closure$oc$0$rc$_type<Type>  Type)))
(assert (forall ((x s_UInt_u32)) (!
  (=
    (s_Param_typ<Type> (make_generic_s_UInt_u32<s_Param> x))
    (as s_UInt_u32_type<Type>  Type))
  :pattern ((make_generic_s_UInt_u32<s_Param> x))
  :qid |prog.s_Param_typ_def_make_generic_s_UInt_u32|)))
(assert (forall ((p s_Param)) (!
  (=>
    (= (s_Param_typ<Type> p) (as s_UInt_u32_type<Type>  Type))
    (=
      (make_generic_s_UInt_u32<s_Param> (get_s_Param_make_concrete_s_UInt_u32<s_UInt_u32> p))
      p))
  :pattern ((get_s_Param_make_concrete_s_UInt_u32<s_UInt_u32> p) (s_Param_typ<Type> p))
  :qid |prog.s_Param_typ_variant_make_generic_s_UInt_u32|)))
(assert (forall ((T$0 Type)) (!
  (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Slice_type<Type> T$0))
  :pattern ((std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_Slice_type<Type> T$0)))
  :qid |prog.s_Slice_MetaSized|)))
(assert (forall ((p s_Param)) (!
  (s_Param_has_typ<Bool> p (s_Param_typ<Type> p))
  :pattern ((s_Param_typ<Type> p))
  :qid |prog.s_Param_has_typ_own|)))
(assert (std$col$$col$marker$col$$col$Sized_impl<Bool> (as s_Bool_type<Type>  Type)))
(assert (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (as s_Bool_type<Type>  Type)))
(assert (forall ((s_RawPtr_immutable_0 $Ref) (s_RawPtr_immutable_1 s_Param)) (!
  (=
    s_RawPtr_immutable_0
    (get_s_RawPtr_immutable_s_RawPtr_immutable_0<Ref> (s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1)))
  :pattern ((s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1))
  )))
(assert (forall ((s_RawPtr_immutable_0 $Ref) (s_RawPtr_immutable_1 s_Param)) (!
  (=
    s_RawPtr_immutable_1
    (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> (s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1)))
  :pattern ((s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1))
  )))
(assert (forall ((s_RawPtr_immutable_0 $Ref) (s_RawPtr_immutable_1 s_Param)) (!
  (=
    (s_RawPtr_immutable_tag<Int> (s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1))
    0)
  :pattern ((s_RawPtr_immutable_cons<s_RawPtr_immutable> s_RawPtr_immutable_0 s_RawPtr_immutable_1))
  )))
(assert (forall ((t s_RawPtr_immutable)) (!
  (=
    t
    (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_RawPtr_immutable_s_RawPtr_immutable_0<Ref> t) (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> t)))
  :pattern ((s_RawPtr_immutable_tag<Int> t))
  :pattern ((get_s_RawPtr_immutable_s_RawPtr_immutable_0<Ref> t))
  :pattern ((get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> t))
  )))
(assert (forall ((s s_UInt_usize)) (!
  (= (s_UInt_usize_cons<s_UInt_usize> (s_UInt_usize_value<Int> s)) s)
  :pattern ((s_UInt_usize_value<Int> s))
  :qid |prog.s_UInt_usize_ax_cons|)))
(assert (forall ((s s_UInt_usize)) (!
  (and
    (<= 0 (s_UInt_usize_value<Int> s))
    (<= (s_UInt_usize_value<Int> s) 18446744073709551615))
  :pattern ((s_UInt_usize_value<Int> s))
  :qid |prog.s_UInt_usize_ax_bounds|)))
(assert (forall ((value Int)) (!
  (=>
    (and (<= 0 value) (<= value 18446744073709551615))
    (= (s_UInt_usize_value<Int> (s_UInt_usize_cons<s_UInt_usize> value)) value))
  :pattern ((s_UInt_usize_cons<s_UInt_usize> value))
  :qid |prog.s_UInt_usize_ax_value|)))
(assert (forall ((T$0 Type)) (!
  (std$col$$col$marker$col$$col$Sized_impl<Bool> (s_RawPtr_immutable_type<Type> T$0))
  :pattern ((std$col$$col$marker$col$$col$Sized_impl<Bool> (s_RawPtr_immutable_type<Type> T$0)))
  :qid |prog.s_RawPtr_immutable_Sized|)))
(assert (forall ((T$0 Type)) (!
  (std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_RawPtr_immutable_type<Type> T$0))
  :pattern ((std$col$$col$marker$col$$col$MetaSized_impl<Bool> (s_RawPtr_immutable_type<Type> T$0)))
  :qid |prog.s_RawPtr_immutable_MetaSized|)))
(assert (forall ((resource_stored s_Param) (resource_nested s_ResourceState)) (!
  (=
    resource_stored
    (get_s_ResourceState_resource_stored<s_Param> (ResourceReference<s_ResourceState> resource_stored resource_nested)))
  :pattern ((ResourceReference<s_ResourceState> resource_stored resource_nested))
  )))
(assert (forall ((resource_stored s_Param) (resource_nested s_ResourceState)) (!
  (=
    resource_nested
    (get_s_ResourceState_resource_nested<s_ResourceState> (ResourceReference<s_ResourceState> resource_stored resource_nested)))
  :pattern ((ResourceReference<s_ResourceState> resource_stored resource_nested))
  )))
(assert (forall ((resource_fields Seq<s_ResourceState>)) (!
  (Seq_equal
    resource_fields
    (get_s_ResourceState_resource_fields<Seq<s_ResourceState>> (ResourceFields<s_ResourceState> resource_fields)))
  :pattern ((ResourceFields<s_ResourceState> resource_fields))
  )))
(assert (forall ((resource_unknown Int)) (!
  (=
    resource_unknown
    (get_s_ResourceState_resource_unknown<Int> (ResourceUnknown<s_ResourceState> resource_unknown)))
  :pattern ((ResourceUnknown<s_ResourceState> resource_unknown))
  )))
(assert (=
  (s_ResourceState_tag<Int> (as ResourceEmpty<s_ResourceState>  s_ResourceState))
  0))
(assert (forall ((resource_stored s_Param) (resource_nested s_ResourceState)) (!
  (=
    (s_ResourceState_tag<Int> (ResourceReference<s_ResourceState> resource_stored resource_nested))
    2)
  :pattern ((ResourceReference<s_ResourceState> resource_stored resource_nested))
  )))
(assert (forall ((resource_fields Seq<s_ResourceState>)) (!
  (=
    (s_ResourceState_tag<Int> (ResourceFields<s_ResourceState> resource_fields))
    1)
  :pattern ((ResourceFields<s_ResourceState> resource_fields))
  )))
(assert (forall ((resource_unknown Int)) (!
  (=
    (s_ResourceState_tag<Int> (ResourceUnknown<s_ResourceState> resource_unknown))
    3)
  :pattern ((ResourceUnknown<s_ResourceState> resource_unknown))
  )))
(assert (forall ((t s_ResourceState)) (!
  (or
    (or
      (or
        (= t (as ResourceEmpty<s_ResourceState>  s_ResourceState))
        (=
          t
          (ResourceReference<s_ResourceState> (get_s_ResourceState_resource_stored<s_Param> t) (get_s_ResourceState_resource_nested<s_ResourceState> t))))
      (=
        t
        (ResourceFields<s_ResourceState> (get_s_ResourceState_resource_fields<Seq<s_ResourceState>> t))))
    (=
      t
      (ResourceUnknown<s_ResourceState> (get_s_ResourceState_resource_unknown<Int> t))))
  :pattern ((s_ResourceState_tag<Int> t))
  :pattern ((get_s_ResourceState_resource_unknown<Int> t))
  )))
(assert (forall ((make_concrete_s_Slice s_Slice) (make_generic_s_Slice_typaram_T$0 Type)) (!
  (=
    make_concrete_s_Slice
    (get_s_Param_make_concrete_s_Slice<s_Slice> (make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0)))
  :pattern ((make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0))
  )))
(assert (forall ((make_concrete_s_Slice s_Slice) (make_generic_s_Slice_typaram_T$0 Type)) (!
  (=
    make_generic_s_Slice_typaram_T$0
    (get_s_Param_make_generic_s_Slice_typaram_T$0<Type> (make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0)))
  :pattern ((make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0))
  )))
(assert (forall ((make_concrete_s_UInt_usize s_UInt_usize)) (!
  (=
    make_concrete_s_UInt_usize
    (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (make_generic_s_UInt_usize<s_Param> make_concrete_s_UInt_usize)))
  :pattern ((make_generic_s_UInt_usize<s_Param> make_concrete_s_UInt_usize))
  )))
(assert (forall ((make_concrete_s_0_Tuple s_0_Tuple)) (!
  (=
    make_concrete_s_0_Tuple
    (get_s_Param_make_concrete_s_0_Tuple<s_0_Tuple> (make_generic_s_0_Tuple<s_Param> make_concrete_s_0_Tuple)))
  :pattern ((make_generic_s_0_Tuple<s_Param> make_concrete_s_0_Tuple))
  )))
(assert (forall ((make_concrete_s_Ref_mutable s_Ref_mutable) (make_generic_s_Ref_mutable_typaram_U$1 Type)) (!
  (=
    make_concrete_s_Ref_mutable
    (get_s_Param_make_concrete_s_Ref_mutable<s_Ref_mutable> (make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1)))
  :pattern ((make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1))
  )))
(assert (forall ((make_concrete_s_Ref_mutable s_Ref_mutable) (make_generic_s_Ref_mutable_typaram_U$1 Type)) (!
  (=
    make_generic_s_Ref_mutable_typaram_U$1
    (get_s_Param_make_generic_s_Ref_mutable_typaram_U$1<Type> (make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1)))
  :pattern ((make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1))
  )))
(assert (forall ((make_concrete_s_UInt_u32 s_UInt_u32)) (!
  (=
    make_concrete_s_UInt_u32
    (get_s_Param_make_concrete_s_UInt_u32<s_UInt_u32> (make_generic_s_UInt_u32<s_Param> make_concrete_s_UInt_u32)))
  :pattern ((make_generic_s_UInt_u32<s_Param> make_concrete_s_UInt_u32))
  )))
(assert (forall ((make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$ s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
  (=
    make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$
    (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$<s_visit$col$$col$$lc$closure$oc$0$rc$> (make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$)))
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$))
  )))
(assert (forall ((make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$ s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
  (=
    make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$
    (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$<s_visit$col$$col$$lc$closure$oc$1$rc$> (make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$)))
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$))
  )))
(assert (forall ((s_Param_Unknown_id Int)) (!
  (=
    s_Param_Unknown_id
    (get_s_Param_s_Param_Unknown_id<Int> (s_Param_Unknown<s_Param> s_Param_Unknown_id)))
  :pattern ((s_Param_Unknown<s_Param> s_Param_Unknown_id))
  )))
(assert (forall ((make_concrete_s_Slice s_Slice) (make_generic_s_Slice_typaram_T$0 Type)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0))
    2)
  :pattern ((make_generic_s_Slice<s_Param> make_concrete_s_Slice make_generic_s_Slice_typaram_T$0))
  )))
(assert (forall ((make_concrete_s_UInt_usize s_UInt_usize)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_UInt_usize<s_Param> make_concrete_s_UInt_usize))
    4)
  :pattern ((make_generic_s_UInt_usize<s_Param> make_concrete_s_UInt_usize))
  )))
(assert (forall ((make_concrete_s_0_Tuple s_0_Tuple)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_0_Tuple<s_Param> make_concrete_s_0_Tuple))
    0)
  :pattern ((make_generic_s_0_Tuple<s_Param> make_concrete_s_0_Tuple))
  )))
(assert (forall ((make_concrete_s_Ref_mutable s_Ref_mutable) (make_generic_s_Ref_mutable_typaram_U$1 Type)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1))
    1)
  :pattern ((make_generic_s_Ref_mutable<s_Param> make_concrete_s_Ref_mutable make_generic_s_Ref_mutable_typaram_U$1))
  )))
(assert (forall ((make_concrete_s_UInt_u32 s_UInt_u32)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_UInt_u32<s_Param> make_concrete_s_UInt_u32))
    3)
  :pattern ((make_generic_s_UInt_u32<s_Param> make_concrete_s_UInt_u32))
  )))
(assert (forall ((make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$ s_visit$col$$col$$lc$closure$oc$0$rc$)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$))
    5)
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$))
  )))
(assert (forall ((make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$ s_visit$col$$col$$lc$closure$oc$1$rc$)) (!
  (=
    (s_Param_tag<Int> (make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$))
    6)
  :pattern ((make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$))
  )))
(assert (forall ((s_Param_Unknown_id Int)) (!
  (= (s_Param_tag<Int> (s_Param_Unknown<s_Param> s_Param_Unknown_id)) 7)
  :pattern ((s_Param_Unknown<s_Param> s_Param_Unknown_id))
  )))
(assert (forall ((t s_Param)) (!
  (or
    (or
      (or
        (or
          (or
            (or
              (or
                (=
                  t
                  (make_generic_s_Slice<s_Param> (get_s_Param_make_concrete_s_Slice<s_Slice> t) (get_s_Param_make_generic_s_Slice_typaram_T$0<Type> t)))
                (=
                  t
                  (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> t))))
              (=
                t
                (make_generic_s_0_Tuple<s_Param> (get_s_Param_make_concrete_s_0_Tuple<s_0_Tuple> t))))
            (=
              t
              (make_generic_s_Ref_mutable<s_Param> (get_s_Param_make_concrete_s_Ref_mutable<s_Ref_mutable> t) (get_s_Param_make_generic_s_Ref_mutable_typaram_U$1<Type> t))))
          (=
            t
            (make_generic_s_UInt_u32<s_Param> (get_s_Param_make_concrete_s_UInt_u32<s_UInt_u32> t))))
        (=
          t
          (make_generic_s_visit$col$$col$$lc$closure$oc$0$rc$<s_Param> (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$0$rc$<s_visit$col$$col$$lc$closure$oc$0$rc$> t))))
      (=
        t
        (make_generic_s_visit$col$$col$$lc$closure$oc$1$rc$<s_Param> (get_s_Param_make_concrete_s_visit$col$$col$$lc$closure$oc$1$rc$<s_visit$col$$col$$lc$closure$oc$1$rc$> t))))
    (= t (s_Param_Unknown<s_Param> (get_s_Param_s_Param_Unknown_id<Int> t))))
  :pattern ((s_Param_tag<Int> t))
  :pattern ((get_s_Param_s_Param_Unknown_id<Int> t))
  )))
; /predicate_snap_functions_axioms.smt2 [indexed_p_Param: Snap]
(assert (forall ((vs $PSF<indexed_p_Param>) (ws $PSF<indexed_p_Param>)) (!
    (=>
      (and
        (Set_equal ($PSF.domain_indexed_p_Param vs) ($PSF.domain_indexed_p_Param ws))
        (forall ((x $Snap)) (!
          (=>
            (Set_in x ($PSF.domain_indexed_p_Param vs))
            (= ($PSF.lookup_indexed_p_Param vs x) ($PSF.lookup_indexed_p_Param ws x)))
          :pattern (($PSF.lookup_indexed_p_Param vs x) ($PSF.lookup_indexed_p_Param ws x))
          :qid |qp.$PSF<indexed_p_Param>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$PSF<indexed_p_Param>To$Snap vs) ($PSF.has_domain_indexed_p_Param vs)
              ($SortWrappers.$PSF<indexed_p_Param>To$Snap ws) ($PSF.has_domain_indexed_p_Param ws)
              )
    :qid |qp.$PSF<indexed_p_Param>-eq-outer|
    )))
(assert (forall ((s $Snap) (pm $PPM)) (!
    ($Perm.isValidVar ($PSF.perm_indexed_p_Param pm s))
    :pattern (($PSF.perm_indexed_p_Param pm s))
    :qid |qp.$PSF<indexed_p_Param>-validvar|)))
(assert (forall ((s $Snap) (f $Snap)) (!
    (= ($PSF.loc_indexed_p_Param f s) true)
    :pattern (($PSF.loc_indexed_p_Param f s))
    :qid |qp.$PSF<indexed_p_Param>-loc|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 1000000)
(check-sat)
; unknown
; ---------- FUNCTION mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize----------
(declare-fun arg@0@00 () s_RawPtr_immutable)
(declare-fun result@1@00 () s_UInt_usize)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg@0@00 s_RawPtr_immutable)) (!
  (=
    (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%limited s@$ arg@0@00)
    (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize s@$ arg@0@00))
  :pattern ((mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize s@$ arg@0@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (arg@0@00 s_RawPtr_immutable)) (!
  (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%stateless arg@0@00)
  :pattern ((mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%limited s@$ arg@0@00))
  :qid |quant-u-1|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] get_s_Param_make_concrete_s_UInt_usize(get_s_RawPtr_immutable_s_RawPtr_immutable_1(arg))
; [eval] get_s_RawPtr_immutable_s_RawPtr_immutable_1(arg)
(assert (=
  result@1@00
  (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> arg@0@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg@0@00 s_RawPtr_immutable)) (!
  (=>
    (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition s@$ arg@0@00)
    (=
      (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize s@$ arg@0@00)
      (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> arg@0@00))))
  :pattern ((mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize s@$ arg@0@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (arg@0@00 s_RawPtr_immutable)) (!
  true
  :pattern ((mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize s@$ arg@0@00))
  :qid |quant-u-67|)))
; ---------- FUNCTION mir_binop_Eq_UInt_usize_UInt_usize----------
(declare-fun arg1@2@00 () s_UInt_usize)
(declare-fun arg2@3@00 () s_UInt_usize)
(declare-fun result@4@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@2@00 s_UInt_usize) (arg2@3@00 s_UInt_usize)) (!
  (=
    (mir_binop_Eq_UInt_usize_UInt_usize%limited s@$ arg1@2@00 arg2@3@00)
    (mir_binop_Eq_UInt_usize_UInt_usize s@$ arg1@2@00 arg2@3@00))
  :pattern ((mir_binop_Eq_UInt_usize_UInt_usize s@$ arg1@2@00 arg2@3@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (arg1@2@00 s_UInt_usize) (arg2@3@00 s_UInt_usize)) (!
  (mir_binop_Eq_UInt_usize_UInt_usize%stateless arg1@2@00 arg2@3@00)
  :pattern ((mir_binop_Eq_UInt_usize_UInt_usize%limited s@$ arg1@2@00 arg2@3@00))
  :qid |quant-u-3|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] s_UInt_usize_value(arg1) == s_UInt_usize_value(arg2)
; [eval] s_UInt_usize_value(arg1)
; [eval] s_UInt_usize_value(arg2)
(assert (=
  result@4@00
  (= (s_UInt_usize_value<Int> arg1@2@00) (s_UInt_usize_value<Int> arg2@3@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@2@00 s_UInt_usize) (arg2@3@00 s_UInt_usize)) (!
  (=>
    (mir_binop_Eq_UInt_usize_UInt_usize%precondition s@$ arg1@2@00 arg2@3@00)
    (=
      (mir_binop_Eq_UInt_usize_UInt_usize s@$ arg1@2@00 arg2@3@00)
      (= (s_UInt_usize_value<Int> arg1@2@00) (s_UInt_usize_value<Int> arg2@3@00))))
  :pattern ((mir_binop_Eq_UInt_usize_UInt_usize s@$ arg1@2@00 arg2@3@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (arg1@2@00 s_UInt_usize) (arg2@3@00 s_UInt_usize)) (!
  true
  :pattern ((mir_binop_Eq_UInt_usize_UInt_usize s@$ arg1@2@00 arg2@3@00))
  :qid |quant-u-69|)))
; ---------- FUNCTION p_Param_snap----------
(declare-fun self@5@00 () $Ref)
(declare-fun T$0@6@00 () Type)
(declare-fun result@7@00 () s_Param)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@76@00 $Snap)
(assert (= $t@76@00 $Snap.unit))
; [eval] s_Param_typ(result) == T$0
; [eval] s_Param_typ(result)
(assert (= (s_Param_typ<Type> result@7@00) T$0@6@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@5@00 $Ref) (T$0@6@00 Type)) (!
  (=
    (p_Param_snap%limited s@$ self@5@00 T$0@6@00)
    (p_Param_snap s@$ self@5@00 T$0@6@00))
  :pattern ((p_Param_snap s@$ self@5@00 T$0@6@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (self@5@00 $Ref) (T$0@6@00 Type)) (!
  (p_Param_snap%stateless self@5@00 T$0@6@00)
  :pattern ((p_Param_snap%limited s@$ self@5@00 T$0@6@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (self@5@00 $Ref) (T$0@6@00 Type)) (!
  (let ((result@7@00 (p_Param_snap%limited s@$ self@5@00 T$0@6@00))) (=>
    (p_Param_snap%precondition s@$ self@5@00 T$0@6@00)
    (= (s_Param_typ<Type> result@7@00) T$0@6@00)))
  :pattern ((p_Param_snap%limited s@$ self@5@00 T$0@6@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (self@5@00 $Ref) (T$0@6@00 Type)) (!
  (let ((result@7@00 (p_Param_snap%limited s@$ self@5@00 T$0@6@00))) true)
  :pattern ((p_Param_snap%limited s@$ self@5@00 T$0@6@00))
  :qid |quant-u-71|)))
; ---------- FUNCTION p_Ref_mutable_arbitrary_value----------
(declare-fun r@8@00 () $Ref)
(declare-fun metadata@9@00 () s_Param)
(declare-fun U$1@10@00 () Type)
(declare-fun result@11@00 () s_Ref_mutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@77@00 $Snap)
(assert (= $t@77@00 ($Snap.combine ($Snap.first $t@77@00) ($Snap.second $t@77@00))))
(assert (= ($Snap.first $t@77@00) $Snap.unit))
; [eval] get_s_Ref_mutable_s_Ref_mutable_0(result) == r
; [eval] get_s_Ref_mutable_s_Ref_mutable_0(result)
(assert (= (get_s_Ref_mutable_s_Ref_mutable_0<Ref> result@11@00) r@8@00))
(assert (= ($Snap.second $t@77@00) $Snap.unit))
; [eval] get_s_Ref_mutable_s_Ref_mutable_1(result) == metadata
; [eval] get_s_Ref_mutable_s_Ref_mutable_1(result)
(assert (= (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@11@00) metadata@9@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (r@8@00 $Ref) (metadata@9@00 s_Param) (U$1@10@00 Type)) (!
  (=
    (p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00)
    (p_Ref_mutable_arbitrary_value s@$ r@8@00 metadata@9@00 U$1@10@00))
  :pattern ((p_Ref_mutable_arbitrary_value s@$ r@8@00 metadata@9@00 U$1@10@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (r@8@00 $Ref) (metadata@9@00 s_Param) (U$1@10@00 Type)) (!
  (p_Ref_mutable_arbitrary_value%stateless r@8@00 metadata@9@00 U$1@10@00)
  :pattern ((p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (r@8@00 $Ref) (metadata@9@00 s_Param) (U$1@10@00 Type)) (!
  (let ((result@11@00 (p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))) (=>
    (p_Ref_mutable_arbitrary_value%precondition s@$ r@8@00 metadata@9@00 U$1@10@00)
    (and
      (= (get_s_Ref_mutable_s_Ref_mutable_0<Ref> result@11@00) r@8@00)
      (= (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@11@00) metadata@9@00))))
  :pattern ((p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (r@8@00 $Ref) (metadata@9@00 s_Param) (U$1@10@00 Type)) (!
  (let ((result@11@00 (p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))) true)
  :pattern ((p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (r@8@00 $Ref) (metadata@9@00 s_Param) (U$1@10@00 Type)) (!
  (let ((result@11@00 (p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))) true)
  :pattern ((p_Ref_mutable_arbitrary_value%limited s@$ r@8@00 metadata@9@00 U$1@10@00))
  :qid |quant-u-74|)))
; ---------- FUNCTION f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len----------
(declare-fun _1s@12@00 () s_Ref_immutable)
(declare-fun T$0@13@00 () Type)
(declare-fun result@14@00 () s_UInt_usize)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@78@00 $Snap)
(assert (= $t@78@00 $Snap.unit))
; [eval] mir_binop_Eq_UInt_usize_UInt_usize(result, mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize(s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))))))
; [eval] mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize(s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s)))))
; [eval] s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))))
; [eval] get_s_Ref_immutable_s_Ref_immutable_0(_1s)
; [eval] make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s)))
; [eval] get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))
; [eval] get_s_Ref_immutable_s_Ref_immutable_1(_1s)
(push) ; 2
(assert (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00))))))
(pop) ; 2
; Joined path conditions
(assert (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00))))))
(push) ; 2
(assert (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@14@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00)))))))
(pop) ; 2
; Joined path conditions
(assert (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@14@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00)))))))
(assert (mir_binop_Eq_UInt_usize_UInt_usize $Snap.unit result@14@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (_1s@12@00 s_Ref_immutable) (T$0@13@00 Type)) (!
  (=
    (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00)
    (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@12@00 T$0@13@00))
  :pattern ((f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@12@00 T$0@13@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (_1s@12@00 s_Ref_immutable) (T$0@13@00 Type)) (!
  (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%stateless _1s@12@00 T$0@13@00)
  :pattern ((f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (_1s@12@00 s_Ref_immutable) (T$0@13@00 Type)) (!
  (let ((result@14@00 (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00))) (=>
    (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@12@00 T$0@13@00)
    (mir_binop_Eq_UInt_usize_UInt_usize $Snap.unit result@14@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00))))))))
  :pattern ((f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (_1s@12@00 s_Ref_immutable) (T$0@13@00 Type)) (!
  (let ((result@14@00 (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00))) (=>
    (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@12@00 T$0@13@00)
    (and
      (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00)))))
      (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@14@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@12@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@12@00)))))))))
  :pattern ((f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@12@00 T$0@13@00))
  :qid |quant-u-76|)))
; ---------- FUNCTION p_0_Tuple_snap----------
(declare-fun self@15@00 () $Ref)
(declare-fun result@16@00 () s_0_Tuple)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@15@00 $Ref)) (!
  (= (p_0_Tuple_snap%limited s@$ self@15@00) (p_0_Tuple_snap s@$ self@15@00))
  :pattern ((p_0_Tuple_snap s@$ self@15@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (self@15@00 $Ref)) (!
  (p_0_Tuple_snap%stateless self@15@00)
  :pattern ((p_0_Tuple_snap%limited s@$ self@15@00))
  :qid |quant-u-11|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_0_Tuple(self), write) in s_0_Tuple_cons())
(push) ; 2
(assert (p_0_Tuple%trigger s@$ self@15@00))
(assert (= s@$ $Snap.unit))
; [eval] s_0_Tuple_cons()
(pop) ; 2
; Joined path conditions
(assert (and (p_0_Tuple%trigger s@$ self@15@00) (= s@$ $Snap.unit)))
(assert (= result@16@00 (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@15@00 $Ref)) (!
  (=>
    (p_0_Tuple_snap%precondition s@$ self@15@00)
    (= (p_0_Tuple_snap s@$ self@15@00) (as s_0_Tuple_cons<s_0_Tuple>  s_0_Tuple)))
  :pattern ((p_0_Tuple_snap s@$ self@15@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (self@15@00 $Ref)) (!
  true
  :pattern ((p_0_Tuple_snap s@$ self@15@00))
  :qid |quant-u-78|)))
; ---------- FUNCTION mir_binop_Eq_UInt_u32_UInt_u32----------
(declare-fun arg1@17@00 () s_UInt_u32)
(declare-fun arg2@18@00 () s_UInt_u32)
(declare-fun result@19@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@17@00 s_UInt_u32) (arg2@18@00 s_UInt_u32)) (!
  (=
    (mir_binop_Eq_UInt_u32_UInt_u32%limited s@$ arg1@17@00 arg2@18@00)
    (mir_binop_Eq_UInt_u32_UInt_u32 s@$ arg1@17@00 arg2@18@00))
  :pattern ((mir_binop_Eq_UInt_u32_UInt_u32 s@$ arg1@17@00 arg2@18@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (arg1@17@00 s_UInt_u32) (arg2@18@00 s_UInt_u32)) (!
  (mir_binop_Eq_UInt_u32_UInt_u32%stateless arg1@17@00 arg2@18@00)
  :pattern ((mir_binop_Eq_UInt_u32_UInt_u32%limited s@$ arg1@17@00 arg2@18@00))
  :qid |quant-u-13|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] s_UInt_u32_value(arg1) == s_UInt_u32_value(arg2)
; [eval] s_UInt_u32_value(arg1)
; [eval] s_UInt_u32_value(arg2)
(assert (=
  result@19@00
  (= (s_UInt_u32_value<Int> arg1@17@00) (s_UInt_u32_value<Int> arg2@18@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@17@00 s_UInt_u32) (arg2@18@00 s_UInt_u32)) (!
  (=>
    (mir_binop_Eq_UInt_u32_UInt_u32%precondition s@$ arg1@17@00 arg2@18@00)
    (=
      (mir_binop_Eq_UInt_u32_UInt_u32 s@$ arg1@17@00 arg2@18@00)
      (= (s_UInt_u32_value<Int> arg1@17@00) (s_UInt_u32_value<Int> arg2@18@00))))
  :pattern ((mir_binop_Eq_UInt_u32_UInt_u32 s@$ arg1@17@00 arg2@18@00))
  :qid |quant-u-79|)))
(assert (forall ((s@$ $Snap) (arg1@17@00 s_UInt_u32) (arg2@18@00 s_UInt_u32)) (!
  true
  :pattern ((mir_binop_Eq_UInt_u32_UInt_u32 s@$ arg1@17@00 arg2@18@00))
  :qid |quant-u-80|)))
; ---------- FUNCTION p_UInt_u32_snap----------
(declare-fun self@20@00 () $Ref)
(declare-fun result@21@00 () s_UInt_u32)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@20@00 $Ref)) (!
  (= (p_UInt_u32_snap%limited s@$ self@20@00) (p_UInt_u32_snap s@$ self@20@00))
  :pattern ((p_UInt_u32_snap s@$ self@20@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (self@20@00 $Ref)) (!
  (p_UInt_u32_snap%stateless self@20@00)
  :pattern ((p_UInt_u32_snap%limited s@$ self@20@00))
  :qid |quant-u-15|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_UInt_u32(self), write) in self.p_UInt_u32_val)
(push) ; 2
(assert (p_UInt_u32%trigger s@$ self@20@00))
(assert (not (= self@20@00 $Ref.null)))
(pop) ; 2
; Joined path conditions
(assert (and (p_UInt_u32%trigger s@$ self@20@00) (not (= self@20@00 $Ref.null))))
(assert (= result@21@00 ($SortWrappers.$SnapTos_UInt_u32 s@$)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@20@00 $Ref)) (!
  (=>
    (p_UInt_u32_snap%precondition s@$ self@20@00)
    (= (p_UInt_u32_snap s@$ self@20@00) ($SortWrappers.$SnapTos_UInt_u32 s@$)))
  :pattern ((p_UInt_u32_snap s@$ self@20@00))
  :qid |quant-u-81|)))
(assert (forall ((s@$ $Snap) (self@20@00 $Ref)) (!
  true
  :pattern ((p_UInt_u32_snap s@$ self@20@00))
  :qid |quant-u-82|)))
; ---------- FUNCTION p_RawPtr_immutable_snap----------
(declare-fun self@22@00 () $Ref)
(declare-fun T$0@23@00 () Type)
(declare-fun result@24@00 () s_RawPtr_immutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@79@00 $Snap)
(assert (= $t@79@00 $Snap.unit))
; [eval] s_Param_typ(get_s_RawPtr_immutable_s_RawPtr_immutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
; [eval] s_Param_typ(get_s_RawPtr_immutable_s_RawPtr_immutable_1(result))
; [eval] get_s_RawPtr_immutable_s_RawPtr_immutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
(assert (=
  (s_Param_typ<Type> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> result@24@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  (=
    (p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00)
    (p_RawPtr_immutable_snap s@$ self@22@00 T$0@23@00))
  :pattern ((p_RawPtr_immutable_snap s@$ self@22@00 T$0@23@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  (p_RawPtr_immutable_snap%stateless self@22@00 T$0@23@00)
  :pattern ((p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  (let ((result@24@00 (p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00))) (=>
    (p_RawPtr_immutable_snap%precondition s@$ self@22@00 T$0@23@00)
    (=
      (s_Param_typ<Type> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> result@24@00))
      (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00))))
  :pattern ((p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00))
  :qid |quant-u-83|)))
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  (let ((result@24@00 (p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00))) true)
  :pattern ((p_RawPtr_immutable_snap%limited s@$ self@22@00 T$0@23@00))
  :qid |quant-u-84|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_RawPtr_immutable(self, T$0), write) in s_RawPtr_immutable_cons(self.p_RawPtr_immutable_addr, self.p_RawPtr_immutable_metadata))
(push) ; 2
(assert (p_RawPtr_immutable%trigger s@$ self@22@00 T$0@23@00))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= self@22@00 $Ref.null)))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] s_Param_typ(self.p_RawPtr_immutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
; [eval] s_Param_typ(self.p_RawPtr_immutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00)))
; [eval] s_RawPtr_immutable_cons(self.p_RawPtr_immutable_addr, self.p_RawPtr_immutable_metadata)
(pop) ; 2
; Joined path conditions
(assert (and
  (p_RawPtr_immutable%trigger s@$ self@22@00 T$0@23@00)
  (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$)))
  (not (= self@22@00 $Ref.null))
  (=
    ($Snap.second s@$)
    ($Snap.combine
      ($Snap.first ($Snap.second s@$))
      ($Snap.second ($Snap.second s@$))))
  (= ($Snap.second ($Snap.second s@$)) $Snap.unit)
  (=
    (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
    (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00))))
(assert (=
  result@24@00
  (s_RawPtr_immutable_cons<s_RawPtr_immutable> ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))))
; [eval] s_Param_typ(get_s_RawPtr_immutable_s_RawPtr_immutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
; [eval] s_Param_typ(get_s_RawPtr_immutable_s_RawPtr_immutable_1(result))
; [eval] get_s_RawPtr_immutable_s_RawPtr_immutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
(push) ; 2
(set-option :rlimit 100000000)
(assert (not (=
  (s_Param_typ<Type> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> result@24@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  (s_Param_typ<Type> (get_s_RawPtr_immutable_s_RawPtr_immutable_1<s_Param> result@24@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@23@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  (=>
    (p_RawPtr_immutable_snap%precondition s@$ self@22@00 T$0@23@00)
    (=
      (p_RawPtr_immutable_snap s@$ self@22@00 T$0@23@00)
      (s_RawPtr_immutable_cons<s_RawPtr_immutable> ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))))
  :pattern ((p_RawPtr_immutable_snap s@$ self@22@00 T$0@23@00))
  :qid |quant-u-85|)))
(assert (forall ((s@$ $Snap) (self@22@00 $Ref) (T$0@23@00 Type)) (!
  true
  :pattern ((p_RawPtr_immutable_snap s@$ self@22@00 T$0@23@00))
  :qid |quant-u-86|)))
; ---------- FUNCTION s_Ref_immutable_unreachable----------
(declare-fun U$1@25@00 () Type)
(declare-fun result@26@00 () s_Ref_immutable)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@80@00 $Snap)
(assert (= $t@80@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap) (U$1@25@00 Type)) (!
  (=
    (s_Ref_immutable_unreachable%limited s@$ U$1@25@00)
    (s_Ref_immutable_unreachable s@$ U$1@25@00))
  :pattern ((s_Ref_immutable_unreachable s@$ U$1@25@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (U$1@25@00 Type)) (!
  (s_Ref_immutable_unreachable%stateless U$1@25@00)
  :pattern ((s_Ref_immutable_unreachable%limited s@$ U$1@25@00))
  :qid |quant-u-19|)))
(assert (forall ((s@$ $Snap) (U$1@25@00 Type)) (!
  (let ((result@26@00 (s_Ref_immutable_unreachable%limited s@$ U$1@25@00))) (=>
    (s_Ref_immutable_unreachable%precondition s@$ U$1@25@00)
    false))
  :pattern ((s_Ref_immutable_unreachable%limited s@$ U$1@25@00))
  :qid |quant-u-87|)))
(assert (forall ((s@$ $Snap) (U$1@25@00 Type)) (!
  (let ((result@26@00 (s_Ref_immutable_unreachable%limited s@$ U$1@25@00))) true)
  :pattern ((s_Ref_immutable_unreachable%limited s@$ U$1@25@00))
  :qid |quant-u-88|)))
; ---------- FUNCTION p_Bool_snap----------
(declare-fun self@27@00 () $Ref)
(declare-fun result@28@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@27@00 $Ref)) (!
  (= (p_Bool_snap%limited s@$ self@27@00) (p_Bool_snap s@$ self@27@00))
  :pattern ((p_Bool_snap s@$ self@27@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (self@27@00 $Ref)) (!
  (p_Bool_snap%stateless self@27@00)
  :pattern ((p_Bool_snap%limited s@$ self@27@00))
  :qid |quant-u-21|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_Bool(self), write) in self.p_Bool_val)
(push) ; 2
(assert (p_Bool%trigger s@$ self@27@00))
(assert (not (= self@27@00 $Ref.null)))
(pop) ; 2
; Joined path conditions
(assert (and (p_Bool%trigger s@$ self@27@00) (not (= self@27@00 $Ref.null))))
(assert (= result@28@00 ($SortWrappers.$SnapToBool s@$)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@27@00 $Ref)) (!
  (=>
    (p_Bool_snap%precondition s@$ self@27@00)
    (= (p_Bool_snap s@$ self@27@00) ($SortWrappers.$SnapToBool s@$)))
  :pattern ((p_Bool_snap s@$ self@27@00))
  :qid |quant-u-89|)))
(assert (forall ((s@$ $Snap) (self@27@00 $Ref)) (!
  true
  :pattern ((p_Bool_snap s@$ self@27@00))
  :qid |quant-u-90|)))
; ---------- FUNCTION s_UInt_u32_unreachable----------
(declare-fun result@29@00 () s_UInt_u32)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@81@00 $Snap)
(assert (= $t@81@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (= (s_UInt_u32_unreachable%limited s@$) (s_UInt_u32_unreachable s@$))
  :pattern ((s_UInt_u32_unreachable s@$))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_UInt_u32_unreachable%stateless  Bool)
  :pattern ((s_UInt_u32_unreachable%limited s@$))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@29@00 (s_UInt_u32_unreachable%limited s@$))) (=>
    (s_UInt_u32_unreachable%precondition s@$)
    false))
  :pattern ((s_UInt_u32_unreachable%limited s@$))
  :qid |quant-u-91|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@29@00 (s_UInt_u32_unreachable%limited s@$))) true)
  :pattern ((s_UInt_u32_unreachable%limited s@$))
  :qid |quant-u-92|)))
; ---------- FUNCTION p_Ref_immutable_snap----------
(declare-fun self@30@00 () $Ref)
(declare-fun U$1@31@00 () Type)
(declare-fun result@32@00 () s_Ref_immutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@82@00 $Snap)
(assert (= $t@82@00 ($Snap.combine ($Snap.first $t@82@00) ($Snap.second $t@82@00))))
(assert (= ($Snap.first $t@82@00) $Snap.unit))
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_1(result))
; [eval] get_s_Ref_immutable_s_Ref_immutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> result@32@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00)))
(assert (= ($Snap.second $t@82@00) $Snap.unit))
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_2(result)) == U$1
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_2(result))
; [eval] get_s_Ref_immutable_s_Ref_immutable_2(result)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> result@32@00))
  U$1@31@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (=
    (p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00)
    (p_Ref_immutable_snap s@$ self@30@00 U$1@31@00))
  :pattern ((p_Ref_immutable_snap s@$ self@30@00 U$1@31@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (p_Ref_immutable_snap%stateless self@30@00 U$1@31@00)
  :pattern ((p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (let ((result@32@00 (p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))) (=>
    (p_Ref_immutable_snap%precondition s@$ self@30@00 U$1@31@00)
    (and
      (=
        (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> result@32@00))
        (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00))
      (=
        (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> result@32@00))
        U$1@31@00))))
  :pattern ((p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))
  :qid |quant-u-93|)))
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (let ((result@32@00 (p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))) true)
  :pattern ((p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))
  :qid |quant-u-94|)))
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (let ((result@32@00 (p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))) true)
  :pattern ((p_Ref_immutable_snap%limited s@$ self@30@00 U$1@31@00))
  :qid |quant-u-95|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_Ref_immutable(self, U$1), write) in s_Ref_immutable_cons(self.p_Ref_immutable_addr, self.p_Ref_immutable_metadata, p_Param_snap(self.p_Ref_immutable_addr, U$1)))
(push) ; 2
(assert (p_Ref_immutable%trigger s@$ self@30@00 U$1@31@00))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= self@30@00 $Ref.null)))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] s_Param_typ(self.p_Ref_immutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(self.p_Ref_immutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00)))
; [eval] read()
(push) ; 3
(set-option :rlimit 100000000)
(assert (not (or (= (as read<Perm>  $Perm) $Perm.No) (< $Perm.No (as read<Perm>  $Perm)))))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (<= $Perm.No (as read<Perm>  $Perm)))
; [eval] s_Ref_immutable_cons(self.p_Ref_immutable_addr, self.p_Ref_immutable_metadata, p_Param_snap(self.p_Ref_immutable_addr, U$1))
; [eval] p_Param_snap(self.p_Ref_immutable_addr, U$1)
(set-option :rlimit 0)
(push) ; 3
(push) ; 4
(set-option :rlimit 100000000)
(assert (not (< $Perm.No (as read<Perm>  $Perm))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (p_Param_snap%precondition ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00))
(pop) ; 3
; Joined path conditions
(assert (p_Param_snap%precondition ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00))
(pop) ; 2
; Joined path conditions
(assert (and
  (p_Ref_immutable%trigger s@$ self@30@00 U$1@31@00)
  (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$)))
  (not (= self@30@00 $Ref.null))
  (=
    ($Snap.second s@$)
    ($Snap.combine
      ($Snap.first ($Snap.second s@$))
      ($Snap.second ($Snap.second s@$))))
  (=
    ($Snap.second ($Snap.second s@$))
    ($Snap.combine
      ($Snap.first ($Snap.second ($Snap.second s@$)))
      ($Snap.second ($Snap.second ($Snap.second s@$)))))
  (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit)
  (=
    (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
    (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00))
  (<= $Perm.No (as read<Perm>  $Perm))
  (p_Param_snap%precondition ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00)))
(assert (=
  result@32@00
  (s_Ref_immutable_cons<s_Ref_immutable> ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) (p_Param_snap ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00))))
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_1(result))
; [eval] get_s_Ref_immutable_s_Ref_immutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(set-option :rlimit 0)
(push) ; 2
(set-option :rlimit 100000000)
(assert (not (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> result@32@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> result@32@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@31@00)))
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_2(result)) == U$1
; [eval] s_Param_typ(get_s_Ref_immutable_s_Ref_immutable_2(result))
; [eval] get_s_Ref_immutable_s_Ref_immutable_2(result)
(set-option :rlimit 0)
(push) ; 2
(set-option :rlimit 100000000)
(assert (not (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> result@32@00))
  U$1@31@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_immutable_s_Ref_immutable_2<s_Param> result@32@00))
  U$1@31@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (=>
    (p_Ref_immutable_snap%precondition s@$ self@30@00 U$1@31@00)
    (=
      (p_Ref_immutable_snap s@$ self@30@00 U$1@31@00)
      (s_Ref_immutable_cons<s_Ref_immutable> ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) (p_Param_snap ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00))))
  :pattern ((p_Ref_immutable_snap s@$ self@30@00 U$1@31@00))
  :qid |quant-u-96|)))
(assert (forall ((s@$ $Snap) (self@30@00 $Ref) (U$1@31@00 Type)) (!
  (=>
    (p_Ref_immutable_snap%precondition s@$ self@30@00 U$1@31@00)
    (p_Param_snap%precondition ($Snap.second ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) U$1@31@00))
  :pattern ((p_Ref_immutable_snap s@$ self@30@00 U$1@31@00))
  :qid |quant-u-97|)))
; ---------- FUNCTION s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable----------
(declare-fun result@33@00 () s_visit$col$$col$$lc$closure$oc$0$rc$)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@83@00 $Snap)
(assert (= $t@83@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$)
    (s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable s@$))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable s@$))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%stateless  Bool)
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@33@00 (s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$))) (=>
    (s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%precondition s@$)
    false))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$))
  :qid |quant-u-98|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@33@00 (s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$))) true)
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_unreachable%limited s@$))
  :qid |quant-u-99|)))
; ---------- FUNCTION s_visit$col$$col$$lc$closure$oc$1$rc$_field_0----------
(declare-fun self@34@00 () $Ref)
(declare-fun result@35@00 () $Ref)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@84@00 $Snap)
(assert (= $t@84@00 $Snap.unit))
; [eval] (self == null) == (result == null)
; [eval] self == null
; [eval] result == null
(assert (= (= self@34@00 $Ref.null) (= result@35@00 $Ref.null)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@34@00 $Ref)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00)
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0 s@$ self@34@00))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_0 s@$ self@34@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (self@34@00 $Ref)) (!
  (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%stateless self@34@00)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (self@34@00 $Ref)) (!
  (let ((result@35@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00))) (=>
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%precondition s@$ self@34@00)
    (= (= self@34@00 $Ref.null) (= result@35@00 $Ref.null))))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00))
  :qid |quant-u-100|)))
(assert (forall ((s@$ $Snap) (self@34@00 $Ref)) (!
  (let ((result@35@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00))) true)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_0%limited s@$ self@34@00))
  :qid |quant-u-101|)))
; ---------- FUNCTION s_visit$col$$col$$lc$closure$oc$1$rc$_field_1----------
(declare-fun self@36@00 () $Ref)
(declare-fun result@37@00 () $Ref)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@85@00 $Snap)
(assert (= $t@85@00 $Snap.unit))
; [eval] (self == null) == (result == null)
; [eval] self == null
; [eval] result == null
(assert (= (= self@36@00 $Ref.null) (= result@37@00 $Ref.null)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@36@00 $Ref)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00)
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1 s@$ self@36@00))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_1 s@$ self@36@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (self@36@00 $Ref)) (!
  (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%stateless self@36@00)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (self@36@00 $Ref)) (!
  (let ((result@37@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00))) (=>
    (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%precondition s@$ self@36@00)
    (= (= self@36@00 $Ref.null) (= result@37@00 $Ref.null))))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00))
  :qid |quant-u-102|)))
(assert (forall ((s@$ $Snap) (self@36@00 $Ref)) (!
  (let ((result@37@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00))) true)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_field_1%limited s@$ self@36@00))
  :qid |quant-u-103|)))
; ---------- FUNCTION s_Ref_mutable_unreachable----------
(declare-fun U$1@38@00 () Type)
(declare-fun result@39@00 () s_Ref_mutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@86@00 $Snap)
(assert (= $t@86@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap) (U$1@38@00 Type)) (!
  (=
    (s_Ref_mutable_unreachable%limited s@$ U$1@38@00)
    (s_Ref_mutable_unreachable s@$ U$1@38@00))
  :pattern ((s_Ref_mutable_unreachable s@$ U$1@38@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (U$1@38@00 Type)) (!
  (s_Ref_mutable_unreachable%stateless U$1@38@00)
  :pattern ((s_Ref_mutable_unreachable%limited s@$ U$1@38@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (U$1@38@00 Type)) (!
  (let ((result@39@00 (s_Ref_mutable_unreachable%limited s@$ U$1@38@00))) (=>
    (s_Ref_mutable_unreachable%precondition s@$ U$1@38@00)
    false))
  :pattern ((s_Ref_mutable_unreachable%limited s@$ U$1@38@00))
  :qid |quant-u-104|)))
(assert (forall ((s@$ $Snap) (U$1@38@00 Type)) (!
  (let ((result@39@00 (s_Ref_mutable_unreachable%limited s@$ U$1@38@00))) true)
  :pattern ((s_Ref_mutable_unreachable%limited s@$ U$1@38@00))
  :qid |quant-u-105|)))
; ---------- FUNCTION indexed_resource_observation----------
(declare-fun element@40@00 () s_Param)
(declare-fun index@41@00 () Int)
(declare-fun result@42@00 () s_Param)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (element@40@00 s_Param) (index@41@00 Int)) (!
  (=
    (indexed_resource_observation%limited s@$ element@40@00 index@41@00)
    (indexed_resource_observation s@$ element@40@00 index@41@00))
  :pattern ((indexed_resource_observation s@$ element@40@00 index@41@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (element@40@00 s_Param) (index@41@00 Int)) (!
  (indexed_resource_observation%stateless element@40@00 index@41@00)
  :pattern ((indexed_resource_observation%limited s@$ element@40@00 index@41@00))
  :qid |quant-u-35|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= result@42@00 element@40@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (element@40@00 s_Param) (index@41@00 Int)) (!
  (=>
    (indexed_resource_observation%precondition s@$ element@40@00 index@41@00)
    (=
      (indexed_resource_observation s@$ element@40@00 index@41@00)
      element@40@00))
  :pattern ((indexed_resource_observation s@$ element@40@00 index@41@00))
  :qid |quant-u-106|)))
(assert (forall ((s@$ $Snap) (element@40@00 s_Param) (index@41@00 Int)) (!
  true
  :pattern ((indexed_resource_observation s@$ element@40@00 index@41@00))
  :qid |quant-u-107|)))
; ---------- FUNCTION p_Ref_mutable_snap----------
(declare-fun self@43@00 () $Ref)
(declare-fun U$1@44@00 () Type)
(declare-fun result@45@00 () s_Ref_mutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@87@00 $Snap)
(assert (= $t@87@00 $Snap.unit))
; [eval] s_Param_typ(get_s_Ref_mutable_s_Ref_mutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(get_s_Ref_mutable_s_Ref_mutable_1(result))
; [eval] get_s_Ref_mutable_s_Ref_mutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@45@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (=
    (p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00)
    (p_Ref_mutable_snap s@$ self@43@00 U$1@44@00))
  :pattern ((p_Ref_mutable_snap s@$ self@43@00 U$1@44@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (p_Ref_mutable_snap%stateless self@43@00 U$1@44@00)
  :pattern ((p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (let ((result@45@00 (p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00))) (=>
    (p_Ref_mutable_snap%precondition s@$ self@43@00 U$1@44@00)
    (=
      (s_Param_typ<Type> (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@45@00))
      (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00))))
  :pattern ((p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00))
  :qid |quant-u-108|)))
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (let ((result@45@00 (p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00))) true)
  :pattern ((p_Ref_mutable_snap%limited s@$ self@43@00 U$1@44@00))
  :qid |quant-u-109|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_Ref_mutable(self, U$1), write) in p_Ref_mutable_arbitrary_value(self.p_Ref_mutable_addr, self.p_Ref_mutable_metadata, U$1))
(push) ; 2
(assert (p_Ref_mutable%trigger s@$ self@43@00 U$1@44@00))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= self@43@00 $Ref.null)))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] s_Param_typ(self.p_Ref_mutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(self.p_Ref_mutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00)))
; [eval] p_Ref_mutable_arbitrary_value(self.p_Ref_mutable_addr, self.p_Ref_mutable_metadata, U$1)
(push) ; 3
(assert (p_Ref_mutable_arbitrary_value%precondition $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00))
(pop) ; 3
; Joined path conditions
(assert (p_Ref_mutable_arbitrary_value%precondition $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00))
(pop) ; 2
; Joined path conditions
(assert (and
  (p_Ref_mutable%trigger s@$ self@43@00 U$1@44@00)
  (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$)))
  (not (= self@43@00 $Ref.null))
  (=
    ($Snap.second s@$)
    ($Snap.combine
      ($Snap.first ($Snap.second s@$))
      ($Snap.second ($Snap.second s@$))))
  (= ($Snap.second ($Snap.second s@$)) $Snap.unit)
  (=
    (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))))
    (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00))
  (p_Ref_mutable_arbitrary_value%precondition $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00)))
(assert (=
  result@45@00
  (p_Ref_mutable_arbitrary_value $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00)))
; [eval] s_Param_typ(get_s_Ref_mutable_s_Ref_mutable_1(result)) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(get_s_Ref_mutable_s_Ref_mutable_1(result))
; [eval] get_s_Ref_mutable_s_Ref_mutable_1(result)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(push) ; 2
(set-option :rlimit 100000000)
(assert (not (=
  (s_Param_typ<Type> (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@45@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  (s_Param_typ<Type> (get_s_Ref_mutable_s_Ref_mutable_1<s_Param> result@45@00))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@44@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (=>
    (p_Ref_mutable_snap%precondition s@$ self@43@00 U$1@44@00)
    (=
      (p_Ref_mutable_snap s@$ self@43@00 U$1@44@00)
      (p_Ref_mutable_arbitrary_value $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00)))
  :pattern ((p_Ref_mutable_snap s@$ self@43@00 U$1@44@00))
  :qid |quant-u-110|)))
(assert (forall ((s@$ $Snap) (self@43@00 $Ref) (U$1@44@00 Type)) (!
  (=>
    (p_Ref_mutable_snap%precondition s@$ self@43@00 U$1@44@00)
    (p_Ref_mutable_arbitrary_value%precondition $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second s@$))) U$1@44@00))
  :pattern ((p_Ref_mutable_snap s@$ self@43@00 U$1@44@00))
  :qid |quant-u-111|)))
; ---------- FUNCTION s_Slice_unreachable----------
(declare-fun T$0@46@00 () Type)
(declare-fun result@47@00 () s_Slice)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@88@00 $Snap)
(assert (= $t@88@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap) (T$0@46@00 Type)) (!
  (=
    (s_Slice_unreachable%limited s@$ T$0@46@00)
    (s_Slice_unreachable s@$ T$0@46@00))
  :pattern ((s_Slice_unreachable s@$ T$0@46@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (T$0@46@00 Type)) (!
  (s_Slice_unreachable%stateless T$0@46@00)
  :pattern ((s_Slice_unreachable%limited s@$ T$0@46@00))
  :qid |quant-u-39|)))
(assert (forall ((s@$ $Snap) (T$0@46@00 Type)) (!
  (let ((result@47@00 (s_Slice_unreachable%limited s@$ T$0@46@00))) (=>
    (s_Slice_unreachable%precondition s@$ T$0@46@00)
    false))
  :pattern ((s_Slice_unreachable%limited s@$ T$0@46@00))
  :qid |quant-u-112|)))
(assert (forall ((s@$ $Snap) (T$0@46@00 Type)) (!
  (let ((result@47@00 (s_Slice_unreachable%limited s@$ T$0@46@00))) true)
  :pattern ((s_Slice_unreachable%limited s@$ T$0@46@00))
  :qid |quant-u-113|)))
; ---------- FUNCTION s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable----------
(declare-fun result@48@00 () s_visit$col$$col$$lc$closure$oc$1$rc$)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@89@00 $Snap)
(assert (= $t@89@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$)
    (s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable s@$))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable s@$))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%stateless  Bool)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$))
  :qid |quant-u-41|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@48@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$))) (=>
    (s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%precondition s@$)
    false))
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$))
  :qid |quant-u-114|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@48@00 (s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$))) true)
  :pattern ((s_visit$col$$col$$lc$closure$oc$1$rc$_unreachable%limited s@$))
  :qid |quant-u-115|)))
; ---------- FUNCTION p_Slice_snap----------
(declare-fun self@49@00 () $Ref)
(declare-fun T$0@50@00 () Type)
(declare-fun result@51@00 () s_Slice)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@49@00 $Ref) (T$0@50@00 Type)) (!
  (=
    (p_Slice_snap%limited s@$ self@49@00 T$0@50@00)
    (p_Slice_snap s@$ self@49@00 T$0@50@00))
  :pattern ((p_Slice_snap s@$ self@49@00 T$0@50@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (self@49@00 $Ref) (T$0@50@00 Type)) (!
  (p_Slice_snap%stateless self@49@00 T$0@50@00)
  :pattern ((p_Slice_snap%limited s@$ self@49@00 T$0@50@00))
  :qid |quant-u-43|)))
; ---------- FUNCTION mir_binop_Ne_UInt_usize_UInt_usize----------
(declare-fun arg1@52@00 () s_UInt_usize)
(declare-fun arg2@53@00 () s_UInt_usize)
(declare-fun result@54@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@52@00 s_UInt_usize) (arg2@53@00 s_UInt_usize)) (!
  (=
    (mir_binop_Ne_UInt_usize_UInt_usize%limited s@$ arg1@52@00 arg2@53@00)
    (mir_binop_Ne_UInt_usize_UInt_usize s@$ arg1@52@00 arg2@53@00))
  :pattern ((mir_binop_Ne_UInt_usize_UInt_usize s@$ arg1@52@00 arg2@53@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (arg1@52@00 s_UInt_usize) (arg2@53@00 s_UInt_usize)) (!
  (mir_binop_Ne_UInt_usize_UInt_usize%stateless arg1@52@00 arg2@53@00)
  :pattern ((mir_binop_Ne_UInt_usize_UInt_usize%limited s@$ arg1@52@00 arg2@53@00))
  :qid |quant-u-45|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] s_UInt_usize_value(arg1) != s_UInt_usize_value(arg2)
; [eval] s_UInt_usize_value(arg1)
; [eval] s_UInt_usize_value(arg2)
(assert (=
  result@54@00
  (not
    (= (s_UInt_usize_value<Int> arg1@52@00) (s_UInt_usize_value<Int> arg2@53@00)))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@52@00 s_UInt_usize) (arg2@53@00 s_UInt_usize)) (!
  (=>
    (mir_binop_Ne_UInt_usize_UInt_usize%precondition s@$ arg1@52@00 arg2@53@00)
    (=
      (mir_binop_Ne_UInt_usize_UInt_usize s@$ arg1@52@00 arg2@53@00)
      (not
        (=
          (s_UInt_usize_value<Int> arg1@52@00)
          (s_UInt_usize_value<Int> arg2@53@00)))))
  :pattern ((mir_binop_Ne_UInt_usize_UInt_usize s@$ arg1@52@00 arg2@53@00))
  :qid |quant-u-116|)))
(assert (forall ((s@$ $Snap) (arg1@52@00 s_UInt_usize) (arg2@53@00 s_UInt_usize)) (!
  true
  :pattern ((mir_binop_Ne_UInt_usize_UInt_usize s@$ arg1@52@00 arg2@53@00))
  :qid |quant-u-117|)))
; ---------- FUNCTION s_visit$col$$col$$lc$closure$oc$0$rc$_field_0----------
(declare-fun self@55@00 () $Ref)
(declare-fun result@56@00 () $Ref)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@90@00 $Snap)
(assert (= $t@90@00 $Snap.unit))
; [eval] (self == null) == (result == null)
; [eval] self == null
; [eval] result == null
(assert (= (= self@55@00 $Ref.null) (= result@56@00 $Ref.null)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@55@00 $Ref)) (!
  (=
    (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00)
    (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0 s@$ self@55@00))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_field_0 s@$ self@55@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (self@55@00 $Ref)) (!
  (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%stateless self@55@00)
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00))
  :qid |quant-u-47|)))
(assert (forall ((s@$ $Snap) (self@55@00 $Ref)) (!
  (let ((result@56@00 (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00))) (=>
    (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%precondition s@$ self@55@00)
    (= (= self@55@00 $Ref.null) (= result@56@00 $Ref.null))))
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00))
  :qid |quant-u-118|)))
(assert (forall ((s@$ $Snap) (self@55@00 $Ref)) (!
  (let ((result@56@00 (s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00))) true)
  :pattern ((s_visit$col$$col$$lc$closure$oc$0$rc$_field_0%limited s@$ self@55@00))
  :qid |quant-u-119|)))
; ---------- FUNCTION p_Slice_index_frame----------
(declare-fun self@57@00 () $Ref)
(declare-fun index@58@00 () Int)
(declare-fun T$0@59@00 () Type)
(declare-fun result@60@00 () s_Slice)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@57@00 $Ref) (index@58@00 Int) (T$0@59@00 Type)) (!
  (=
    (p_Slice_index_frame%limited s@$ self@57@00 index@58@00 T$0@59@00)
    (p_Slice_index_frame s@$ self@57@00 index@58@00 T$0@59@00))
  :pattern ((p_Slice_index_frame s@$ self@57@00 index@58@00 T$0@59@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (self@57@00 $Ref) (index@58@00 Int) (T$0@59@00 Type)) (!
  (p_Slice_index_frame%stateless self@57@00 index@58@00 T$0@59@00)
  :pattern ((p_Slice_index_frame%limited s@$ self@57@00 index@58@00 T$0@59@00))
  :qid |quant-u-49|)))
; ---------- FUNCTION mir_binop_Lt_UInt_usize_UInt_usize----------
(declare-fun arg1@61@00 () s_UInt_usize)
(declare-fun arg2@62@00 () s_UInt_usize)
(declare-fun result@63@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@61@00 s_UInt_usize) (arg2@62@00 s_UInt_usize)) (!
  (=
    (mir_binop_Lt_UInt_usize_UInt_usize%limited s@$ arg1@61@00 arg2@62@00)
    (mir_binop_Lt_UInt_usize_UInt_usize s@$ arg1@61@00 arg2@62@00))
  :pattern ((mir_binop_Lt_UInt_usize_UInt_usize s@$ arg1@61@00 arg2@62@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (arg1@61@00 s_UInt_usize) (arg2@62@00 s_UInt_usize)) (!
  (mir_binop_Lt_UInt_usize_UInt_usize%stateless arg1@61@00 arg2@62@00)
  :pattern ((mir_binop_Lt_UInt_usize_UInt_usize%limited s@$ arg1@61@00 arg2@62@00))
  :qid |quant-u-51|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] s_UInt_usize_value(arg1) < s_UInt_usize_value(arg2)
; [eval] s_UInt_usize_value(arg1)
; [eval] s_UInt_usize_value(arg2)
(assert (=
  result@63@00
  (< (s_UInt_usize_value<Int> arg1@61@00) (s_UInt_usize_value<Int> arg2@62@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arg1@61@00 s_UInt_usize) (arg2@62@00 s_UInt_usize)) (!
  (=>
    (mir_binop_Lt_UInt_usize_UInt_usize%precondition s@$ arg1@61@00 arg2@62@00)
    (=
      (mir_binop_Lt_UInt_usize_UInt_usize s@$ arg1@61@00 arg2@62@00)
      (<
        (s_UInt_usize_value<Int> arg1@61@00)
        (s_UInt_usize_value<Int> arg2@62@00))))
  :pattern ((mir_binop_Lt_UInt_usize_UInt_usize s@$ arg1@61@00 arg2@62@00))
  :qid |quant-u-120|)))
(assert (forall ((s@$ $Snap) (arg1@61@00 s_UInt_usize) (arg2@62@00 s_UInt_usize)) (!
  true
  :pattern ((mir_binop_Lt_UInt_usize_UInt_usize s@$ arg1@61@00 arg2@62@00))
  :qid |quant-u-121|)))
; ---------- FUNCTION s_Bool_unreachable----------
(declare-fun result@64@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@91@00 $Snap)
(assert (= $t@91@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (= (s_Bool_unreachable%limited s@$) (s_Bool_unreachable s@$))
  :pattern ((s_Bool_unreachable s@$))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_Bool_unreachable%stateless  Bool)
  :pattern ((s_Bool_unreachable%limited s@$))
  :qid |quant-u-53|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@64@00 (s_Bool_unreachable%limited s@$))) (=>
    (s_Bool_unreachable%precondition s@$)
    false))
  :pattern ((s_Bool_unreachable%limited s@$))
  :qid |quant-u-122|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@64@00 (s_Bool_unreachable%limited s@$))) true)
  :pattern ((s_Bool_unreachable%limited s@$))
  :qid |quant-u-123|)))
; ---------- FUNCTION cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len----------
(declare-fun _1s@65@00 () s_Ref_immutable)
(declare-fun T$0@66@00 () Type)
(declare-fun result@67@00 () s_UInt_usize)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@92@00 $Snap)
(assert (= $t@92@00 $Snap.unit))
; [eval] mir_binop_Eq_UInt_usize_UInt_usize(result, mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize(s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))))))
; [eval] mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize(s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s)))))
; [eval] s_RawPtr_immutable_cons(get_s_Ref_immutable_s_Ref_immutable_0(_1s), make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))))
; [eval] get_s_Ref_immutable_s_Ref_immutable_0(_1s)
; [eval] make_generic_s_UInt_usize(get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s)))
; [eval] get_s_Param_make_concrete_s_UInt_usize(get_s_Ref_immutable_s_Ref_immutable_1(_1s))
; [eval] get_s_Ref_immutable_s_Ref_immutable_1(_1s)
(push) ; 2
(assert (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00))))))
(pop) ; 2
; Joined path conditions
(assert (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00))))))
(push) ; 2
(assert (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@67@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00)))))))
(pop) ; 2
; Joined path conditions
(assert (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@67@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00)))))))
(assert (mir_binop_Eq_UInt_usize_UInt_usize $Snap.unit result@67@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (=
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00)
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@65@00 T$0@66@00))
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%stateless _1s@65@00 T$0@66@00)
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-55|)))
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (let ((result@67@00 (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00))) (=>
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@65@00 T$0@66@00)
    (mir_binop_Eq_UInt_usize_UInt_usize $Snap.unit result@67@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00))))))))
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-124|)))
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (let ((result@67@00 (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00))) (=>
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@65@00 T$0@66@00)
    (and
      (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize%precondition $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00)))))
      (mir_binop_Eq_UInt_usize_UInt_usize%precondition $Snap.unit result@67@00 (mir_unop_PtrMetadata_RawPtr_immutable_UInt_usize $Snap.unit (s_RawPtr_immutable_cons<s_RawPtr_immutable> (get_s_Ref_immutable_s_Ref_immutable_0<Ref> _1s@65@00) (make_generic_s_UInt_usize<s_Param> (get_s_Param_make_concrete_s_UInt_usize<s_UInt_usize> (get_s_Ref_immutable_s_Ref_immutable_1<s_Param> _1s@65@00)))))))))
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%limited s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-125|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len(_1s, T$0)
(push) ; 2
(assert (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition $Snap.unit _1s@65@00 T$0@66@00))
(pop) ; 2
; Joined path conditions
(assert (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition $Snap.unit _1s@65@00 T$0@66@00))
(assert (=
  result@67@00
  (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len $Snap.unit _1s@65@00 T$0@66@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (=>
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@65@00 T$0@66@00)
    (=
      (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@65@00 T$0@66@00)
      (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len $Snap.unit _1s@65@00 T$0@66@00)))
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-126|)))
(assert (forall ((s@$ $Snap) (_1s@65@00 s_Ref_immutable) (T$0@66@00 Type)) (!
  (=>
    (cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition s@$ _1s@65@00 T$0@66@00)
    (f_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len%precondition $Snap.unit _1s@65@00 T$0@66@00))
  :pattern ((cf_core$col$$col$slice$col$$col$$lt$impl$sp$$lb$T$rb$$gt$$col$$col$len s@$ _1s@65@00 T$0@66@00))
  :qid |quant-u-127|)))
; ---------- FUNCTION p_UInt_usize_snap----------
(declare-fun self@68@00 () $Ref)
(declare-fun result@69@00 () s_UInt_usize)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@68@00 $Ref)) (!
  (=
    (p_UInt_usize_snap%limited s@$ self@68@00)
    (p_UInt_usize_snap s@$ self@68@00))
  :pattern ((p_UInt_usize_snap s@$ self@68@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (self@68@00 $Ref)) (!
  (p_UInt_usize_snap%stateless self@68@00)
  :pattern ((p_UInt_usize_snap%limited s@$ self@68@00))
  :qid |quant-u-57|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; [eval] (unfolding acc(p_UInt_usize(self), write) in self.p_UInt_usize_val)
(push) ; 2
(assert (p_UInt_usize%trigger s@$ self@68@00))
(assert (not (= self@68@00 $Ref.null)))
(pop) ; 2
; Joined path conditions
(assert (and (p_UInt_usize%trigger s@$ self@68@00) (not (= self@68@00 $Ref.null))))
(assert (= result@69@00 ($SortWrappers.$SnapTos_UInt_usize s@$)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@68@00 $Ref)) (!
  (=>
    (p_UInt_usize_snap%precondition s@$ self@68@00)
    (=
      (p_UInt_usize_snap s@$ self@68@00)
      ($SortWrappers.$SnapTos_UInt_usize s@$)))
  :pattern ((p_UInt_usize_snap s@$ self@68@00))
  :qid |quant-u-128|)))
(assert (forall ((s@$ $Snap) (self@68@00 $Ref)) (!
  true
  :pattern ((p_UInt_usize_snap s@$ self@68@00))
  :qid |quant-u-129|)))
; ---------- FUNCTION s_Param_unreachable----------
(declare-fun T$0@70@00 () Type)
(declare-fun result@71@00 () s_Param)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@93@00 $Snap)
(assert (= $t@93@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap) (T$0@70@00 Type)) (!
  (=
    (s_Param_unreachable%limited s@$ T$0@70@00)
    (s_Param_unreachable s@$ T$0@70@00))
  :pattern ((s_Param_unreachable s@$ T$0@70@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (T$0@70@00 Type)) (!
  (s_Param_unreachable%stateless T$0@70@00)
  :pattern ((s_Param_unreachable%limited s@$ T$0@70@00))
  :qid |quant-u-59|)))
(assert (forall ((s@$ $Snap) (T$0@70@00 Type)) (!
  (let ((result@71@00 (s_Param_unreachable%limited s@$ T$0@70@00))) (=>
    (s_Param_unreachable%precondition s@$ T$0@70@00)
    false))
  :pattern ((s_Param_unreachable%limited s@$ T$0@70@00))
  :qid |quant-u-130|)))
(assert (forall ((s@$ $Snap) (T$0@70@00 Type)) (!
  (let ((result@71@00 (s_Param_unreachable%limited s@$ T$0@70@00))) true)
  :pattern ((s_Param_unreachable%limited s@$ T$0@70@00))
  :qid |quant-u-131|)))
; ---------- FUNCTION s_0_Tuple_unreachable----------
(declare-fun result@72@00 () s_0_Tuple)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@94@00 $Snap)
(assert (= $t@94@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (= (s_0_Tuple_unreachable%limited s@$) (s_0_Tuple_unreachable s@$))
  :pattern ((s_0_Tuple_unreachable s@$))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_0_Tuple_unreachable%stateless  Bool)
  :pattern ((s_0_Tuple_unreachable%limited s@$))
  :qid |quant-u-61|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@72@00 (s_0_Tuple_unreachable%limited s@$))) (=>
    (s_0_Tuple_unreachable%precondition s@$)
    false))
  :pattern ((s_0_Tuple_unreachable%limited s@$))
  :qid |quant-u-132|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@72@00 (s_0_Tuple_unreachable%limited s@$))) true)
  :pattern ((s_0_Tuple_unreachable%limited s@$))
  :qid |quant-u-133|)))
; ---------- FUNCTION s_UInt_usize_unreachable----------
(declare-fun result@73@00 () s_UInt_usize)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@95@00 $Snap)
(assert (= $t@95@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap)) (!
  (= (s_UInt_usize_unreachable%limited s@$) (s_UInt_usize_unreachable s@$))
  :pattern ((s_UInt_usize_unreachable s@$))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap)) (!
  (as s_UInt_usize_unreachable%stateless  Bool)
  :pattern ((s_UInt_usize_unreachable%limited s@$))
  :qid |quant-u-63|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@73@00 (s_UInt_usize_unreachable%limited s@$))) (=>
    (s_UInt_usize_unreachable%precondition s@$)
    false))
  :pattern ((s_UInt_usize_unreachable%limited s@$))
  :qid |quant-u-134|)))
(assert (forall ((s@$ $Snap)) (!
  (let ((result@73@00 (s_UInt_usize_unreachable%limited s@$))) true)
  :pattern ((s_UInt_usize_unreachable%limited s@$))
  :qid |quant-u-135|)))
; ---------- FUNCTION s_RawPtr_immutable_unreachable----------
(declare-fun T$0@74@00 () Type)
(declare-fun result@75@00 () s_RawPtr_immutable)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@96@00 $Snap)
(assert (= $t@96@00 $Snap.unit))
(assert false)
(pop) ; 1
(assert (forall ((s@$ $Snap) (T$0@74@00 Type)) (!
  (=
    (s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00)
    (s_RawPtr_immutable_unreachable s@$ T$0@74@00))
  :pattern ((s_RawPtr_immutable_unreachable s@$ T$0@74@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (T$0@74@00 Type)) (!
  (s_RawPtr_immutable_unreachable%stateless T$0@74@00)
  :pattern ((s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00))
  :qid |quant-u-65|)))
(assert (forall ((s@$ $Snap) (T$0@74@00 Type)) (!
  (let ((result@75@00 (s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00))) (=>
    (s_RawPtr_immutable_unreachable%precondition s@$ T$0@74@00)
    false))
  :pattern ((s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00))
  :qid |quant-u-136|)))
(assert (forall ((s@$ $Snap) (T$0@74@00 Type)) (!
  (let ((result@75@00 (s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00))) true)
  :pattern ((s_RawPtr_immutable_unreachable%limited s@$ T$0@74@00))
  :qid |quant-u-137|)))
; ---------- p_0_Tuple ----------
(declare-const $t@97@00 $Snap)
(declare-const self@98@00 $Ref)
(push) ; 1
(assert (= $t@97@00 $Snap.unit))
(pop) ; 1
; ---------- p_Ref_mutable ----------
(declare-const $t@99@00 $Snap)
(declare-const self@100@00 $Ref)
(declare-const U$1@101@00 Type)
(push) ; 1
(assert (= $t@99@00 ($Snap.combine ($Snap.first $t@99@00) ($Snap.second $t@99@00))))
(assert (not (= self@100@00 $Ref.null)))
(assert (=
  ($Snap.second $t@99@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@99@00))
    ($Snap.second ($Snap.second $t@99@00)))))
(assert (= ($Snap.second ($Snap.second $t@99@00)) $Snap.unit))
; [eval] s_Param_typ(self.p_Ref_mutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(self.p_Ref_mutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second $t@99@00))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@101@00)))
(pop) ; 1
; ---------- p_Param ----------
(declare-const $t@102@00 $Snap)
(declare-const self@103@00 $Ref)
(declare-const T$0@104@00 Type)
; ---------- p_Slice ----------
(declare-const $t@105@00 $Snap)
(declare-const self@106@00 $Ref)
(declare-const T$0@107@00 Type)
; ---------- p_Slice_index ----------
(declare-const $t@108@00 $Snap)
(declare-const self@109@00 $Ref)
(declare-const index@110@00 Int)
(declare-const T$0@111@00 Type)
; ---------- p_UInt_usize ----------
(declare-const $t@112@00 $Snap)
(declare-const self@113@00 $Ref)
(push) ; 1
(assert (not (= self@113@00 $Ref.null)))
(pop) ; 1
; ---------- p_Ref_immutable ----------
(declare-const $t@114@00 $Snap)
(declare-const self@115@00 $Ref)
(declare-const U$1@116@00 Type)
(push) ; 1
(assert (= $t@114@00 ($Snap.combine ($Snap.first $t@114@00) ($Snap.second $t@114@00))))
(assert (not (= self@115@00 $Ref.null)))
(assert (=
  ($Snap.second $t@114@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@114@00))
    ($Snap.second ($Snap.second $t@114@00)))))
(assert (=
  ($Snap.second ($Snap.second $t@114@00))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@114@00)))
    ($Snap.second ($Snap.second ($Snap.second $t@114@00))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@114@00))) $Snap.unit))
; [eval] s_Param_typ(self.p_Ref_immutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
; [eval] s_Param_typ(self.p_Ref_immutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(U$1)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second $t@114@00))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> U$1@116@00)))
; [eval] read()
(push) ; 2
(set-option :rlimit 100000000)
(assert (not (or (= (as read<Perm>  $Perm) $Perm.No) (< $Perm.No (as read<Perm>  $Perm)))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= $Perm.No (as read<Perm>  $Perm)))
(pop) ; 1
; ---------- p_UInt_u32 ----------
(declare-const $t@117@00 $Snap)
(declare-const self@118@00 $Ref)
(set-option :rlimit 0)
(push) ; 1
(assert (not (= self@118@00 $Ref.null)))
(pop) ; 1
; ---------- p_RawPtr_immutable ----------
(declare-const $t@119@00 $Snap)
(declare-const self@120@00 $Ref)
(declare-const T$0@121@00 Type)
(push) ; 1
(assert (= $t@119@00 ($Snap.combine ($Snap.first $t@119@00) ($Snap.second $t@119@00))))
(assert (not (= self@120@00 $Ref.null)))
(assert (=
  ($Snap.second $t@119@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@119@00))
    ($Snap.second ($Snap.second $t@119@00)))))
(assert (= ($Snap.second ($Snap.second $t@119@00)) $Snap.unit))
; [eval] s_Param_typ(self.p_RawPtr_immutable_metadata) == std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
; [eval] s_Param_typ(self.p_RawPtr_immutable_metadata)
; [eval] std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata(T$0)
(assert (=
  (s_Param_typ<Type> ($SortWrappers.$SnapTos_Param ($Snap.first ($Snap.second $t@119@00))))
  (std$col$$col$ptr$col$$col$Pointee_assoc_type_std$col$$col$ptr$col$$col$Pointee$col$$col$Metadata<Type> T$0@121@00)))
(pop) ; 1
; ---------- p_Bool ----------
(declare-const $t@122@00 $Snap)
(declare-const self@123@00 $Ref)
(push) ; 1
(assert (not (= self@123@00 $Ref.null)))
(pop) ; 1
; ---------- indexed_p_Param ----------
(declare-const $t@124@00 $Snap)
(declare-const index@125@00 Int)
(declare-const path@126@00 Seq<Int>)
(declare-const arg0@127@00 $Ref)
(declare-const arg1@128@00 Type)
(push) ; 1
(pop) ; 1
