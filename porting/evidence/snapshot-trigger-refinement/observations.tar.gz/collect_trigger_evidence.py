from pathlib import Path
import collections, hashlib, importlib.util, json, re, shutil, subprocess, sys, tarfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/will/wk/exp/ferrum')
sys.path.insert(0,str(REPO/'tools/performance/smt'))
from analyze_trace import analyze, canonical, expressions

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_text())
def dump(p,x):
    p.write_text(json.dumps(x,indent=2)+'\n')

def stream_rows(root):
    rows=[]
    for folder in sorted(root.iterdir()):
        d=analyze(folder)
        dump(folder/'analysis.json',d)
        rows.append({k:d[k] for k in ['folder','issues','input_sha256','output_sha256','command_counts','response_count']})
    return rows

def signatures(rows):
    return sorted((r['input_sha256'],r['output_sha256']) for r in rows)

names=['allocation-append-separate','trigger-append-separate','trigger-append-default',
       'trigger-append-cache','trigger-append-old-cache','trigger-append-wrong',
       'trigger-append-wrong-nocache','trigger-graph','allocation-quickselect',
       'trigger-quickselect-cpu4','trigger-quickselect','allocation-nested']
rows={}
for name in names:
    folder=ROOT/name
    manifest=read(folder/'manifest.json')
    assert sha(Path(manifest['input']))==manifest['input_sha256']
    assert sha(Path(manifest['command'][3]))==manifest['binary_sha256']
    runner_hash=manifest['runner_sha256']
    assert runner_hash in [sha(ROOT/'run_case.py'),sha(ROOT/'run_case_initial.py')]
    result=read(folder/'result.json')
    assert not result['protocol_errors'] and not result['cleanup_pending']
    streams=stream_rows(folder/'streams') if (folder/'streams').exists() else []
    if result['outcome']=='completed':
        assert len(result['records'])==1
        timeout=result['records'][0]['outcome']=='verifier_timeout'
        for stream in streams:
            assert not stream['issues'] or (timeout and len(stream['issues'])==1 and re.fullmatch(r'Missing response to command \d+ check-sat',stream['issues'][0])),stream
    rows[name]={'manifest':manifest,'result':result,'streams':streams}
assert signatures(rows['trigger-append-cache']['streams'])==signatures(rows['trigger-append-old-cache']['streams'])
assert signatures(rows['trigger-quickselect-cpu4']['streams'])==signatures(rows['allocation-quickselect']['streams'])
for name,outcome in [('allocation-append-separate','failure'),('trigger-append-separate','verified'),('trigger-append-wrong-nocache','failure'),('trigger-quickselect-cpu4','verified')]:
    assert rows[name]['result']['records'][0]['outcome']==outcome
assert rows['trigger-append-wrong-nocache']['result']['records'][0]['errors'][0]['id']=='postcondition.violated:assertion.false'

prusti={}
for label in ['trigger-prusti-nested','trigger-prusti-nested-old']:
    folder=ROOT/label
    result=read(folder/'result.json');audit=read(folder/'audit.json')
    assert result['classification']=='valid' and not result['timed_out']
    assert result['dependency_check']['valid'] and not result['service_cleanup']['cleanup_pending']
    assert sha(Path(result['server']))==result['server_sha256']
    assert sha(Path(result['source']))==result['source_sha256']
    for stream in audit['streams']:
        assert stream['replay']['original_response_prefix_equal']
        assert stream['replay']['exit_code']==0 and not stream['replay']['timed_out']
    prusti[label]={'result':result,'audit':audit}
new_folder=next((ROOT/'trigger-prusti-nested/smt').iterdir())
old_folder=next((ROOT/'trigger-prusti-nested-old/smt').iterdir())
new=(new_folder/'stdin.bin').read_bytes();old=(old_folder/'stdin.bin').read_bytes()
new_cmds=[new[a:b] for a,b in expressions(new)]
old_cmds=[old[a:b] for a,b in expressions(old)]
assert len(new_cmds)==len(old_cmds)
changed=[]
for i,(a,b) in enumerate(zip(old_cmds,new_cmds)):
    if a==b:continue
    assert b'qp.psmValDef' in a and b'qp.psmValDef' in b
    patterns=list(re.finditer(rb':pattern\s+',a))
    assert len(patterns)==2 and len(list(re.finditer(rb':pattern\s+',b)))==1
    match=patterns[1];start,end=next(expressions(a[match.end():]))
    pruned=a[:match.start()]+a[match.end()+end:]
    assert canonical(pruned)==canonical(b)
    changed.append(i)
assert len(changed)==136
assert (new_folder/'stdout.bin').read_bytes()==(old_folder/'stdout.bin').read_bytes()
previous=next(Path('/tmp/ferrum-solver-work-0e1bf91/trigger-nested-trace/smt').iterdir())
assert new==(previous/'stdin.bin').read_bytes()
assert (new_folder/'stdout.bin').read_bytes()==(previous/'stdout.bin').read_bytes()

source=read(ROOT/'trigger-source.json')
for path,h in source['files'].items():assert sha(REPO/path)==h,path
fixture=REPO/'tests/fixtures/snapshot_summary_append.vpr'
upstream=Path(rows['trigger-append-separate']['manifest']['input'])
assert fixture.read_text()== '\n'.join(line.expandtabs(4).rstrip() for line in upstream.read_text().splitlines()).rstrip()+'\n'

inputs=ROOT/'trigger-inputs';inputs.mkdir(exist_ok=True)
for label in ['trigger-append-separate','trigger-append-wrong-nocache','trigger-graph','trigger-quickselect-cpu4','allocation-nested']:
    p=Path(rows[label]['manifest']['input']);shutil.copyfile(p,inputs/p.name)
for label in prusti:
    p=Path(prusti[label]['result']['source']);shutil.copyfile(p,inputs/p.name)
shutil.copyfile(fixture,inputs/fixture.name)
checks={
    'unit':'trigger-unit-all.log','policy_unit':'trigger-unit-build.log',
    'real_z3':'trigger-integration-final.log','workspace_native_z3':'trigger-workspace-check.log'}
assert '309 passed; 0 failed; 43 ignored' in (ROOT/checks['unit']).read_text()
assert '1 passed; 0 failed' in (ROOT/checks['real_z3']).read_text()
assert 'Finished' in (ROOT/checks['workspace_native_z3']).read_text()
result={
    'base_revision':source['base'],
    'compatibility_patch':'trigger-candidate.patch',
    'server_runtime_patch':'trigger-runtime.patch',
    'source_manifest':source,
    'standalone':rows,
    'direct_prusti':prusti,
    'direct_prusti_comparison':{'changed_commands':changed,'only_removed_original_lookup_patterns':True,
        'response_streams_identical':True,'prior_optimized_input_and_output_byte_identical':True,
        'prior_capture':str(previous),'cache_enabled_append_prefixes_identical':True,
        'quickselect_complete_streams_identical':True},
    'checks':{k:{'file':v,'sha256':sha(ROOT/v)} for k,v in checks.items()},
    'regression_fixture_sha256':sha(fixture),
    'limitations':['No fresh full stdlib matrix.','Append retained-solver and cache-on variants still timeout.',
        'Graph-marking still times out.','Timings are single traced observations on a shared host.']}
dump(ROOT/'trigger-results.json',result)

# Keep raw captures, audits, scripts, patches and logs; exclude executable binaries
# and deleted scratch dependencies. Replay SMT is retained for independent reruns.
files=[]
for name in names+list(prusti)+['trigger-inputs']:
    for p in sorted((ROOT/name).rglob('*')):
        if p.is_file():files.append(p)
for pattern in ['trigger-*.log','trigger-*.patch','trigger-source.json','trigger-results.json']:
    files+=list(ROOT.glob(pattern))
for name in ['run_case.py','run_case_initial.py','run_direct.py','audit_trial.py','collect_trigger_evidence.py']:
    files.append(ROOT/name)
files=sorted(set(files))
index={str(p.relative_to(ROOT)):sha(p) for p in files}
dump(ROOT/'trigger-evidence-index.json',index)
files.append(ROOT/'trigger-evidence-index.json')
archive=REPO/'porting/evidence/snapshot-trigger-refinement/observations.tar.gz'
archive.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive,'w:gz') as tf:
    for p in files:tf.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
result['evidence']={'archive':str(archive.relative_to(REPO)),'sha256':sha(archive),
    'files':len(files),'bytes':archive.stat().st_size}
dump(REPO/'porting/snapshot-trigger-refinement.json',result)
print(json.dumps(result['evidence']))
