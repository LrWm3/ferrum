from pathlib import Path
import sys,json,collections
sys.path.insert(0,'/home/will/wk/exp/ferrum/tools/performance/smt')
from analyze_trace import analyze
from run_saturation import offline
root=Path(sys.argv[1]);results=[]
for f in sorted((root/'smt').iterdir()):
 metadata=json.loads((f/'metadata.json').read_text())
 if '-in' not in metadata['argv']:continue
 report=analyze(f);(f/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
 if report['issues']:raise ValueError(report['issues'])
 replay=offline({'z3':'/home/will/wk/exp/prusti-stdlib/viper_tools/z3/bin/z3','offline_timeout':45},f,report,'0,1,2,3')
 results.append({'capture':str(f),'queries':len(report['queries']),'input_sha256':report['input_sha256'],'output_sha256':report['output_sha256'],'commands':report['command_counts'],'replay':replay})
 assert replay['original_response_prefix_equal'] and replay['exit_code']==0 and not replay['timed_out']
summary={'streams':results,'instantiations':sum(int(r['replay']['statistics'].get('quant-instantiations',0)) for r in results),'resources':sum(int(r['replay']['statistics'].get('rlimit-count',0)) for r in results),'checks':sum(r['queries'] for r in results)}
(root/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='streams'}))
