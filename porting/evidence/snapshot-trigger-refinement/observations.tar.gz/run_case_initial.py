#!/usr/bin/env python3
"""Bounded standalone verification with optional exact SMT byte capture."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/will/wk/exp/ferrum')
Z3 = '/home/will/wk/exp/prusti-stdlib/viper_tools/z3/bin/z3'
REF = Path('/tmp/ferrum-reference-silicon/silver/src/test/resources')
CASES = {
    'wand': REF / 'examples/vmcai2016/linked-list-predicates-with-wands.vpr',
    'append': REF / 'quantifiedpermissions/sequences/linked-list-qp-append.vpr',
    'graph': REF / 'examples/graph-marking/graph-marking.vpr',
    'quickselect': REF / 'examples/quickselect/arrays_quickselect_rec.vpr',
    'nested': REPO / 'tools/performance/fixtures/mut_element_nested_pass.vpr',
    'array': REPO / 'tools/performance/fixtures/mut_element_array_pass.vpr',
    'array-wrong': REPO / 'tools/performance/fixtures/mut_element_array_wrong.vpr',
}

def sha(p):
    with open(p, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('label')
    p.add_argument('binary')
    p.add_argument('case')
    p.add_argument('--seconds', type=int, default=30)
    p.add_argument('--cpus', default='0-3')
    p.add_argument('--trace', action='store_true')
    p.add_argument('--extra', action='append', default=[])
    a = p.parse_args()
    out = ROOT / a.label
    out.mkdir()
    path = CASES.get(a.case, Path(a.case)).resolve()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('FERRUM_', 'PRUSTI_', 'DEFAULT_PRUSTI_', 'Z3_'))}
    solver = Z3
    if a.trace:
        proxy = out / 'z3-relay'
        proxy.write_text('#!/usr/bin/env python3\nimport os,sys\nos.environ["FERRUM_SMT_REAL_Z3"]='+repr(Z3)+'\nos.environ["FERRUM_SMT_TRACE_ROOT"]='+repr(str(out/'streams'))+'\nos.execv(sys.executable,[sys.executable,'+repr(str(REPO/'tools/performance/smt/trace_z3_v2.py'))+',*sys.argv[1:]])\n')
        proxy.chmod(0o755)
        solver = str(proxy)
    opts = ['--timeout', str(a.seconds), '--numberOfParallelVerifiers=1', '--parallelizeBranches=false'] + a.extra
    cmd = ['taskset', '-c', a.cpus, str(Path(a.binary).resolve()), solver] + opts + ['--', str(path)]
    manifest = {'case': a.case, 'input': str(path), 'input_sha256': sha(path),
                'binary_sha256': sha(a.binary), 'z3_sha256': sha(Z3),
                'runner_sha256': sha(__file__), 'command': cmd, 'started': time.time(), 'load': os.getloadavg()}
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    runner = [sys.executable, str(REPO/'tools/compatibility/run_session.py'), '--timeout', str(a.seconds+35), '--output', str(out/'result.json'), '--'] + cmd
    with (out/'runner.log').open('w') as log:
        subprocess.run(runner, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    result = json.loads((out/'result.json').read_text())
    assert result['outcome'] == 'completed', result
    assert not result['cleanup_pending'] and not result['protocol_errors']
    assert len(result['records']) == 1 and result['records'][0]['case'] == str(path)
    assert sha(a.binary) == manifest['binary_sha256'] and sha(path) == manifest['input_sha256']
    if a.trace:
        spec = importlib.util.spec_from_file_location('audit', REPO/'tools/performance/smt/analyze_trace.py')
        audit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(audit)
        for folder in (out/'streams').iterdir():
            d = audit.analyze(folder)
            (folder/'analysis.json').write_text(json.dumps(d, indent=2)+'\n')
            expected = [] if result['records'][0]['outcome'] != 'verifier_timeout' else [f"Missing response to command {len(d['commands'])-1} check-sat"]
            assert d['issues'] == expected, d['issues']
    row = result['records'][0]
    print(a.label, row['outcome'], round(result['wall_seconds'], 3), [(e['id'],e['position']) for e in row.get('errors',[])], flush=True)

if __name__ == '__main__':
    main()
