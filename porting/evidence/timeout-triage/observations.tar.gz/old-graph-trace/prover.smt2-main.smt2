(get-info :version)
; (:version "4.16.0")
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :model.partial true)
(set-option :smt.qi.max_multi_patterns 1000)
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-const $Snap.null $Snap) ; hack
(declare-fun internalCondFrame (Bool $Snap $Snap) $Snap)
(assert (forall ((cnd Bool) (frst $Snap) (scnd $Snap)) (!
    (= (internalCondFrame cnd frst scnd) (ite cnd frst scnd))
    :pattern ((internalCondFrame cnd frst scnd)))))
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(declare-fun $Perm.min ($Perm $Perm) $Perm)
(assert (forall ((p1 $Perm) (p2 $Perm)) (!
    (= ($Perm.min p1 p2) (ite (<= p1 p2) p1 p2))
    :pattern (($Perm.min p1 p2)))))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
(declare-sort Set<Bool> 0)
(declare-sort Set<$Ref> 0)
(declare-sort Set<$Snap> 0)
(declare-fun Set_card (Set<Bool>) Int)
(declare-const Set_empty Set<Bool>)
(declare-fun Set_in (Bool Set<Bool>) Bool)
(declare-fun Set_singleton (Bool) Set<Bool>)
(declare-fun Set_unionone (Set<Bool> Bool) Set<Bool>)
(declare-fun Set_union (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_intersection (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_difference (Set<Bool> Set<Bool>) Set<Bool>)
(declare-fun Set_subset (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_equal (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_skolem_diff (Set<Bool> Set<Bool>) Bool)
(declare-fun Set_card (Set<$Ref>) Int)
(declare-const Set_empty Set<$Ref>)
(declare-fun Set_in ($Ref Set<$Ref>) Bool)
(declare-fun Set_singleton ($Ref) Set<$Ref>)
(declare-fun Set_unionone (Set<$Ref> $Ref) Set<$Ref>)
(declare-fun Set_union (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_intersection (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_difference (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_subset (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_equal (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_skolem_diff (Set<$Ref> Set<$Ref>) $Ref)
(declare-fun Set_card (Set<$Snap>) Int)
(declare-const Set_empty Set<$Snap>)
(declare-fun Set_in ($Snap Set<$Snap>) Bool)
(declare-fun Set_singleton ($Snap) Set<$Snap>)
(declare-fun Set_unionone (Set<$Snap> $Snap) Set<$Snap>)
(declare-fun Set_union (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_intersection (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_difference (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_subset (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_equal (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_skolem_diff (Set<$Snap> Set<$Snap>) $Snap)
(declare-sort $FVF<left> 0)
(declare-sort $FVF<right> 0)
(declare-sort $FVF<is_marked> 0)
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
(declare-fun $SortWrappers.Set<Bool>To$Snap (Set<Bool>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Bool> ($Snap) Set<Bool>)
(assert (forall ((x Set<Bool>)) (!
    (= x ($SortWrappers.$SnapToSet<Bool>($SortWrappers.Set<Bool>To$Snap x)))
    :pattern (($SortWrappers.Set<Bool>To$Snap x))
    :qid |$Snap.$SnapToSet<Bool>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Bool>To$Snap($SortWrappers.$SnapToSet<Bool> x)))
    :pattern (($SortWrappers.$SnapToSet<Bool> x))
    :qid |$Snap.Set<Bool>To$SnapToSet<Bool>|
    )))
(declare-fun $SortWrappers.Set<$Ref>To$Snap (Set<$Ref>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Ref> ($Snap) Set<$Ref>)
(assert (forall ((x Set<$Ref>)) (!
    (= x ($SortWrappers.$SnapToSet<$Ref>($SortWrappers.Set<$Ref>To$Snap x)))
    :pattern (($SortWrappers.Set<$Ref>To$Snap x))
    :qid |$Snap.$SnapToSet<$Ref>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Ref>To$Snap($SortWrappers.$SnapToSet<$Ref> x)))
    :pattern (($SortWrappers.$SnapToSet<$Ref> x))
    :qid |$Snap.Set<$Ref>To$SnapToSet<$Ref>|
    )))
(declare-fun $SortWrappers.Set<$Snap>To$Snap (Set<$Snap>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Snap> ($Snap) Set<$Snap>)
(assert (forall ((x Set<$Snap>)) (!
    (= x ($SortWrappers.$SnapToSet<$Snap>($SortWrappers.Set<$Snap>To$Snap x)))
    :pattern (($SortWrappers.Set<$Snap>To$Snap x))
    :qid |$Snap.$SnapToSet<$Snap>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Snap>To$Snap($SortWrappers.$SnapToSet<$Snap> x)))
    :pattern (($SortWrappers.$SnapToSet<$Snap> x))
    :qid |$Snap.Set<$Snap>To$SnapToSet<$Snap>|
    )))
(declare-fun $SortWrappers.$FVF<left>To$Snap ($FVF<left>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<left> ($Snap) $FVF<left>)
(assert (forall ((x $FVF<left>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<left>($SortWrappers.$FVF<left>To$Snap x)))
    :pattern (($SortWrappers.$FVF<left>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<left>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<left>To$Snap($SortWrappers.$SnapTo$FVF<left> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<left> x))
    :qid |$Snap.$FVF<left>To$SnapTo$FVF<left>|
    )))
(declare-fun $SortWrappers.$FVF<right>To$Snap ($FVF<right>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<right> ($Snap) $FVF<right>)
(assert (forall ((x $FVF<right>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<right>($SortWrappers.$FVF<right>To$Snap x)))
    :pattern (($SortWrappers.$FVF<right>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<right>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<right>To$Snap($SortWrappers.$SnapTo$FVF<right> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<right> x))
    :qid |$Snap.$FVF<right>To$SnapTo$FVF<right>|
    )))
(declare-fun $SortWrappers.$FVF<is_marked>To$Snap ($FVF<is_marked>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<is_marked> ($Snap) $FVF<is_marked>)
(assert (forall ((x $FVF<is_marked>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<is_marked>($SortWrappers.$FVF<is_marked>To$Snap x)))
    :pattern (($SortWrappers.$FVF<is_marked>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<is_marked>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<is_marked>To$Snap($SortWrappers.$SnapTo$FVF<is_marked> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<is_marked> x))
    :qid |$Snap.$FVF<is_marked>To$SnapTo$FVF<is_marked>|
    )))
; /field_value_functions_declarations.smt2 [left: Ref]
(declare-fun $FVF.domain_left ($FVF<left>) Set<$Ref>)
(declare-fun $FVF.has_domain_left ($FVF<left>) Bool)
(declare-fun $FVF.lookup_left ($FVF<left> $Ref) $Ref)
(declare-fun $FVF.after_left ($FVF<left> $FVF<left>) Bool)
(declare-fun $FVF.loc_left ($Ref $Ref) Bool)
(declare-fun $FVF.perm_left ($FPM $Ref) $Perm)
(declare-const $fvfTOP_left $FVF<left>)
; /field_value_functions_declarations.smt2 [right: Ref]
(declare-fun $FVF.domain_right ($FVF<right>) Set<$Ref>)
(declare-fun $FVF.has_domain_right ($FVF<right>) Bool)
(declare-fun $FVF.lookup_right ($FVF<right> $Ref) $Ref)
(declare-fun $FVF.after_right ($FVF<right> $FVF<right>) Bool)
(declare-fun $FVF.loc_right ($Ref $Ref) Bool)
(declare-fun $FVF.perm_right ($FPM $Ref) $Perm)
(declare-const $fvfTOP_right $FVF<right>)
; /field_value_functions_declarations.smt2 [is_marked: Bool]
(declare-fun $FVF.domain_is_marked ($FVF<is_marked>) Set<$Ref>)
(declare-fun $FVF.has_domain_is_marked ($FVF<is_marked>) Bool)
(declare-fun $FVF.lookup_is_marked ($FVF<is_marked> $Ref) Bool)
(declare-fun $FVF.after_is_marked ($FVF<is_marked> $FVF<is_marked>) Bool)
(declare-fun $FVF.loc_is_marked (Bool $Ref) Bool)
(declare-fun $FVF.perm_is_marked ($FPM $Ref) $Perm)
(declare-const $fvfTOP_is_marked $FVF<is_marked>)
; Declaring predicate trigger functions
(assert (forall ((s Set<Bool>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Bool]_prog.Set_card_nonneg|)))
(assert (forall ((o Bool)) (! (not (Set_in o (as Set_empty Set<Bool>))) :pattern ((Set_in o (as Set_empty Set<Bool>))) :qid |$Set[Bool]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Bool>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<Bool>))) (=> (not (= (Set_card s) 0)) (exists ((x Bool)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Bool]_prog.Set_card_zero|)))
(assert (forall ((r Bool)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Bool]_prog.Set_singleton_contains1|)))
(assert (forall ((r Bool) (o Bool)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Bool]_prog.Set_singleton_contains2|)))
(assert (forall ((r Bool)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Bool]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Bool>) (x Bool) (o Bool)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Bool]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Bool>) (x Bool)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Bool]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Bool>) (x Bool) (y Bool)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Bool]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Bool>) (x Bool)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Bool]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Bool>) (x Bool)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Bool]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Bool]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Bool]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Bool]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Bool]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Bool]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Bool]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Bool]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Bool]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Bool]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (o Bool)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Bool]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>) (y Bool)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Bool]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Bool]_prog.Set_diff_card|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (= (Set_subset a b) (forall ((o Bool)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Bool]_prog.Set_subset_def|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Bool]_prog.Set_equal_def|)))
(assert (forall ((a Set<Bool>) (b Set<Bool>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Bool]_prog.Set_equal_ext|)))
(assert (forall ((s Set<$Ref>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Ref]_prog.Set_card_nonneg|)))
(assert (forall ((o $Ref)) (! (not (Set_in o (as Set_empty Set<$Ref>))) :pattern ((Set_in o (as Set_empty Set<$Ref>))) :qid |$Set[Ref]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Ref>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<$Ref>))) (=> (not (= (Set_card s) 0)) (exists ((x $Ref)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Ref]_prog.Set_card_zero|)))
(assert (forall ((r $Ref)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Ref]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Ref) (o $Ref)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Ref]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Ref)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Ref]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (o $Ref)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Ref]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (y $Ref)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Ref]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Ref]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Ref]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Ref]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Ref]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Ref]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Ref]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Ref]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Ref]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Ref]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Ref]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Ref]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Ref]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_subset a b) (forall ((o $Ref)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Ref]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Ref]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Ref]_prog.Set_equal_ext|)))
(assert (forall ((s Set<$Snap>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Snap]_prog.Set_card_nonneg|)))
(assert (forall ((o $Snap)) (! (not (Set_in o (as Set_empty Set<$Snap>))) :pattern ((Set_in o (as Set_empty Set<$Snap>))) :qid |$Set[Snap]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Snap>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<$Snap>))) (=> (not (= (Set_card s) 0)) (exists ((x $Snap)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Snap]_prog.Set_card_zero|)))
(assert (forall ((r $Snap)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Snap]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Snap) (o $Snap)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Snap]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Snap)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Snap]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (o $Snap)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Snap]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (y $Snap)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Snap]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Snap]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Snap]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Snap]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Snap]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Snap]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Snap]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Snap]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Snap]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Snap]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Snap]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Snap]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Snap]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_subset a b) (forall ((o $Snap)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Snap]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Snap]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Snap]_prog.Set_equal_ext|)))
; /field_value_functions_axioms.smt2 [left: Ref]
(assert (forall ((vs $FVF<left>) (ws $FVF<left>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_left vs) ($FVF.domain_left ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_left vs))
            (= ($FVF.lookup_left vs x) ($FVF.lookup_left ws x)))
          :pattern (($FVF.lookup_left vs x) ($FVF.lookup_left ws x))
          :qid |qp.$FVF<left>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<left>To$Snap vs) ($FVF.has_domain_left vs)
              ($SortWrappers.$FVF<left>To$Snap ws) ($FVF.has_domain_left ws)
              )
    :qid |qp.$FVF<left>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_left pm r))
    :pattern (($FVF.perm_left pm r))
    :qid |qp.$FVF<left>-validvar|)))
(assert (forall ((r $Ref) (f $Ref)) (!
    (= ($FVF.loc_left f r) true)
    :pattern (($FVF.loc_left f r))
    :qid |qp.$FVF<left>-loc|)))
; /field_value_functions_axioms.smt2 [right: Ref]
(assert (forall ((vs $FVF<right>) (ws $FVF<right>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_right vs) ($FVF.domain_right ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_right vs))
            (= ($FVF.lookup_right vs x) ($FVF.lookup_right ws x)))
          :pattern (($FVF.lookup_right vs x) ($FVF.lookup_right ws x))
          :qid |qp.$FVF<right>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<right>To$Snap vs) ($FVF.has_domain_right vs)
              ($SortWrappers.$FVF<right>To$Snap ws) ($FVF.has_domain_right ws)
              )
    :qid |qp.$FVF<right>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_right pm r))
    :pattern (($FVF.perm_right pm r))
    :qid |qp.$FVF<right>-validvar|)))
(assert (forall ((r $Ref) (f $Ref)) (!
    (= ($FVF.loc_right f r) true)
    :pattern (($FVF.loc_right f r))
    :qid |qp.$FVF<right>-loc|)))
; /field_value_functions_axioms.smt2 [is_marked: Bool]
(assert (forall ((vs $FVF<is_marked>) (ws $FVF<is_marked>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_is_marked vs) ($FVF.domain_is_marked ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_is_marked vs))
            (= ($FVF.lookup_is_marked vs x) ($FVF.lookup_is_marked ws x)))
          :pattern (($FVF.lookup_is_marked vs x) ($FVF.lookup_is_marked ws x))
          :qid |qp.$FVF<is_marked>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<is_marked>To$Snap vs) ($FVF.has_domain_is_marked vs)
              ($SortWrappers.$FVF<is_marked>To$Snap ws) ($FVF.has_domain_is_marked ws)
              )
    :qid |qp.$FVF<is_marked>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_is_marked pm r))
    :pattern (($FVF.perm_is_marked pm r))
    :qid |qp.$FVF<is_marked>-validvar|)))
(assert (forall ((r $Ref) (f Bool)) (!
    (= ($FVF.loc_is_marked f r) true)
    :pattern (($FVF.loc_is_marked f r))
    :qid |qp.$FVF<is_marked>-loc|)))
; State saturation: after prelude
(set-option :rlimit 1000000)
(check-sat)
; unknown
(declare-const nodes@0@main Set<$Ref>)
(declare-const node@1@main $Ref)
(declare-const nodes@2@main Set<$Ref>)
(declare-const node@3@main $Ref)
(set-option :rlimit 0)
(push) ; 1
(declare-const snapshot@4@main $Snap)
(assert (= snapshot@4@main ($Snap.combine ($Snap.first snapshot@4@main) ($Snap.second snapshot@4@main))))
(assert (= ($Snap.first snapshot@4@main) $Snap.unit))
; [eval] (node in nodes)
(assert (Set_in node@3@main nodes@2@main))
(assert (= ($Snap.second snapshot@4@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@4@main)) ($Snap.second ($Snap.second snapshot@4@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@4@main)) $Snap.unit))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(assert (not (Set_in $Ref.null nodes@2@main)))
(assert (= ($Snap.second ($Snap.second snapshot@4@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@4@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))
(declare-const n$0@5@main $Ref)
(push) ; 2
; [eval] (n$0 in nodes)
(assert (Set_in n$0@5@main nodes@2@main))
(pop) ; 2
(declare-fun inv@6@main ($Ref) $Ref)
(declare-fun img@7@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 2
(assert (not (forall ((n$01@5@main $Ref) (n$02@5@main $Ref)) (! (=> (and (Set_in n$01@5@main nodes@2@main) (Set_in n$02@5@main nodes@2@main) (= n$01@5@main n$02@5@main)) (= n$01@5@main n$02@5@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$0@5@main $Ref)) (! (=> (Set_in n$0@5@main nodes@2@main) (and (= (inv@6@main n$0@5@main) n$0@5@main) (img@7@main n$0@5@main))) :pattern ((Set_in n$0@5@main nodes@2@main)) :pattern ((inv@6@main n$0@5@main)) :pattern ((img@7@main n$0@5@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= (inv@6@main r) r)) :pattern ((inv@6@main r)) :qid |left-fctOfInv|)))
(assert (forall ((n$0@5@main $Ref)) (! (=> (Set_in n$0@5@main nodes@2@main) (not (= n$0@5@main $Ref.null))) :pattern ((Set_in n$0@5@main nodes@2@main)) :pattern ((inv@6@main n$0@5@main)) :pattern ((img@7@main n$0@5@main)) :qid |left-permImpliesNonNull|)))
(declare-const sm@8@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@8@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@8@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef1|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@8@main $FVF<left>) r)) :qid |qp.psmResTrgDef2|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@6@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) r) r)) :pattern ((inv@6@main r)) :qid |quant-u-1|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))))
(declare-const n$1@9@main $Ref)
(push) ; 2
; [eval] (n$1 in nodes)
(assert (Set_in n$1@9@main nodes@2@main))
(pop) ; 2
(declare-fun inv@10@main ($Ref) $Ref)
(declare-fun img@11@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 2
(assert (not (forall ((n$11@9@main $Ref) (n$12@9@main $Ref)) (! (=> (and (Set_in n$11@9@main nodes@2@main) (Set_in n$12@9@main nodes@2@main) (= n$11@9@main n$12@9@main)) (= n$11@9@main n$12@9@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 2
; 4ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$1@9@main $Ref)) (! (=> (Set_in n$1@9@main nodes@2@main) (and (= (inv@10@main n$1@9@main) n$1@9@main) (img@11@main n$1@9@main))) :pattern ((Set_in n$1@9@main nodes@2@main)) :pattern ((inv@10@main n$1@9@main)) :pattern ((img@11@main n$1@9@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= (inv@10@main r) r)) :pattern ((inv@10@main r)) :qid |right-fctOfInv|)))
(assert (forall ((n$1@9@main $Ref)) (! (=> (Set_in n$1@9@main nodes@2@main) (not (= n$1@9@main $Ref.null))) :pattern ((Set_in n$1@9@main nodes@2@main)) :pattern ((inv@10@main n$1@9@main)) :pattern ((img@11@main n$1@9@main)) :qid |right-permImpliesNonNull|)))
(declare-const sm@12@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@12@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@12@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef4|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@12@main $FVF<right>) r)) :qid |qp.psmResTrgDef5|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@10@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) r) r)) :pattern ((inv@10@main r)) :qid |quant-u-3|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))))
(declare-const n$2@13@main $Ref)
(push) ; 2
; [eval] (n$2 in nodes)
(assert (Set_in n$2@13@main nodes@2@main))
(pop) ; 2
(declare-fun inv@14@main ($Ref) $Ref)
(declare-fun img@15@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 2
(assert (not (forall ((n$21@13@main $Ref) (n$22@13@main $Ref)) (! (=> (and (Set_in n$21@13@main nodes@2@main) (Set_in n$22@13@main nodes@2@main) (= n$21@13@main n$22@13@main)) (= n$21@13@main n$22@13@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$2@13@main $Ref)) (! (=> (Set_in n$2@13@main nodes@2@main) (and (= (inv@14@main n$2@13@main) n$2@13@main) (img@15@main n$2@13@main))) :pattern ((Set_in n$2@13@main nodes@2@main)) :pattern ((inv@14@main n$2@13@main)) :pattern ((img@15@main n$2@13@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (= (inv@14@main r) r)) :pattern ((inv@14@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((n$2@13@main $Ref)) (! (=> (Set_in n$2@13@main nodes@2@main) (not (= n$2@13@main $Ref.null))) :pattern ((Set_in n$2@13@main nodes@2@main)) :pattern ((inv@14@main n$2@13@main)) :pattern ((img@15@main n$2@13@main)) :qid |is_marked-permImpliesNonNull|)))
(declare-const sm@16@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r)) :qid |qp.psmValDef7|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef8|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@14@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) r) r)) :pattern ((inv@14@main r)) :qid |quant-u-5|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) $Snap.unit))
; [eval] (forall n$3: Ref :: { (n$3.left in nodes) } { (n$3 in nodes), n$3.left } (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes))
(declare-const n$3@17@main $Ref)
(push) ; 2
; [eval] (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes)
; [eval] (n$3 in nodes) && n$3.left != null
; [eval] (n$3 in nodes)
(push) ; 3
(push) ; 4
(assert (not (Set_in n$3@17@main nodes@2@main)))
(pop) ; 4
(push) ; 4
(assert (Set_in n$3@17@main nodes@2@main))
; [eval] n$3.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))
(push) ; 5
(assert (not (and (img@7@main n$3@17@main) (Set_in (inv@6@main n$3@17@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$3@17@main nodes@2@main) (and (Set_in n$3@17@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))))
(assert (or (Set_in n$3@17@main nodes@2@main) (not (Set_in n$3@17@main nodes@2@main))))
(push) ; 3
(push) ; 4
(assert (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))))
; [eval] (n$3.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))
(push) ; 5
(assert (not (and (img@7@main n$3@17@main) (Set_in (inv@6@main n$3@17@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)))))
(declare-const sm@18@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@18@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@18@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef9|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@18@main $FVF<left>) r)) :qid |qp.psmResTrgDef10|)))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@18@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@18@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef9|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@18@main $FVF<left>) r)) :qid |qp.psmResTrgDef10|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$3@17@main $Ref)) (! (and (=> (Set_in n$3@17@main nodes@2@main) (and (Set_in n$3@17@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))) (or (Set_in n$3@17@main nodes@2@main) (not (Set_in n$3@17@main nodes@2@main))) (=> (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))) (or (not (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$3@17@main $Ref)) (! (and (=> (Set_in n$3@17@main nodes@2@main) (and (Set_in n$3@17@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))) (or (Set_in n$3@17@main nodes@2@main) (not (Set_in n$3@17@main nodes@2@main))) (=> (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) n$3@17@main))) (or (not (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null)))) (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))))) :pattern ((Set_in n$3@17@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@18@main $FVF<left>) n$3@17@main) n$3@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$3@17@main $Ref)) (! (=> (and (Set_in n$3@17@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@8@main $FVF<left>) n$3@17@main) nodes@2@main)) :pattern ((Set_in n$3@17@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@18@main $FVF<left>) n$3@17@main) n$3@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))) $Snap.unit))
; [eval] (forall n$4: Ref :: { (n$4.right in nodes) } { (n$4 in nodes), n$4.right } (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes))
(declare-const n$4@19@main $Ref)
(push) ; 2
; [eval] (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes)
; [eval] (n$4 in nodes) && n$4.right != null
; [eval] (n$4 in nodes)
(push) ; 3
(push) ; 4
(assert (not (Set_in n$4@19@main nodes@2@main)))
(pop) ; 4
(push) ; 4
(assert (Set_in n$4@19@main nodes@2@main))
; [eval] n$4.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))
(push) ; 5
(assert (not (and (img@11@main n$4@19@main) (Set_in (inv@10@main n$4@19@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$4@19@main nodes@2@main) (and (Set_in n$4@19@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))))
(assert (or (Set_in n$4@19@main nodes@2@main) (not (Set_in n$4@19@main nodes@2@main))))
(push) ; 3
(push) ; 4
(assert (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))))
; [eval] (n$4.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))
(push) ; 5
(assert (not (and (img@11@main n$4@19@main) (Set_in (inv@10@main n$4@19@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)))))
(declare-const sm@20@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@20@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@20@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef11|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@20@main $FVF<right>) r)) :qid |qp.psmResTrgDef12|)))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@20@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@20@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef11|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@20@main $FVF<right>) r)) :qid |qp.psmResTrgDef12|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$4@19@main $Ref)) (! (and (=> (Set_in n$4@19@main nodes@2@main) (and (Set_in n$4@19@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))) (or (Set_in n$4@19@main nodes@2@main) (not (Set_in n$4@19@main nodes@2@main))) (=> (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))) (or (not (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$4@19@main $Ref)) (! (and (=> (Set_in n$4@19@main nodes@2@main) (and (Set_in n$4@19@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))) (or (Set_in n$4@19@main nodes@2@main) (not (Set_in n$4@19@main nodes@2@main))) (=> (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) n$4@19@main))) (or (not (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null)))) (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))))) :pattern ((Set_in n$4@19@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@20@main $FVF<right>) n$4@19@main) n$4@19@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$4@19@main $Ref)) (! (=> (and (Set_in n$4@19@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@12@main $FVF<right>) n$4@19@main) nodes@2@main)) :pattern ((Set_in n$4@19@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@20@main $FVF<right>) n$4@19@main) n$4@19@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))))) $Snap.unit))
; [eval] !node.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) node@3@main) node@3@main))
(push) ; 2
(assert (not (and (img@15@main node@3@main) (Set_in (inv@14@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 2
; 1ms
; (get-info :all-statistics)
(assert (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) node@3@main)))
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const snapshot@21@main $Snap)
(assert (= snapshot@21@main ($Snap.combine ($Snap.first snapshot@21@main) ($Snap.second snapshot@21@main))))
(assert (= ($Snap.first snapshot@21@main) $Snap.unit))
; [eval] (node in nodes)
(assert (= ($Snap.second snapshot@21@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@21@main)) ($Snap.second ($Snap.second snapshot@21@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@21@main)) $Snap.unit))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(assert (= ($Snap.second ($Snap.second snapshot@21@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@21@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))
(declare-const n$5@22@main $Ref)
(push) ; 3
; [eval] (n$5 in nodes)
(assert (Set_in n$5@22@main nodes@2@main))
(pop) ; 3
(declare-fun inv@23@main ($Ref) $Ref)
(declare-fun img@24@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 3
(assert (not (forall ((n$51@22@main $Ref) (n$52@22@main $Ref)) (! (=> (and (Set_in n$51@22@main nodes@2@main) (Set_in n$52@22@main nodes@2@main) (= n$51@22@main n$52@22@main)) (= n$51@22@main n$52@22@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$5@22@main $Ref)) (! (=> (Set_in n$5@22@main nodes@2@main) (and (= (inv@23@main n$5@22@main) n$5@22@main) (img@24@main n$5@22@main))) :pattern ((Set_in n$5@22@main nodes@2@main)) :pattern ((inv@23@main n$5@22@main)) :pattern ((img@24@main n$5@22@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= (inv@23@main r) r)) :pattern ((inv@23@main r)) :qid |left-fctOfInv|)))
(assert (forall ((n$5@22@main $Ref)) (! (=> (Set_in n$5@22@main nodes@2@main) (not (= n$5@22@main $Ref.null))) :pattern ((Set_in n$5@22@main nodes@2@main)) :pattern ((inv@23@main n$5@22@main)) :pattern ((img@24@main n$5@22@main)) :qid |left-permImpliesNonNull|)))
(declare-const sm@25@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r))) :pattern (($FVF.lookup_left (as sm@25@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r)) :qid |qp.psmValDef14|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r) r) :pattern (($FVF.lookup_left (as sm@25@main $FVF<left>) r)) :qid |qp.psmResTrgDef15|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@23@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) r) r)) :pattern ((inv@23@main r)) :qid |quant-u-7|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))
(declare-const n$6@26@main $Ref)
(push) ; 3
; [eval] (n$6 in nodes)
(assert (Set_in n$6@26@main nodes@2@main))
(pop) ; 3
(declare-fun inv@27@main ($Ref) $Ref)
(declare-fun img@28@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 3
(assert (not (forall ((n$61@26@main $Ref) (n$62@26@main $Ref)) (! (=> (and (Set_in n$61@26@main nodes@2@main) (Set_in n$62@26@main nodes@2@main) (= n$61@26@main n$62@26@main)) (= n$61@26@main n$62@26@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$6@26@main $Ref)) (! (=> (Set_in n$6@26@main nodes@2@main) (and (= (inv@27@main n$6@26@main) n$6@26@main) (img@28@main n$6@26@main))) :pattern ((Set_in n$6@26@main nodes@2@main)) :pattern ((inv@27@main n$6@26@main)) :pattern ((img@28@main n$6@26@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= (inv@27@main r) r)) :pattern ((inv@27@main r)) :qid |right-fctOfInv|)))
(assert (forall ((n$6@26@main $Ref)) (! (=> (Set_in n$6@26@main nodes@2@main) (not (= n$6@26@main $Ref.null))) :pattern ((Set_in n$6@26@main nodes@2@main)) :pattern ((inv@27@main n$6@26@main)) :pattern ((img@28@main n$6@26@main)) :qid |right-permImpliesNonNull|)))
(declare-const sm@29@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r))) :pattern (($FVF.lookup_right (as sm@29@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r)) :qid |qp.psmValDef17|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r) r) :pattern (($FVF.lookup_right (as sm@29@main $FVF<right>) r)) :qid |qp.psmResTrgDef18|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@27@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) r) r)) :pattern ((inv@27@main r)) :qid |quant-u-9|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))
(declare-const n$7@30@main $Ref)
(push) ; 3
; [eval] (n$7 in nodes)
(assert (Set_in n$7@30@main nodes@2@main))
(pop) ; 3
(declare-fun inv@31@main ($Ref) $Ref)
(declare-fun img@32@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 3
(assert (not (forall ((n$71@30@main $Ref) (n$72@30@main $Ref)) (! (=> (and (Set_in n$71@30@main nodes@2@main) (Set_in n$72@30@main nodes@2@main) (= n$71@30@main n$72@30@main)) (= n$71@30@main n$72@30@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$7@30@main $Ref)) (! (=> (Set_in n$7@30@main nodes@2@main) (and (= (inv@31@main n$7@30@main) n$7@30@main) (img@32@main n$7@30@main))) :pattern ((Set_in n$7@30@main nodes@2@main)) :pattern ((inv@31@main n$7@30@main)) :pattern ((img@32@main n$7@30@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= (inv@31@main r) r)) :pattern ((inv@31@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((n$7@30@main $Ref)) (! (=> (Set_in n$7@30@main nodes@2@main) (not (= n$7@30@main $Ref.null))) :pattern ((Set_in n$7@30@main nodes@2@main)) :pattern ((inv@31@main n$7@30@main)) :pattern ((img@32@main n$7@30@main)) :qid |is_marked-permImpliesNonNull|)))
(declare-const sm@33@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef20|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef21|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@31@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) r) r)) :pattern ((inv@31@main r)) :qid |quant-u-11|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) $Snap.unit))
; [eval] (forall n$8: Ref :: { (n$8.left in nodes) } { (n$8 in nodes), n$8.left } (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes))
(declare-const n$8@34@main $Ref)
(push) ; 3
; [eval] (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes)
; [eval] (n$8 in nodes) && n$8.left != null
; [eval] (n$8 in nodes)
(push) ; 4
(push) ; 5
(assert (not (Set_in n$8@34@main nodes@2@main)))
(pop) ; 5
(push) ; 5
(assert (Set_in n$8@34@main nodes@2@main))
; [eval] n$8.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))
(push) ; 6
(assert (not (and (img@24@main n$8@34@main) (Set_in (inv@23@main n$8@34@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$8@34@main nodes@2@main) (and (Set_in n$8@34@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))))
(assert (or (Set_in n$8@34@main nodes@2@main) (not (Set_in n$8@34@main nodes@2@main))))
(push) ; 4
(push) ; 5
(assert (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))))
; [eval] (n$8.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))
(push) ; 6
(assert (not (and (img@24@main n$8@34@main) (Set_in (inv@23@main n$8@34@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)))))
(declare-const sm@35@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@35@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r))) :pattern (($FVF.lookup_left (as sm@35@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r)) :qid |qp.psmValDef22|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r) r) :pattern (($FVF.lookup_left (as sm@35@main $FVF<left>) r)) :qid |qp.psmResTrgDef23|)))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@35@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r))) :pattern (($FVF.lookup_left (as sm@35@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r)) :qid |qp.psmValDef22|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r) r) :pattern (($FVF.lookup_left (as sm@35@main $FVF<left>) r)) :qid |qp.psmResTrgDef23|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$8@34@main $Ref)) (! (and (=> (Set_in n$8@34@main nodes@2@main) (and (Set_in n$8@34@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))) (or (Set_in n$8@34@main nodes@2@main) (not (Set_in n$8@34@main nodes@2@main))) (=> (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))) (or (not (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@34@main $Ref)) (! (and (=> (Set_in n$8@34@main nodes@2@main) (and (Set_in n$8@34@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))) (or (Set_in n$8@34@main nodes@2@main) (not (Set_in n$8@34@main nodes@2@main))) (=> (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) n$8@34@main))) (or (not (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null)))) (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))))) :pattern ((Set_in n$8@34@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@35@main $FVF<left>) n$8@34@main) n$8@34@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@34@main $Ref)) (! (=> (and (Set_in n$8@34@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@25@main $FVF<left>) n$8@34@main) nodes@2@main)) :pattern ((Set_in n$8@34@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@35@main $FVF<left>) n$8@34@main) n$8@34@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))) $Snap.unit))
; [eval] (forall n$9: Ref :: { (n$9.right in nodes) } { (n$9 in nodes), n$9.right } (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes))
(declare-const n$9@36@main $Ref)
(push) ; 3
; [eval] (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes)
; [eval] (n$9 in nodes) && n$9.right != null
; [eval] (n$9 in nodes)
(push) ; 4
(push) ; 5
(assert (not (Set_in n$9@36@main nodes@2@main)))
(pop) ; 5
(push) ; 5
(assert (Set_in n$9@36@main nodes@2@main))
; [eval] n$9.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))
(push) ; 6
(assert (not (and (img@28@main n$9@36@main) (Set_in (inv@27@main n$9@36@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$9@36@main nodes@2@main) (and (Set_in n$9@36@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))))
(assert (or (Set_in n$9@36@main nodes@2@main) (not (Set_in n$9@36@main nodes@2@main))))
(push) ; 4
(push) ; 5
(assert (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))))
; [eval] (n$9.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))
(push) ; 6
(assert (not (and (img@28@main n$9@36@main) (Set_in (inv@27@main n$9@36@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)))))
(declare-const sm@37@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@37@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r))) :pattern (($FVF.lookup_right (as sm@37@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r)) :qid |qp.psmValDef24|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r) r) :pattern (($FVF.lookup_right (as sm@37@main $FVF<right>) r)) :qid |qp.psmResTrgDef25|)))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@37@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r))) :pattern (($FVF.lookup_right (as sm@37@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r)) :qid |qp.psmValDef24|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r) r) :pattern (($FVF.lookup_right (as sm@37@main $FVF<right>) r)) :qid |qp.psmResTrgDef25|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$9@36@main $Ref)) (! (and (=> (Set_in n$9@36@main nodes@2@main) (and (Set_in n$9@36@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))) (or (Set_in n$9@36@main nodes@2@main) (not (Set_in n$9@36@main nodes@2@main))) (=> (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))) (or (not (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@36@main $Ref)) (! (and (=> (Set_in n$9@36@main nodes@2@main) (and (Set_in n$9@36@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))) (or (Set_in n$9@36@main nodes@2@main) (not (Set_in n$9@36@main nodes@2@main))) (=> (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) n$9@36@main))) (or (not (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null)))) (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))))) :pattern ((Set_in n$9@36@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@37@main $FVF<right>) n$9@36@main) n$9@36@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@36@main $Ref)) (! (=> (and (Set_in n$9@36@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@29@main $FVF<right>) n$9@36@main) nodes@2@main)) :pattern ((Set_in n$9@36@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@37@main $FVF<right>) n$9@36@main) n$9@36@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } (n in nodes) ==> old(n.is_marked) ==> n.is_marked)
(declare-const n@38@main $Ref)
(push) ; 3
; [eval] (n in nodes) ==> old(n.is_marked) ==> n.is_marked
; [eval] (n in nodes)
(push) ; 4
(push) ; 5
(assert (Set_in n@38@main nodes@2@main))
; [eval] old(n.is_marked) ==> n.is_marked
; [eval] old(n.is_marked)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) n@38@main))
(push) ; 6
(assert (not (and (img@15@main n@38@main) (Set_in (inv@14@main n@38@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@38@main) n@38@main))
(push) ; 8
(assert (not (and (img@32@main n@38@main) (Set_in (inv@31@main n@38@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) (and ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@38@main) n@38@main))))
; Joined path conditions
(assert (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)))
(pop) ; 5
(push) ; 5
(assert (not (Set_in n@38@main nodes@2@main)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (Set_in n@38@main nodes@2@main) (and (Set_in n@38@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) n@38@main) (=> ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) (and ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@38@main) n@38@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)))))
; Joined path conditions
(assert (or (not (Set_in n@38@main nodes@2@main)) (Set_in n@38@main nodes@2@main)))
(declare-const sm@39@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef26|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef27|)))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef26|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef27|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@38@main $Ref)) (! (and (=> (Set_in n@38@main nodes@2@main) (and (Set_in n@38@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) n@38@main) (=> ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) (and ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@38@main) n@38@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)))) (or (not (Set_in n@38@main nodes@2@main)) (Set_in n@38@main nodes@2@main))) :pattern ((Set_in n@38@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) n@38@main) n@38@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102-aux|)))
(assert (forall ((n@38@main $Ref)) (! (=> (and (Set_in n@38@main nodes@2@main) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@38@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@38@main)) :pattern ((Set_in n@38@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@39@main $FVF<is_marked>) n@38@main) n@38@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))) $Snap.unit))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) node@3@main) node@3@main))
(push) ; 3
(assert (not (and (img@32@main node@3@main) (Set_in (inv@31@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(assert ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) node@3@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.left } (n in nodes) ==> n.left == old(n.left))
(declare-const n@40@main $Ref)
(push) ; 3
; [eval] (n in nodes) ==> n.left == old(n.left)
; [eval] (n in nodes)
(push) ; 4
(push) ; 5
(assert (Set_in n@40@main nodes@2@main))
; [eval] n.left == old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@40@main) n@40@main))
(push) ; 6
(assert (not (and (img@24@main n@40@main) (Set_in (inv@23@main n@40@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 2ms
; (get-info :all-statistics)
; [eval] old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n@40@main) n@40@main))
(push) ; 6
(assert (not (and (img@7@main n@40@main) (Set_in (inv@6@main n@40@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 4ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (Set_in n@40@main nodes@2@main)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (Set_in n@40@main nodes@2@main) (and (Set_in n@40@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@40@main) n@40@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n@40@main) n@40@main))))
; Joined path conditions
(assert (or (not (Set_in n@40@main nodes@2@main)) (Set_in n@40@main nodes@2@main)))
(declare-const sm@41@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@41@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r))) :pattern (($FVF.lookup_left (as sm@41@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r)) :qid |qp.psmValDef28|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r) r) :pattern (($FVF.lookup_left (as sm@41@main $FVF<left>) r)) :qid |qp.psmResTrgDef29|)))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@24@main r) (Set_in (inv@23@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@41@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r))) :pattern (($FVF.lookup_left (as sm@41@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r)) :qid |qp.psmValDef28|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@21@main)))) r) r) :pattern (($FVF.lookup_left (as sm@41@main $FVF<left>) r)) :qid |qp.psmResTrgDef29|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@40@main $Ref)) (! (and (=> (Set_in n@40@main nodes@2@main) (and (Set_in n@40@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@40@main) n@40@main) ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) n@40@main) n@40@main))) (or (not (Set_in n@40@main nodes@2@main)) (Set_in n@40@main nodes@2@main))) :pattern ((Set_in n@40@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@41@main $FVF<left>) n@40@main) n@40@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86-aux|)))
(assert (forall ((n@40@main $Ref)) (! (=> (Set_in n@40@main nodes@2@main) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@40@main) ($FVF.lookup_left (as sm@8@main $FVF<left>) n@40@main))) :pattern ((Set_in n@40@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@41@main $FVF<left>) n@40@main) n@40@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.right } (n in nodes) ==> n.right == old(n.right))
(declare-const n@42@main $Ref)
(push) ; 3
; [eval] (n in nodes) ==> n.right == old(n.right)
; [eval] (n in nodes)
(push) ; 4
(push) ; 5
(assert (Set_in n@42@main nodes@2@main))
; [eval] n.right == old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@42@main) n@42@main))
(push) ; 6
(assert (not (and (img@28@main n@42@main) (Set_in (inv@27@main n@42@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
; [eval] old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n@42@main) n@42@main))
(push) ; 6
(assert (not (and (img@11@main n@42@main) (Set_in (inv@10@main n@42@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (Set_in n@42@main nodes@2@main)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (Set_in n@42@main nodes@2@main) (and (Set_in n@42@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@42@main) n@42@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n@42@main) n@42@main))))
; Joined path conditions
(assert (or (not (Set_in n@42@main nodes@2@main)) (Set_in n@42@main nodes@2@main)))
(declare-const sm@43@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@43@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r))) :pattern (($FVF.lookup_right (as sm@43@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r)) :qid |qp.psmValDef30|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r) r) :pattern (($FVF.lookup_right (as sm@43@main $FVF<right>) r)) :qid |qp.psmResTrgDef31|)))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@28@main r) (Set_in (inv@27@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@43@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r))) :pattern (($FVF.lookup_right (as sm@43@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r)) :qid |qp.psmValDef30|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))) r) r) :pattern (($FVF.lookup_right (as sm@43@main $FVF<right>) r)) :qid |qp.psmResTrgDef31|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@42@main $Ref)) (! (and (=> (Set_in n@42@main nodes@2@main) (and (Set_in n@42@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@42@main) n@42@main) ($FVF.loc_right ($FVF.lookup_right (as sm@12@main $FVF<right>) n@42@main) n@42@main))) (or (not (Set_in n@42@main nodes@2@main)) (Set_in n@42@main nodes@2@main))) :pattern ((Set_in n@42@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@43@main $FVF<right>) n@42@main) n@42@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89-aux|)))
(assert (forall ((n@42@main $Ref)) (! (=> (Set_in n@42@main nodes@2@main) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@42@main) ($FVF.lookup_right (as sm@12@main $FVF<right>) n@42@main))) :pattern ((Set_in n@42@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@43@main $FVF<right>) n@42@main) n@42@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.left.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked)
(declare-const n@44@main $Ref)
(push) ; 3
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] (n in nodes)
(push) ; 4
(push) ; 5
(assert (Set_in n@44@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main) n@44@main))
(push) ; 6
(assert (not (and (img@15@main n@44@main) (Set_in (inv@14@main n@44@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main))
(pop) ; 7
(push) ; 7
(assert (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) n@44@main))
(push) ; 8
(assert (not (and (img@32@main n@44@main) (Set_in (inv@31@main n@44@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) n@44@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)))
(push) ; 6
(push) ; 7
(assert (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main)))
; [eval] n.left == null || n.left.is_marked
; [eval] n.left == null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main))
(push) ; 8
(assert (not (and (img@24@main n@44@main) (Set_in (inv@23@main n@44@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null))
(pop) ; 9
(push) ; 9
(assert (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))
(push) ; 10
(assert (not (and (img@24@main n@44@main) (Set_in (inv@23@main n@44@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))
(push) ; 10
(assert (not (and (img@32@main ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) (Set_in (inv@31@main ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))))
(assert (or (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))
(pop) ; 7
(push) ; 7
(assert (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main) (=> (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))) (or (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))))
(pop) ; 5
(push) ; 5
(assert (not (Set_in n@44@main nodes@2@main)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (Set_in n@44@main nodes@2@main) (and (Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main) n@44@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) n@44@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main) (=> (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))) (or (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))))))
; Joined path conditions
(assert (or (not (Set_in n@44@main nodes@2@main)) (Set_in n@44@main nodes@2@main)))
(declare-const sm@45@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef32|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef33|)))
(declare-const sm@46@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef34|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef35|)))
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef32|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef33|)))
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef34|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef35|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@44@main $Ref)) (! (and (=> (Set_in n@44@main nodes@2@main) (and (Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main) n@44@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) n@44@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main) (=> (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))) (or (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))))) (or (not (Set_in n@44@main nodes@2@main)) (Set_in n@44@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main)) :pattern ((Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) n@44@main) n@44@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@44@main $Ref)) (! (and (=> (Set_in n@44@main nodes@2@main) (and (Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main) n@44@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) n@44@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main) (=> (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))) (or (not (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)) (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))))) (or (not (Set_in n@44@main nodes@2@main)) (Set_in n@44@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) n@44@main)) :pattern ((Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@44@main $Ref)) (! (=> (and (Set_in n@44@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@44@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@44@main))) (or (= ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main) $Ref.null) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)))) :pattern ((Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@45@main $FVF<is_marked>) n@44@main) n@44@main)) :pattern ((Set_in n@44@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@46@main $FVF<is_marked>) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main)) ($FVF.lookup_left (as sm@25@main $FVF<left>) n@44@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.right.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked)
(declare-const n@47@main $Ref)
(push) ; 3
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] (n in nodes)
(push) ; 4
(push) ; 5
(assert (Set_in n@47@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main) n@47@main))
(push) ; 6
(assert (not (and (img@15@main n@47@main) (Set_in (inv@14@main n@47@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main))
(pop) ; 7
(push) ; 7
(assert (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) n@47@main))
(push) ; 8
(assert (not (and (img@32@main n@47@main) (Set_in (inv@31@main n@47@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) n@47@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)))
(push) ; 6
(push) ; 7
(assert (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main)))
; [eval] n.right == null || n.right.is_marked
; [eval] n.right == null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main))
(push) ; 8
(assert (not (and (img@28@main n@47@main) (Set_in (inv@27@main n@47@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null))
(pop) ; 9
(push) ; 9
(assert (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))
(push) ; 10
(assert (not (and (img@28@main n@47@main) (Set_in (inv@27@main n@47@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 2ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))
(push) ; 10
(assert (not (and (img@32@main ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) (Set_in (inv@31@main ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))))
(assert (or (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))
(pop) ; 7
(push) ; 7
(assert (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main) (=> (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))) (or (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))))
(pop) ; 5
(push) ; 5
(assert (not (Set_in n@47@main nodes@2@main)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (Set_in n@47@main nodes@2@main) (and (Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main) n@47@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) n@47@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main) (=> (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))) (or (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))))))
; Joined path conditions
(assert (or (not (Set_in n@47@main nodes@2@main)) (Set_in n@47@main nodes@2@main)))
(declare-const sm@48@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef36|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef37|)))
(declare-const sm@49@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef38|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef39|)))
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef36|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef37|)))
(assert (forall ((r $Ref)) (! (=> (and (img@32@main r) (Set_in (inv@31@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r)) :qid |qp.psmValDef38|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@21@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef39|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@47@main $Ref)) (! (and (=> (Set_in n@47@main nodes@2@main) (and (Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main) n@47@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) n@47@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main) (=> (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))) (or (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))))) (or (not (Set_in n@47@main nodes@2@main)) (Set_in n@47@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main)) :pattern ((Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) n@47@main) n@47@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@47@main $Ref)) (! (and (=> (Set_in n@47@main nodes@2@main) (and (Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main) n@47@main) (=> (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) n@47@main))) (or (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main)) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main) (=> (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))) (or (not (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)) (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))))) (or (not (Set_in n@47@main nodes@2@main)) (Set_in n@47@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) n@47@main)) :pattern ((Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@47@main $Ref)) (! (=> (and (Set_in n@47@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@16@main $FVF<is_marked>) n@47@main)) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) n@47@main))) (or (= ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main) $Ref.null) ($FVF.lookup_is_marked (as sm@33@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)))) :pattern ((Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@48@main $FVF<is_marked>) n@47@main) n@47@main)) :pattern ((Set_in n@47@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@49@main $FVF<is_marked>) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main)) ($FVF.lookup_right (as sm@29@main $FVF<right>) n@47@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104|)))
(pop) ; 2
(push) ; 2
; [exec]
; node.is_marked := true
(declare-const sm@50@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r)) :qid |qp.psmValDef40|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef41|)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) node@3@main) node@3@main))
(define-fun pTaken@51@main ((r $Ref)) $Perm
  (ite (= r node@3@main) ($Perm.min (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@51@main r)) $Perm.No) :qid |quant-u-12|))))
(check-sat)
; unknown
(pop) ; 3
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (forall ((r $Ref)) (! (= (pTaken@51@main r) $Perm.No) :qid |quant-u-13|))))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (= r node@3@main) (= (- $Perm.Write (pTaken@51@main r)) $Perm.No)) :qid |quant-u-14|))))
(check-sat)
; unsat
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(declare-const sm@52@main $FVF<is_marked>)
(assert (= ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) node@3@main) true))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) node@3@main) node@3@main))
; [eval] node.left != null && !node.left.is_marked
; [eval] node.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) node@3@main))
(set-option :rlimit 0)
(push) ; 3
(assert (not (and (img@7@main node@3@main) (Set_in (inv@6@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(push) ; 3
(push) ; 4
(assert (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null))
(pop) ; 4
(push) ; 4
(assert (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)))
; [eval] !node.left.is_marked
(push) ; 5
(assert (not (and (img@7@main node@3@main) (Set_in (inv@6@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(declare-const sm@53@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (= r node@3@main) (= ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r))) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r)) :qid |qp.psmValDef42|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (< $Perm.No (- $Perm.Write (pTaken@51@main r))) false) (= ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r)) :qid |qp.psmValDef43|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r)) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef44|)))
(declare-const pm@54@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_is_marked (as pm@54@main $FPM) r) (+ (ite (= r node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (- $Perm.Write (pTaken@51@main r)) $Perm.No))) :pattern (($FVF.perm_is_marked (as pm@54@main $FPM) r)) :qid |qp.resPrmSumDef45|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r)) :pattern (($FVF.perm_is_marked (as pm@54@main $FPM) r)) :qid |qp.resTrgDef46|)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))
(declare-const rcvr@55@main $Ref)
(push) ; 5
(assert (not (=> (= (as rcvr@55@main $Ref) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) (< $Perm.No ($FVF.perm_is_marked (as pm@54@main $FPM) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main))))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r node@3@main) (= ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r))) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r)) :qid |qp.psmValDef42|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (< $Perm.No (- $Perm.Write (pTaken@51@main r))) false) (= ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r)) :qid |qp.psmValDef43|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r)) :pattern (($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef44|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_is_marked (as pm@54@main $FPM) r) (+ (ite (= r node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (- $Perm.Write (pTaken@51@main r)) $Perm.No))) :pattern (($FVF.perm_is_marked (as pm@54@main $FPM) r)) :qid |qp.resPrmSumDef45|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r)) :pattern (($FVF.perm_is_marked (as pm@54@main $FPM) r)) :qid |qp.resTrgDef46|)))
(assert (=> (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))))
(assert (or (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)))
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (and (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))))))
(check-sat)
; unknown
(pop) ; 3
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (and (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main))))))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (and (not (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@53@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))))
; [exec]
; trav_rec(nodes, node.left)
(push) ; 4
(assert (not (and (img@7@main node@3@main) (Set_in (inv@6@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; [eval] (node in nodes)
(push) ; 4
(assert (not (Set_in ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) nodes@2@main)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (Set_in ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) nodes@2@main))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(declare-const n$0@56@main $Ref)
(push) ; 4
; [eval] (n$0 in nodes)
(assert (Set_in n$0@56@main nodes@2@main))
(pop) ; 4
(declare-fun inv@57@main ($Ref) $Ref)
(declare-fun img@58@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@59@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@59@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@59@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@59@main $FVF<left>) r)) :qid |qp.psmResTrgDef48|)))
(push) ; 4
(assert (not (forall ((n$01@56@main $Ref) (n$02@56@main $Ref)) (! (=> (and (and (Set_in n$01@56@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$01@56@main) n$01@56@main)) (and (Set_in n$02@56@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$02@56@main) n$02@56@main)) (= n$01@56@main n$02@56@main)) (= n$01@56@main n$02@56@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$0@56@main $Ref)) (! (=> (Set_in n$0@56@main nodes@2@main) (and (= (inv@57@main n$0@56@main) n$0@56@main) (img@58@main n$0@56@main))) :pattern ((Set_in n$0@56@main nodes@2@main)) :pattern ((inv@57@main n$0@56@main)) :pattern ((img@58@main n$0@56@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@58@main r) (Set_in (inv@57@main r) nodes@2@main)) (= (inv@57@main r) r)) :pattern ((inv@57@main r)) :qid |left-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@57@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) r) r)) :pattern ((inv@57@main r)) :qid |quant-u-17|)))
(define-fun pTaken@60@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@57@main r) nodes@2@main) (img@58@main r) (= r (inv@57@main r))) ($Perm.min (ite (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@60@main r)) $Perm.No) :qid |quant-u-18|))))
(check-sat)
; unsat
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@57@main r) nodes@2@main) (img@58@main r) (= r (inv@57@main r))) (= (- $Perm.Write (pTaken@60@main r)) $Perm.No)) :qid |quant-u-19|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(declare-const n$1@61@main $Ref)
(set-option :rlimit 0)
(push) ; 4
; [eval] (n$1 in nodes)
(assert (Set_in n$1@61@main nodes@2@main))
(pop) ; 4
(declare-fun inv@62@main ($Ref) $Ref)
(declare-fun img@63@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@64@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@64@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@64@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@64@main $FVF<right>) r)) :qid |qp.psmResTrgDef50|)))
(push) ; 4
(assert (not (forall ((n$11@61@main $Ref) (n$12@61@main $Ref)) (! (=> (and (and (Set_in n$11@61@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$11@61@main) n$11@61@main)) (and (Set_in n$12@61@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$12@61@main) n$12@61@main)) (= n$11@61@main n$12@61@main)) (= n$11@61@main n$12@61@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$1@61@main $Ref)) (! (=> (Set_in n$1@61@main nodes@2@main) (and (= (inv@62@main n$1@61@main) n$1@61@main) (img@63@main n$1@61@main))) :pattern ((Set_in n$1@61@main nodes@2@main)) :pattern ((inv@62@main n$1@61@main)) :pattern ((img@63@main n$1@61@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@63@main r) (Set_in (inv@62@main r) nodes@2@main)) (= (inv@62@main r) r)) :pattern ((inv@62@main r)) :qid |right-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@62@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) r) r)) :pattern ((inv@62@main r)) :qid |quant-u-22|)))
(define-fun pTaken@65@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@62@main r) nodes@2@main) (img@63@main r) (= r (inv@62@main r))) ($Perm.min (ite (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@65@main r)) $Perm.No) :qid |quant-u-23|))))
(check-sat)
; unsat
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@62@main r) nodes@2@main) (img@63@main r) (= r (inv@62@main r))) (= (- $Perm.Write (pTaken@65@main r)) $Perm.No)) :qid |quant-u-24|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(declare-const n$2@66@main $Ref)
(set-option :rlimit 0)
(push) ; 4
; [eval] (n$2 in nodes)
(assert (Set_in n$2@66@main nodes@2@main))
(pop) ; 4
(declare-fun inv@67@main ($Ref) $Ref)
(declare-fun img@68@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@69@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (= r node@3@main) (= ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r) ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r))) :pattern (($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r)) :qid |qp.psmValDef51|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (< $Perm.No (- $Perm.Write (pTaken@51@main r))) false) (= ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r)) :qid |qp.psmValDef52|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@52@main $FVF<is_marked>) r) r) ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@4@main)))))) r) r)) :pattern (($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef53|)))
(push) ; 4
(assert (not (forall ((n$21@66@main $Ref) (n$22@66@main $Ref)) (! (=> (and (and (Set_in n$21@66@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n$21@66@main) n$21@66@main)) (and (Set_in n$22@66@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n$22@66@main) n$22@66@main)) (= n$21@66@main n$22@66@main)) (= n$21@66@main n$22@66@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$2@66@main $Ref)) (! (=> (Set_in n$2@66@main nodes@2@main) (and (= (inv@67@main n$2@66@main) n$2@66@main) (img@68@main n$2@66@main))) :pattern ((Set_in n$2@66@main nodes@2@main)) :pattern ((inv@67@main n$2@66@main)) :pattern ((img@68@main n$2@66@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@68@main r) (Set_in (inv@67@main r) nodes@2@main)) (= (inv@67@main r) r)) :pattern ((inv@67@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@67@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) r) r)) :pattern ((inv@67@main r)) :qid |quant-u-27|)))
(define-fun pTaken@70@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@67@main r) nodes@2@main) (img@68@main r) (= r (inv@67@main r))) ($Perm.min (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (- $Perm.Write (pTaken@51@main r)) $Perm.No) $Perm.Write) $Perm.No))
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@15@main r) (Set_in (inv@14@main r) nodes@2@main)) (- $Perm.Write (pTaken@51@main r)) $Perm.No) (pTaken@70@main r)) $Perm.No) :qid |quant-u-28|))))
(check-sat)
; unsat
(pop) ; 4
; 5ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@67@main r) nodes@2@main) (img@68@main r) (= r (inv@67@main r))) (= (- $Perm.Write (pTaken@70@main r)) $Perm.No)) :qid |quant-u-29|))))
(check-sat)
; unknown
(pop) ; 4
; 4ms
; (get-info :all-statistics)
(define-fun pTaken@71@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@67@main r) nodes@2@main) (img@68@main r) (= r (inv@67@main r))) ($Perm.min (ite (= r node@3@main) $Perm.Write $Perm.No) (- $Perm.Write (pTaken@70@main r))) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r node@3@main) $Perm.Write $Perm.No) (pTaken@71@main r)) $Perm.No) :qid |quant-u-30|))))
(check-sat)
; unsat
(pop) ; 4
; 5ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@67@main r) nodes@2@main) (img@68@main r) (= r (inv@67@main r))) (= (- (- $Perm.Write (pTaken@70@main r)) (pTaken@71@main r)) $Perm.No)) :qid |quant-u-31|))))
(check-sat)
; unsat
(pop) ; 4
; 5ms
; (get-info :all-statistics)
; [eval] (forall n$3: Ref :: { (n$3.left in nodes) } { (n$3 in nodes), n$3.left } (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes))
(declare-const n$3@72@main $Ref)
(set-option :rlimit 0)
(push) ; 4
; [eval] (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes)
; [eval] (n$3 in nodes) && n$3.left != null
; [eval] (n$3 in nodes)
(push) ; 5
(push) ; 6
(assert (not (Set_in n$3@72@main nodes@2@main)))
(pop) ; 6
(push) ; 6
(assert (Set_in n$3@72@main nodes@2@main))
; [eval] n$3.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))
(push) ; 7
(assert (not (and (img@7@main n$3@72@main) (Set_in (inv@6@main n$3@72@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$3@72@main nodes@2@main) (and (Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))))
(assert (or (Set_in n$3@72@main nodes@2@main) (not (Set_in n$3@72@main nodes@2@main))))
(push) ; 5
(push) ; 6
(assert (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))))
; [eval] (n$3.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))
(push) ; 7
(assert (not (and (img@7@main n$3@72@main) (Set_in (inv@6@main n$3@72@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)))))
(declare-const sm@73@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@73@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@73@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@73@main $FVF<left>) r)) :qid |qp.psmResTrgDef55|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@7@main r) (Set_in (inv@6@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@73@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r))) :pattern (($FVF.lookup_left (as sm@73@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@4@main)))) r) r) :pattern (($FVF.lookup_left (as sm@73@main $FVF<left>) r)) :qid |qp.psmResTrgDef55|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$3@72@main $Ref)) (! (and (=> (Set_in n$3@72@main nodes@2@main) (and (Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))) (or (Set_in n$3@72@main nodes@2@main) (not (Set_in n$3@72@main nodes@2@main))) (=> (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))) (or (not (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$3@72@main $Ref)) (! (and (=> (Set_in n$3@72@main nodes@2@main) (and (Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))) (or (Set_in n$3@72@main nodes@2@main) (not (Set_in n$3@72@main nodes@2@main))) (=> (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) n$3@72@main))) (or (not (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null)))) (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))))) :pattern ((Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@73@main $FVF<left>) n$3@72@main) n$3@72@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(push) ; 4
(assert (not (forall ((n$3@72@main $Ref)) (! (=> (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) nodes@2@main)) :pattern ((Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@73@main $FVF<left>) n$3@72@main) n$3@72@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(assert (forall ((n$3@72@main $Ref)) (! (=> (and (Set_in n$3@72@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@59@main $FVF<left>) n$3@72@main) nodes@2@main)) :pattern ((Set_in n$3@72@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@73@main $FVF<left>) n$3@72@main) n$3@72@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
; [eval] (forall n$4: Ref :: { (n$4.right in nodes) } { (n$4 in nodes), n$4.right } (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes))
(declare-const n$4@74@main $Ref)
(push) ; 4
; [eval] (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes)
; [eval] (n$4 in nodes) && n$4.right != null
; [eval] (n$4 in nodes)
(push) ; 5
(push) ; 6
(assert (not (Set_in n$4@74@main nodes@2@main)))
(pop) ; 6
(push) ; 6
(assert (Set_in n$4@74@main nodes@2@main))
; [eval] n$4.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))
(push) ; 7
(assert (not (and (img@11@main n$4@74@main) (Set_in (inv@10@main n$4@74@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$4@74@main nodes@2@main) (and (Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))))
(assert (or (Set_in n$4@74@main nodes@2@main) (not (Set_in n$4@74@main nodes@2@main))))
(push) ; 5
(push) ; 6
(assert (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))))
; [eval] (n$4.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))
(push) ; 7
(assert (not (and (img@11@main n$4@74@main) (Set_in (inv@10@main n$4@74@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)))))
(declare-const sm@75@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@75@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@75@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef56|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@75@main $FVF<right>) r)) :qid |qp.psmResTrgDef57|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@11@main r) (Set_in (inv@10@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@75@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r))) :pattern (($FVF.lookup_right (as sm@75@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r)) :qid |qp.psmValDef56|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@4@main))))) r) r) :pattern (($FVF.lookup_right (as sm@75@main $FVF<right>) r)) :qid |qp.psmResTrgDef57|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$4@74@main $Ref)) (! (and (=> (Set_in n$4@74@main nodes@2@main) (and (Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))) (or (Set_in n$4@74@main nodes@2@main) (not (Set_in n$4@74@main nodes@2@main))) (=> (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))) (or (not (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$4@74@main $Ref)) (! (and (=> (Set_in n$4@74@main nodes@2@main) (and (Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))) (or (Set_in n$4@74@main nodes@2@main) (not (Set_in n$4@74@main nodes@2@main))) (=> (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) n$4@74@main))) (or (not (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null)))) (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))))) :pattern ((Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@75@main $FVF<right>) n$4@74@main) n$4@74@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(push) ; 4
(assert (not (forall ((n$4@74@main $Ref)) (! (=> (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) nodes@2@main)) :pattern ((Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@75@main $FVF<right>) n$4@74@main) n$4@74@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(assert (forall ((n$4@74@main $Ref)) (! (=> (and (Set_in n$4@74@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@64@main $FVF<right>) n$4@74@main) nodes@2@main)) :pattern ((Set_in n$4@74@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@75@main $FVF<right>) n$4@74@main) n$4@74@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
; [eval] !node.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))
(push) ; 4
(assert (not (< $Perm.No (+ (ite (= ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main) node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) (Set_in (inv@14@main ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) nodes@2@main)) (- $Perm.Write (pTaken@51@main ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main))) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(push) ; 4
(assert (not (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main))))
(declare-const snapshot@76@main $Snap)
(assert (= snapshot@76@main ($Snap.combine ($Snap.first snapshot@76@main) ($Snap.second snapshot@76@main))))
(assert (= ($Snap.first snapshot@76@main) $Snap.unit))
; [eval] (node in nodes)
(assert (= ($Snap.second snapshot@76@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@76@main)) ($Snap.second ($Snap.second snapshot@76@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@76@main)) $Snap.unit))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(assert (= ($Snap.second ($Snap.second snapshot@76@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@76@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))
(declare-const n$5@77@main $Ref)
(push) ; 4
; [eval] (n$5 in nodes)
(assert (Set_in n$5@77@main nodes@2@main))
(pop) ; 4
(declare-fun inv@78@main ($Ref) $Ref)
(declare-fun img@79@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 4
(assert (not (forall ((n$51@77@main $Ref) (n$52@77@main $Ref)) (! (=> (and (Set_in n$51@77@main nodes@2@main) (Set_in n$52@77@main nodes@2@main) (= n$51@77@main n$52@77@main)) (= n$51@77@main n$52@77@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$5@77@main $Ref)) (! (=> (Set_in n$5@77@main nodes@2@main) (and (= (inv@78@main n$5@77@main) n$5@77@main) (img@79@main n$5@77@main))) :pattern ((Set_in n$5@77@main nodes@2@main)) :pattern ((inv@78@main n$5@77@main)) :pattern ((img@79@main n$5@77@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= (inv@78@main r) r)) :pattern ((inv@78@main r)) :qid |left-fctOfInv|)))
(assert (forall ((n$5@77@main $Ref)) (! (=> (Set_in n$5@77@main nodes@2@main) (not (= n$5@77@main $Ref.null))) :pattern ((Set_in n$5@77@main nodes@2@main)) :pattern ((inv@78@main n$5@77@main)) :pattern ((img@79@main n$5@77@main)) :qid |left-permImpliesNonNull|)))
(declare-const sm@80@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@80@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef59|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@80@main $FVF<left>) r)) :qid |qp.psmResTrgDef60|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@78@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) r) r)) :pattern ((inv@78@main r)) :qid |quant-u-34|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))
(declare-const n$6@81@main $Ref)
(push) ; 4
; [eval] (n$6 in nodes)
(assert (Set_in n$6@81@main nodes@2@main))
(pop) ; 4
(declare-fun inv@82@main ($Ref) $Ref)
(declare-fun img@83@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 4
(assert (not (forall ((n$61@81@main $Ref) (n$62@81@main $Ref)) (! (=> (and (Set_in n$61@81@main nodes@2@main) (Set_in n$62@81@main nodes@2@main) (= n$61@81@main n$62@81@main)) (= n$61@81@main n$62@81@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$6@81@main $Ref)) (! (=> (Set_in n$6@81@main nodes@2@main) (and (= (inv@82@main n$6@81@main) n$6@81@main) (img@83@main n$6@81@main))) :pattern ((Set_in n$6@81@main nodes@2@main)) :pattern ((inv@82@main n$6@81@main)) :pattern ((img@83@main n$6@81@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= (inv@82@main r) r)) :pattern ((inv@82@main r)) :qid |right-fctOfInv|)))
(assert (forall ((n$6@81@main $Ref)) (! (=> (Set_in n$6@81@main nodes@2@main) (not (= n$6@81@main $Ref.null))) :pattern ((Set_in n$6@81@main nodes@2@main)) :pattern ((inv@82@main n$6@81@main)) :pattern ((img@83@main n$6@81@main)) :qid |right-permImpliesNonNull|)))
(declare-const sm@84@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@84@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef62|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@84@main $FVF<right>) r)) :qid |qp.psmResTrgDef63|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@82@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) r) r)) :pattern ((inv@82@main r)) :qid |quant-u-36|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))
(declare-const n$7@85@main $Ref)
(push) ; 4
; [eval] (n$7 in nodes)
(assert (Set_in n$7@85@main nodes@2@main))
(pop) ; 4
(declare-fun inv@86@main ($Ref) $Ref)
(declare-fun img@87@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 4
(assert (not (forall ((n$71@85@main $Ref) (n$72@85@main $Ref)) (! (=> (and (Set_in n$71@85@main nodes@2@main) (Set_in n$72@85@main nodes@2@main) (= n$71@85@main n$72@85@main)) (= n$71@85@main n$72@85@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$7@85@main $Ref)) (! (=> (Set_in n$7@85@main nodes@2@main) (and (= (inv@86@main n$7@85@main) n$7@85@main) (img@87@main n$7@85@main))) :pattern ((Set_in n$7@85@main nodes@2@main)) :pattern ((inv@86@main n$7@85@main)) :pattern ((img@87@main n$7@85@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= (inv@86@main r) r)) :pattern ((inv@86@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((n$7@85@main $Ref)) (! (=> (Set_in n$7@85@main nodes@2@main) (not (= n$7@85@main $Ref.null))) :pattern ((Set_in n$7@85@main nodes@2@main)) :pattern ((inv@86@main n$7@85@main)) :pattern ((img@87@main n$7@85@main)) :qid |is_marked-permImpliesNonNull|)))
(declare-const sm@88@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef65|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef66|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@86@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) r) r)) :pattern ((inv@86@main r)) :qid |quant-u-38|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) $Snap.unit))
; [eval] (forall n$8: Ref :: { (n$8.left in nodes) } { (n$8 in nodes), n$8.left } (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes))
(declare-const n$8@89@main $Ref)
(push) ; 4
; [eval] (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes)
; [eval] (n$8 in nodes) && n$8.left != null
; [eval] (n$8 in nodes)
(push) ; 5
(push) ; 6
(assert (not (Set_in n$8@89@main nodes@2@main)))
(pop) ; 6
(push) ; 6
(assert (Set_in n$8@89@main nodes@2@main))
; [eval] n$8.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))
(push) ; 7
(assert (not (and (img@79@main n$8@89@main) (Set_in (inv@78@main n$8@89@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$8@89@main nodes@2@main) (and (Set_in n$8@89@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))))
(assert (or (Set_in n$8@89@main nodes@2@main) (not (Set_in n$8@89@main nodes@2@main))))
(push) ; 5
(push) ; 6
(assert (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))))
; [eval] (n$8.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))
(push) ; 7
(assert (not (and (img@79@main n$8@89@main) (Set_in (inv@78@main n$8@89@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)))))
(declare-const sm@90@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@90@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@90@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef67|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@90@main $FVF<left>) r)) :qid |qp.psmResTrgDef68|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@90@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@90@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef67|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@90@main $FVF<left>) r)) :qid |qp.psmResTrgDef68|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$8@89@main $Ref)) (! (and (=> (Set_in n$8@89@main nodes@2@main) (and (Set_in n$8@89@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))) (or (Set_in n$8@89@main nodes@2@main) (not (Set_in n$8@89@main nodes@2@main))) (=> (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))) (or (not (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@89@main $Ref)) (! (and (=> (Set_in n$8@89@main nodes@2@main) (and (Set_in n$8@89@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))) (or (Set_in n$8@89@main nodes@2@main) (not (Set_in n$8@89@main nodes@2@main))) (=> (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) n$8@89@main))) (or (not (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null)))) (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))))) :pattern ((Set_in n$8@89@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@90@main $FVF<left>) n$8@89@main) n$8@89@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@89@main $Ref)) (! (=> (and (Set_in n$8@89@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@80@main $FVF<left>) n$8@89@main) nodes@2@main)) :pattern ((Set_in n$8@89@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@90@main $FVF<left>) n$8@89@main) n$8@89@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))) $Snap.unit))
; [eval] (forall n$9: Ref :: { (n$9.right in nodes) } { (n$9 in nodes), n$9.right } (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes))
(declare-const n$9@91@main $Ref)
(push) ; 4
; [eval] (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes)
; [eval] (n$9 in nodes) && n$9.right != null
; [eval] (n$9 in nodes)
(push) ; 5
(push) ; 6
(assert (not (Set_in n$9@91@main nodes@2@main)))
(pop) ; 6
(push) ; 6
(assert (Set_in n$9@91@main nodes@2@main))
; [eval] n$9.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))
(push) ; 7
(assert (not (and (img@83@main n$9@91@main) (Set_in (inv@82@main n$9@91@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 2ms
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$9@91@main nodes@2@main) (and (Set_in n$9@91@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))))
(assert (or (Set_in n$9@91@main nodes@2@main) (not (Set_in n$9@91@main nodes@2@main))))
(push) ; 5
(push) ; 6
(assert (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))))
; [eval] (n$9.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))
(push) ; 7
(assert (not (and (img@83@main n$9@91@main) (Set_in (inv@82@main n$9@91@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 2ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)))))
(declare-const sm@92@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@92@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@92@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef69|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@92@main $FVF<right>) r)) :qid |qp.psmResTrgDef70|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@92@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@92@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef69|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@92@main $FVF<right>) r)) :qid |qp.psmResTrgDef70|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$9@91@main $Ref)) (! (and (=> (Set_in n$9@91@main nodes@2@main) (and (Set_in n$9@91@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))) (or (Set_in n$9@91@main nodes@2@main) (not (Set_in n$9@91@main nodes@2@main))) (=> (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))) (or (not (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@91@main $Ref)) (! (and (=> (Set_in n$9@91@main nodes@2@main) (and (Set_in n$9@91@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))) (or (Set_in n$9@91@main nodes@2@main) (not (Set_in n$9@91@main nodes@2@main))) (=> (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) n$9@91@main))) (or (not (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null)))) (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))))) :pattern ((Set_in n$9@91@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@92@main $FVF<right>) n$9@91@main) n$9@91@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@91@main $Ref)) (! (=> (and (Set_in n$9@91@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@84@main $FVF<right>) n$9@91@main) nodes@2@main)) :pattern ((Set_in n$9@91@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@92@main $FVF<right>) n$9@91@main) n$9@91@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } (n in nodes) ==> old(n.is_marked) ==> n.is_marked)
(declare-const n@93@main $Ref)
(push) ; 4
; [eval] (n in nodes) ==> old(n.is_marked) ==> n.is_marked
; [eval] (n in nodes)
(push) ; 5
(push) ; 6
(assert (Set_in n@93@main nodes@2@main))
; [eval] old(n.is_marked) ==> n.is_marked
; [eval] old(n.is_marked)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) n@93@main))
(push) ; 7
(assert (not (< $Perm.No (+ (ite (= n@93@main node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main n@93@main) (Set_in (inv@14@main n@93@main) nodes@2@main)) (- $Perm.Write (pTaken@51@main n@93@main)) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 9ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@93@main) n@93@main))
(push) ; 9
(assert (not (and (img@87@main n@93@main) (Set_in (inv@86@main n@93@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(pop) ; 8
(push) ; 8
(assert (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (=> ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) (and ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@93@main) n@93@main))))
; Joined path conditions
(assert (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)))
(pop) ; 6
(push) ; 6
(assert (not (Set_in n@93@main nodes@2@main)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (Set_in n@93@main nodes@2@main) (and (Set_in n@93@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) n@93@main) (=> ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) (and ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@93@main) n@93@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)))))
; Joined path conditions
(assert (or (not (Set_in n@93@main nodes@2@main)) (Set_in n@93@main nodes@2@main)))
(declare-const sm@94@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef71|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef72|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef71|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef72|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@93@main $Ref)) (! (and (=> (Set_in n@93@main nodes@2@main) (and (Set_in n@93@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) n@93@main) (=> ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) (and ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@93@main) n@93@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)))) (or (not (Set_in n@93@main nodes@2@main)) (Set_in n@93@main nodes@2@main))) :pattern ((Set_in n@93@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) n@93@main) n@93@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102-aux|)))
(assert (forall ((n@93@main $Ref)) (! (=> (and (Set_in n@93@main nodes@2@main) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@93@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@93@main)) :pattern ((Set_in n@93@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@94@main $FVF<is_marked>) n@93@main) n@93@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))) $Snap.unit))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))
(push) ; 4
(assert (not (and (img@87@main ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) (Set_in (inv@86@main ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(assert ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@8@main $FVF<left>) node@3@main)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.left } (n in nodes) ==> n.left == old(n.left))
(declare-const n@95@main $Ref)
(push) ; 4
; [eval] (n in nodes) ==> n.left == old(n.left)
; [eval] (n in nodes)
(push) ; 5
(push) ; 6
(assert (Set_in n@95@main nodes@2@main))
; [eval] n.left == old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@95@main) n@95@main))
(push) ; 7
(assert (not (and (img@79@main n@95@main) (Set_in (inv@78@main n@95@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
; [eval] old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n@95@main) n@95@main))
(push) ; 7
(assert (not (and (img@7@main n@95@main) (Set_in (inv@6@main n@95@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (Set_in n@95@main nodes@2@main)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (Set_in n@95@main nodes@2@main) (and (Set_in n@95@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@95@main) n@95@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n@95@main) n@95@main))))
; Joined path conditions
(assert (or (not (Set_in n@95@main nodes@2@main)) (Set_in n@95@main nodes@2@main)))
(declare-const sm@96@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@96@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@96@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef73|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@96@main $FVF<left>) r)) :qid |qp.psmResTrgDef74|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@96@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@96@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef73|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@96@main $FVF<left>) r)) :qid |qp.psmResTrgDef74|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@95@main $Ref)) (! (and (=> (Set_in n@95@main nodes@2@main) (and (Set_in n@95@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@95@main) n@95@main) ($FVF.loc_left ($FVF.lookup_left (as sm@59@main $FVF<left>) n@95@main) n@95@main))) (or (not (Set_in n@95@main nodes@2@main)) (Set_in n@95@main nodes@2@main))) :pattern ((Set_in n@95@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@96@main $FVF<left>) n@95@main) n@95@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86-aux|)))
(assert (forall ((n@95@main $Ref)) (! (=> (Set_in n@95@main nodes@2@main) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@95@main) ($FVF.lookup_left (as sm@59@main $FVF<left>) n@95@main))) :pattern ((Set_in n@95@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@96@main $FVF<left>) n@95@main) n@95@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.right } (n in nodes) ==> n.right == old(n.right))
(declare-const n@97@main $Ref)
(push) ; 4
; [eval] (n in nodes) ==> n.right == old(n.right)
; [eval] (n in nodes)
(push) ; 5
(push) ; 6
(assert (Set_in n@97@main nodes@2@main))
; [eval] n.right == old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@97@main) n@97@main))
(push) ; 7
(assert (not (and (img@83@main n@97@main) (Set_in (inv@82@main n@97@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
; [eval] old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n@97@main) n@97@main))
(push) ; 7
(assert (not (and (img@11@main n@97@main) (Set_in (inv@10@main n@97@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (Set_in n@97@main nodes@2@main)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (Set_in n@97@main nodes@2@main) (and (Set_in n@97@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@97@main) n@97@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n@97@main) n@97@main))))
; Joined path conditions
(assert (or (not (Set_in n@97@main nodes@2@main)) (Set_in n@97@main nodes@2@main)))
(declare-const sm@98@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@98@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@98@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef75|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@98@main $FVF<right>) r)) :qid |qp.psmResTrgDef76|)))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@98@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@98@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef75|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@98@main $FVF<right>) r)) :qid |qp.psmResTrgDef76|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@97@main $Ref)) (! (and (=> (Set_in n@97@main nodes@2@main) (and (Set_in n@97@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@97@main) n@97@main) ($FVF.loc_right ($FVF.lookup_right (as sm@64@main $FVF<right>) n@97@main) n@97@main))) (or (not (Set_in n@97@main nodes@2@main)) (Set_in n@97@main nodes@2@main))) :pattern ((Set_in n@97@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@98@main $FVF<right>) n@97@main) n@97@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89-aux|)))
(assert (forall ((n@97@main $Ref)) (! (=> (Set_in n@97@main nodes@2@main) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@97@main) ($FVF.lookup_right (as sm@64@main $FVF<right>) n@97@main))) :pattern ((Set_in n@97@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@98@main $FVF<right>) n@97@main) n@97@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.left.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked)
(declare-const n@99@main $Ref)
(push) ; 4
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] (n in nodes)
(push) ; 5
(push) ; 6
(assert (Set_in n@99@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main) n@99@main))
(push) ; 7
(assert (not (< $Perm.No (+ (ite (= n@99@main node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main n@99@main) (Set_in (inv@14@main n@99@main) nodes@2@main)) (- $Perm.Write (pTaken@51@main n@99@main)) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 6ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main))
(pop) ; 8
(push) ; 8
(assert (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) n@99@main))
(push) ; 9
(assert (not (and (img@87@main n@99@main) (Set_in (inv@86@main n@99@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) n@99@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)))
(push) ; 7
(push) ; 8
(assert (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main)))
; [eval] n.left == null || n.left.is_marked
; [eval] n.left == null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main))
(push) ; 9
(assert (not (and (img@79@main n@99@main) (Set_in (inv@78@main n@99@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(push) ; 9
(push) ; 10
(assert (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null))
(pop) ; 10
(push) ; 10
(assert (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))
(push) ; 11
(assert (not (and (img@79@main n@99@main) (Set_in (inv@78@main n@99@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))
(push) ; 11
(assert (not (and (img@87@main ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) (Set_in (inv@86@main ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))))
(assert (or (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))
(pop) ; 8
(push) ; 8
(assert (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main) (=> (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))) (or (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))))
(pop) ; 6
(push) ; 6
(assert (not (Set_in n@99@main nodes@2@main)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (Set_in n@99@main nodes@2@main) (and (Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main) n@99@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) n@99@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main) (=> (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))) (or (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))))))
; Joined path conditions
(assert (or (not (Set_in n@99@main nodes@2@main)) (Set_in n@99@main nodes@2@main)))
(declare-const sm@100@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef77|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef78|)))
(declare-const sm@101@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef79|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef80|)))
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef77|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef78|)))
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef79|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef80|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@99@main $Ref)) (! (and (=> (Set_in n@99@main nodes@2@main) (and (Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main) n@99@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) n@99@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main) (=> (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))) (or (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))))) (or (not (Set_in n@99@main nodes@2@main)) (Set_in n@99@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main)) :pattern ((Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) n@99@main) n@99@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@99@main $Ref)) (! (and (=> (Set_in n@99@main nodes@2@main) (and (Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main) n@99@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) n@99@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main) (=> (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))) (or (not (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)) (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))))) (or (not (Set_in n@99@main nodes@2@main)) (Set_in n@99@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) n@99@main)) :pattern ((Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@99@main $Ref)) (! (=> (and (Set_in n@99@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@99@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@99@main))) (or (= ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main) $Ref.null) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)))) :pattern ((Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@100@main $FVF<is_marked>) n@99@main) n@99@main)) :pattern ((Set_in n@99@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@101@main $FVF<is_marked>) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main)) ($FVF.lookup_left (as sm@80@main $FVF<left>) n@99@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.right.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked)
(declare-const n@102@main $Ref)
(push) ; 4
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] (n in nodes)
(push) ; 5
(push) ; 6
(assert (Set_in n@102@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main) n@102@main))
(push) ; 7
(assert (not (< $Perm.No (+ (ite (= n@102@main node@3@main) $Perm.Write $Perm.No) (ite (and (img@15@main n@102@main) (Set_in (inv@14@main n@102@main) nodes@2@main)) (- $Perm.Write (pTaken@51@main n@102@main)) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 7ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main))
(pop) ; 8
(push) ; 8
(assert (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) n@102@main))
(push) ; 9
(assert (not (and (img@87@main n@102@main) (Set_in (inv@86@main n@102@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) n@102@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)))
(push) ; 7
(push) ; 8
(assert (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main)))
; [eval] n.right == null || n.right.is_marked
; [eval] n.right == null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main))
(push) ; 9
(assert (not (and (img@83@main n@102@main) (Set_in (inv@82@main n@102@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(push) ; 9
(push) ; 10
(assert (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null))
(pop) ; 10
(push) ; 10
(assert (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))
(push) ; 11
(assert (not (and (img@83@main n@102@main) (Set_in (inv@82@main n@102@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))
(push) ; 11
(assert (not (and (img@87@main ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) (Set_in (inv@86@main ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))))
(assert (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))
(pop) ; 8
(push) ; 8
(assert (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main) (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))) (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))))
(pop) ; 6
(push) ; 6
(assert (not (Set_in n@102@main nodes@2@main)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (Set_in n@102@main nodes@2@main) (and (Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main) n@102@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) n@102@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main) (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))) (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))))))
; Joined path conditions
(assert (or (not (Set_in n@102@main nodes@2@main)) (Set_in n@102@main nodes@2@main)))
(declare-const sm@103@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef81|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef82|)))
(declare-const sm@104@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef83|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef84|)))
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef81|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef82|)))
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef83|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef84|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@102@main $Ref)) (! (and (=> (Set_in n@102@main nodes@2@main) (and (Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main) n@102@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) n@102@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main) (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))) (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))))) (or (not (Set_in n@102@main nodes@2@main)) (Set_in n@102@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main)) :pattern ((Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) n@102@main) n@102@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@102@main $Ref)) (! (and (=> (Set_in n@102@main nodes@2@main) (and (Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main) n@102@main) (=> (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) n@102@main))) (or (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main)) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main) (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))) (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))))) (or (not (Set_in n@102@main nodes@2@main)) (Set_in n@102@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) n@102@main)) :pattern ((Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@102@main $Ref)) (! (=> (and (Set_in n@102@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@69@main $FVF<is_marked>) n@102@main)) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) n@102@main))) (or (= ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main) $Ref.null) ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)))) :pattern ((Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@103@main $FVF<is_marked>) n@102@main) n@102@main)) :pattern ((Set_in n@102@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@104@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) n@102@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104|)))
; [eval] node.right != null && !node.right.is_marked
; [eval] node.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) node@3@main))
(push) ; 4
(assert (not (and (img@83@main node@3@main) (Set_in (inv@82@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(assert (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null))
(pop) ; 5
(push) ; 5
(assert (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)))
; [eval] !node.right.is_marked
(push) ; 6
(assert (not (and (img@83@main node@3@main) (Set_in (inv@82@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))
(push) ; 6
(assert (not (and (img@87@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) (Set_in (inv@86@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))))
(assert (or (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)))
(push) ; 4
(set-option :rlimit 100000)
(assert (not (not (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))))))
(check-sat)
; unknown
(pop) ; 4
; 55ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main))))))
(check-sat)
; unknown
(pop) ; 4
; 51ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(assert (and (not (= ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) $Ref.null)) (not ($FVF.lookup_is_marked (as sm@88@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))))
; [exec]
; trav_rec(nodes, node.right)
(push) ; 5
(assert (not (and (img@83@main node@3@main) (Set_in (inv@82@main node@3@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
; [eval] (node in nodes)
(push) ; 5
(assert (not (Set_in ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) nodes@2@main)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(assert (Set_in ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main) nodes@2@main))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(declare-const n$0@105@main $Ref)
(push) ; 5
; [eval] (n$0 in nodes)
(assert (Set_in n$0@105@main nodes@2@main))
(pop) ; 5
(declare-fun inv@106@main ($Ref) $Ref)
(declare-fun img@107@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@108@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@108@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@108@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef85|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@108@main $FVF<left>) r)) :qid |qp.psmResTrgDef86|)))
(push) ; 5
(assert (not (forall ((n$01@105@main $Ref) (n$02@105@main $Ref)) (! (=> (and (and (Set_in n$01@105@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$01@105@main) n$01@105@main)) (and (Set_in n$02@105@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$02@105@main) n$02@105@main)) (= n$01@105@main n$02@105@main)) (= n$01@105@main n$02@105@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$0@105@main $Ref)) (! (=> (Set_in n$0@105@main nodes@2@main) (and (= (inv@106@main n$0@105@main) n$0@105@main) (img@107@main n$0@105@main))) :pattern ((Set_in n$0@105@main nodes@2@main)) :pattern ((inv@106@main n$0@105@main)) :pattern ((img@107@main n$0@105@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@107@main r) (Set_in (inv@106@main r) nodes@2@main)) (= (inv@106@main r) r)) :pattern ((inv@106@main r)) :qid |left-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@106@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) r) r)) :pattern ((inv@106@main r)) :qid |quant-u-40|)))
(define-fun pTaken@109@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@106@main r) nodes@2@main) (img@107@main r) (= r (inv@106@main r))) ($Perm.min (ite (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@109@main r)) $Perm.No) :qid |quant-u-41|))))
(check-sat)
; unsat
(pop) ; 5
; 8ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@106@main r) nodes@2@main) (img@107@main r) (= r (inv@106@main r))) (= (- $Perm.Write (pTaken@109@main r)) $Perm.No)) :qid |quant-u-42|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(declare-const n$1@110@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$1 in nodes)
(assert (Set_in n$1@110@main nodes@2@main))
(pop) ; 5
(declare-fun inv@111@main ($Ref) $Ref)
(declare-fun img@112@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@113@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@113@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@113@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef87|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@113@main $FVF<right>) r)) :qid |qp.psmResTrgDef88|)))
(push) ; 5
(assert (not (forall ((n$11@110@main $Ref) (n$12@110@main $Ref)) (! (=> (and (and (Set_in n$11@110@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$11@110@main) n$11@110@main)) (and (Set_in n$12@110@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$12@110@main) n$12@110@main)) (= n$11@110@main n$12@110@main)) (= n$11@110@main n$12@110@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$1@110@main $Ref)) (! (=> (Set_in n$1@110@main nodes@2@main) (and (= (inv@111@main n$1@110@main) n$1@110@main) (img@112@main n$1@110@main))) :pattern ((Set_in n$1@110@main nodes@2@main)) :pattern ((inv@111@main n$1@110@main)) :pattern ((img@112@main n$1@110@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@112@main r) (Set_in (inv@111@main r) nodes@2@main)) (= (inv@111@main r) r)) :pattern ((inv@111@main r)) :qid |right-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@111@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) r) r)) :pattern ((inv@111@main r)) :qid |quant-u-45|)))
(define-fun pTaken@114@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@111@main r) nodes@2@main) (img@112@main r) (= r (inv@111@main r))) ($Perm.min (ite (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@114@main r)) $Perm.No) :qid |quant-u-46|))))
(check-sat)
; unsat
(pop) ; 5
; 7ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@111@main r) nodes@2@main) (img@112@main r) (= r (inv@111@main r))) (= (- $Perm.Write (pTaken@114@main r)) $Perm.No)) :qid |quant-u-47|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(declare-const n$2@115@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$2 in nodes)
(assert (Set_in n$2@115@main nodes@2@main))
(pop) ; 5
(declare-fun inv@116@main ($Ref) $Ref)
(declare-fun img@117@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@118@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r)) :qid |qp.psmValDef89|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@76@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef90|)))
(push) ; 5
(assert (not (forall ((n$21@115@main $Ref) (n$22@115@main $Ref)) (! (=> (and (and (Set_in n$21@115@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n$21@115@main) n$21@115@main)) (and (Set_in n$22@115@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n$22@115@main) n$22@115@main)) (= n$21@115@main n$22@115@main)) (= n$21@115@main n$22@115@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$2@115@main $Ref)) (! (=> (Set_in n$2@115@main nodes@2@main) (and (= (inv@116@main n$2@115@main) n$2@115@main) (img@117@main n$2@115@main))) :pattern ((Set_in n$2@115@main nodes@2@main)) :pattern ((inv@116@main n$2@115@main)) :pattern ((img@117@main n$2@115@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@117@main r) (Set_in (inv@116@main r) nodes@2@main)) (= (inv@116@main r) r)) :pattern ((inv@116@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@116@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) r) r)) :pattern ((inv@116@main r)) :qid |quant-u-50|)))
(define-fun pTaken@119@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@116@main r) nodes@2@main) (img@117@main r) (= r (inv@116@main r))) ($Perm.min (ite (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@87@main r) (Set_in (inv@86@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@119@main r)) $Perm.No) :qid |quant-u-51|))))
(check-sat)
; unsat
(pop) ; 5
; 7ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@116@main r) nodes@2@main) (img@117@main r) (= r (inv@116@main r))) (= (- $Perm.Write (pTaken@119@main r)) $Perm.No)) :qid |quant-u-52|))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
; [eval] (forall n$3: Ref :: { (n$3.left in nodes) } { (n$3 in nodes), n$3.left } (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes))
(declare-const n$3@120@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$3 in nodes) && n$3.left != null ==> (n$3.left in nodes)
; [eval] (n$3 in nodes) && n$3.left != null
; [eval] (n$3 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$3@120@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$3@120@main nodes@2@main))
; [eval] n$3.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))
(push) ; 8
(assert (not (and (img@79@main n$3@120@main) (Set_in (inv@78@main n$3@120@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$3@120@main nodes@2@main) (and (Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))))
(assert (or (Set_in n$3@120@main nodes@2@main) (not (Set_in n$3@120@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))))
; [eval] (n$3.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))
(push) ; 8
(assert (not (and (img@79@main n$3@120@main) (Set_in (inv@78@main n$3@120@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)))))
(declare-const sm@121@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@121@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@121@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef91|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@121@main $FVF<left>) r)) :qid |qp.psmResTrgDef92|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (Set_in (inv@78@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@121@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r))) :pattern (($FVF.lookup_left (as sm@121@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r)) :qid |qp.psmValDef91|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@76@main)))) r) r) :pattern (($FVF.lookup_left (as sm@121@main $FVF<left>) r)) :qid |qp.psmResTrgDef92|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$3@120@main $Ref)) (! (and (=> (Set_in n$3@120@main nodes@2@main) (and (Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))) (or (Set_in n$3@120@main nodes@2@main) (not (Set_in n$3@120@main nodes@2@main))) (=> (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))) (or (not (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$3@120@main $Ref)) (! (and (=> (Set_in n$3@120@main nodes@2@main) (and (Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))) (or (Set_in n$3@120@main nodes@2@main) (not (Set_in n$3@120@main nodes@2@main))) (=> (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) n$3@120@main))) (or (not (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null)))) (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))))) :pattern ((Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@121@main $FVF<left>) n$3@120@main) n$3@120@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(push) ; 5
(assert (not (forall ((n$3@120@main $Ref)) (! (=> (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) nodes@2@main)) :pattern ((Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@121@main $FVF<left>) n$3@120@main) n$3@120@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(assert (forall ((n$3@120@main $Ref)) (! (=> (and (Set_in n$3@120@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@108@main $FVF<left>) n$3@120@main) nodes@2@main)) :pattern ((Set_in n$3@120@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@121@main $FVF<left>) n$3@120@main) n$3@120@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
; [eval] (forall n$4: Ref :: { (n$4.right in nodes) } { (n$4 in nodes), n$4.right } (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes))
(declare-const n$4@122@main $Ref)
(push) ; 5
; [eval] (n$4 in nodes) && n$4.right != null ==> (n$4.right in nodes)
; [eval] (n$4 in nodes) && n$4.right != null
; [eval] (n$4 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$4@122@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$4@122@main nodes@2@main))
; [eval] n$4.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))
(push) ; 8
(assert (not (and (img@83@main n$4@122@main) (Set_in (inv@82@main n$4@122@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$4@122@main nodes@2@main) (and (Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))))
(assert (or (Set_in n$4@122@main nodes@2@main) (not (Set_in n$4@122@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))))
; [eval] (n$4.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))
(push) ; 8
(assert (not (and (img@83@main n$4@122@main) (Set_in (inv@82@main n$4@122@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)))))
(declare-const sm@123@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@123@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@123@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef93|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@123@main $FVF<right>) r)) :qid |qp.psmResTrgDef94|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@83@main r) (Set_in (inv@82@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@123@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r))) :pattern (($FVF.lookup_right (as sm@123@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r)) :qid |qp.psmValDef93|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@76@main))))) r) r) :pattern (($FVF.lookup_right (as sm@123@main $FVF<right>) r)) :qid |qp.psmResTrgDef94|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$4@122@main $Ref)) (! (and (=> (Set_in n$4@122@main nodes@2@main) (and (Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))) (or (Set_in n$4@122@main nodes@2@main) (not (Set_in n$4@122@main nodes@2@main))) (=> (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))) (or (not (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(assert (forall ((n$4@122@main $Ref)) (! (and (=> (Set_in n$4@122@main nodes@2@main) (and (Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))) (or (Set_in n$4@122@main nodes@2@main) (not (Set_in n$4@122@main nodes@2@main))) (=> (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) n$4@122@main))) (or (not (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null)))) (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))))) :pattern ((Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@123@main $FVF<right>) n$4@122@main) n$4@122@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38-aux|)))
(push) ; 5
(assert (not (forall ((n$4@122@main $Ref)) (! (=> (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) nodes@2@main)) :pattern ((Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@123@main $FVF<right>) n$4@122@main) n$4@122@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(assert (forall ((n$4@122@main $Ref)) (! (=> (and (Set_in n$4@122@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@113@main $FVF<right>) n$4@122@main) nodes@2@main)) :pattern ((Set_in n$4@122@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@123@main $FVF<right>) n$4@122@main) n$4@122@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@23@28@23@38|)))
; [eval] !node.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))
(push) ; 5
(assert (not (and (img@87@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) (Set_in (inv@86@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(assert (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main))))
(declare-const snapshot@124@main $Snap)
(assert (= snapshot@124@main ($Snap.combine ($Snap.first snapshot@124@main) ($Snap.second snapshot@124@main))))
(assert (= ($Snap.first snapshot@124@main) $Snap.unit))
; [eval] (node in nodes)
(assert (= ($Snap.second snapshot@124@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@124@main)) ($Snap.second ($Snap.second snapshot@124@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@124@main)) $Snap.unit))
; [eval] !((null in nodes))
; [eval] (null in nodes)
(assert (= ($Snap.second ($Snap.second snapshot@124@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@124@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))
(declare-const n$5@125@main $Ref)
(push) ; 5
; [eval] (n$5 in nodes)
(assert (Set_in n$5@125@main nodes@2@main))
(pop) ; 5
(declare-fun inv@126@main ($Ref) $Ref)
(declare-fun img@127@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 5
(assert (not (forall ((n$51@125@main $Ref) (n$52@125@main $Ref)) (! (=> (and (Set_in n$51@125@main nodes@2@main) (Set_in n$52@125@main nodes@2@main) (= n$51@125@main n$52@125@main)) (= n$51@125@main n$52@125@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$5@125@main $Ref)) (! (=> (Set_in n$5@125@main nodes@2@main) (and (= (inv@126@main n$5@125@main) n$5@125@main) (img@127@main n$5@125@main))) :pattern ((Set_in n$5@125@main nodes@2@main)) :pattern ((inv@126@main n$5@125@main)) :pattern ((img@127@main n$5@125@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= (inv@126@main r) r)) :pattern ((inv@126@main r)) :qid |left-fctOfInv|)))
(assert (forall ((n$5@125@main $Ref)) (! (=> (Set_in n$5@125@main nodes@2@main) (not (= n$5@125@main $Ref.null))) :pattern ((Set_in n$5@125@main nodes@2@main)) :pattern ((inv@126@main n$5@125@main)) :pattern ((img@127@main n$5@125@main)) :qid |left-permImpliesNonNull|)))
(declare-const sm@128@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@128@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef96|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@128@main $FVF<left>) r)) :qid |qp.psmResTrgDef97|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@126@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) r) r)) :pattern ((inv@126@main r)) :qid |quant-u-55|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))
(declare-const n$6@129@main $Ref)
(push) ; 5
; [eval] (n$6 in nodes)
(assert (Set_in n$6@129@main nodes@2@main))
(pop) ; 5
(declare-fun inv@130@main ($Ref) $Ref)
(declare-fun img@131@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 5
(assert (not (forall ((n$61@129@main $Ref) (n$62@129@main $Ref)) (! (=> (and (Set_in n$61@129@main nodes@2@main) (Set_in n$62@129@main nodes@2@main) (= n$61@129@main n$62@129@main)) (= n$61@129@main n$62@129@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$6@129@main $Ref)) (! (=> (Set_in n$6@129@main nodes@2@main) (and (= (inv@130@main n$6@129@main) n$6@129@main) (img@131@main n$6@129@main))) :pattern ((Set_in n$6@129@main nodes@2@main)) :pattern ((inv@130@main n$6@129@main)) :pattern ((img@131@main n$6@129@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= (inv@130@main r) r)) :pattern ((inv@130@main r)) :qid |right-fctOfInv|)))
(assert (forall ((n$6@129@main $Ref)) (! (=> (Set_in n$6@129@main nodes@2@main) (not (= n$6@129@main $Ref.null))) :pattern ((Set_in n$6@129@main nodes@2@main)) :pattern ((inv@130@main n$6@129@main)) :pattern ((img@131@main n$6@129@main)) :qid |right-permImpliesNonNull|)))
(declare-const sm@132@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@132@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef99|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@132@main $FVF<right>) r)) :qid |qp.psmResTrgDef100|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@130@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) r) r)) :pattern ((inv@130@main r)) :qid |quant-u-57|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))
(declare-const n$7@133@main $Ref)
(push) ; 5
; [eval] (n$7 in nodes)
(assert (Set_in n$7@133@main nodes@2@main))
(pop) ; 5
(declare-fun inv@134@main ($Ref) $Ref)
(declare-fun img@135@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(push) ; 5
(assert (not (forall ((n$71@133@main $Ref) (n$72@133@main $Ref)) (! (=> (and (Set_in n$71@133@main nodes@2@main) (Set_in n$72@133@main nodes@2@main) (= n$71@133@main n$72@133@main)) (= n$71@133@main n$72@133@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$7@133@main $Ref)) (! (=> (Set_in n$7@133@main nodes@2@main) (and (= (inv@134@main n$7@133@main) n$7@133@main) (img@135@main n$7@133@main))) :pattern ((Set_in n$7@133@main nodes@2@main)) :pattern ((inv@134@main n$7@133@main)) :pattern ((img@135@main n$7@133@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= (inv@134@main r) r)) :pattern ((inv@134@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((n$7@133@main $Ref)) (! (=> (Set_in n$7@133@main nodes@2@main) (not (= n$7@133@main $Ref.null))) :pattern ((Set_in n$7@133@main nodes@2@main)) :pattern ((inv@134@main n$7@133@main)) :pattern ((img@135@main n$7@133@main)) :qid |is_marked-permImpliesNonNull|)))
(declare-const sm@136@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef102|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef103|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@134@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) r) r)) :pattern ((inv@134@main r)) :qid |quant-u-59|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) $Snap.unit))
; [eval] (forall n$8: Ref :: { (n$8.left in nodes) } { (n$8 in nodes), n$8.left } (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes))
(declare-const n$8@137@main $Ref)
(push) ; 5
; [eval] (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes)
; [eval] (n$8 in nodes) && n$8.left != null
; [eval] (n$8 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$8@137@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$8@137@main nodes@2@main))
; [eval] n$8.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))
(push) ; 8
(assert (not (and (img@127@main n$8@137@main) (Set_in (inv@126@main n$8@137@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$8@137@main nodes@2@main) (and (Set_in n$8@137@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))))
(assert (or (Set_in n$8@137@main nodes@2@main) (not (Set_in n$8@137@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))))
; [eval] (n$8.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))
(push) ; 8
(assert (not (and (img@127@main n$8@137@main) (Set_in (inv@126@main n$8@137@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)))))
(declare-const sm@138@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@138@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@138@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@138@main $FVF<left>) r)) :qid |qp.psmResTrgDef105|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@138@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@138@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@138@main $FVF<left>) r)) :qid |qp.psmResTrgDef105|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$8@137@main $Ref)) (! (and (=> (Set_in n$8@137@main nodes@2@main) (and (Set_in n$8@137@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))) (or (Set_in n$8@137@main nodes@2@main) (not (Set_in n$8@137@main nodes@2@main))) (=> (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))) (or (not (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@137@main $Ref)) (! (and (=> (Set_in n$8@137@main nodes@2@main) (and (Set_in n$8@137@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))) (or (Set_in n$8@137@main nodes@2@main) (not (Set_in n$8@137@main nodes@2@main))) (=> (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) n$8@137@main))) (or (not (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null)))) (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))))) :pattern ((Set_in n$8@137@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@138@main $FVF<left>) n$8@137@main) n$8@137@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@137@main $Ref)) (! (=> (and (Set_in n$8@137@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@128@main $FVF<left>) n$8@137@main) nodes@2@main)) :pattern ((Set_in n$8@137@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@138@main $FVF<left>) n$8@137@main) n$8@137@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))) $Snap.unit))
; [eval] (forall n$9: Ref :: { (n$9.right in nodes) } { (n$9 in nodes), n$9.right } (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes))
(declare-const n$9@139@main $Ref)
(push) ; 5
; [eval] (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes)
; [eval] (n$9 in nodes) && n$9.right != null
; [eval] (n$9 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$9@139@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$9@139@main nodes@2@main))
; [eval] n$9.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))
(push) ; 8
(assert (not (and (img@131@main n$9@139@main) (Set_in (inv@130@main n$9@139@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$9@139@main nodes@2@main) (and (Set_in n$9@139@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))))
(assert (or (Set_in n$9@139@main nodes@2@main) (not (Set_in n$9@139@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))))
; [eval] (n$9.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))
(push) ; 8
(assert (not (and (img@131@main n$9@139@main) (Set_in (inv@130@main n$9@139@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)))))
(declare-const sm@140@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@140@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@140@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef106|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@140@main $FVF<right>) r)) :qid |qp.psmResTrgDef107|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@140@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@140@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef106|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@140@main $FVF<right>) r)) :qid |qp.psmResTrgDef107|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$9@139@main $Ref)) (! (and (=> (Set_in n$9@139@main nodes@2@main) (and (Set_in n$9@139@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))) (or (Set_in n$9@139@main nodes@2@main) (not (Set_in n$9@139@main nodes@2@main))) (=> (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))) (or (not (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@139@main $Ref)) (! (and (=> (Set_in n$9@139@main nodes@2@main) (and (Set_in n$9@139@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))) (or (Set_in n$9@139@main nodes@2@main) (not (Set_in n$9@139@main nodes@2@main))) (=> (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) n$9@139@main))) (or (not (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null)))) (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))))) :pattern ((Set_in n$9@139@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@140@main $FVF<right>) n$9@139@main) n$9@139@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@139@main $Ref)) (! (=> (and (Set_in n$9@139@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@132@main $FVF<right>) n$9@139@main) nodes@2@main)) :pattern ((Set_in n$9@139@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@140@main $FVF<right>) n$9@139@main) n$9@139@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } (n in nodes) ==> old(n.is_marked) ==> n.is_marked)
(declare-const n@141@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> old(n.is_marked) ==> n.is_marked
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@141@main nodes@2@main))
; [eval] old(n.is_marked) ==> n.is_marked
; [eval] old(n.is_marked)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) n@141@main))
(push) ; 8
(assert (not (and (img@87@main n@141@main) (Set_in (inv@86@main n@141@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@141@main) n@141@main))
(push) ; 10
(assert (not (and (img@135@main n@141@main) (Set_in (inv@134@main n@141@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(push) ; 9
(assert (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) (and ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@141@main) n@141@main))))
; Joined path conditions
(assert (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)))
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@141@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@141@main nodes@2@main) (and (Set_in n@141@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) n@141@main) (=> ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) (and ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@141@main) n@141@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)))))
; Joined path conditions
(assert (or (not (Set_in n@141@main nodes@2@main)) (Set_in n@141@main nodes@2@main)))
(declare-const sm@142@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef109|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef109|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@141@main $Ref)) (! (and (=> (Set_in n@141@main nodes@2@main) (and (Set_in n@141@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) n@141@main) (=> ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) (and ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@141@main) n@141@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)))) (or (not (Set_in n@141@main nodes@2@main)) (Set_in n@141@main nodes@2@main))) :pattern ((Set_in n@141@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) n@141@main) n@141@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102-aux|)))
(assert (forall ((n@141@main $Ref)) (! (=> (and (Set_in n@141@main nodes@2@main) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@141@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@141@main)) :pattern ((Set_in n@141@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@142@main $FVF<is_marked>) n@141@main) n@141@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))) $Snap.unit))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))
(push) ; 5
(assert (not (and (img@135@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) (Set_in (inv@134@main ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(assert ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@84@main $FVF<right>) node@3@main)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.left } (n in nodes) ==> n.left == old(n.left))
(declare-const n@143@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> n.left == old(n.left)
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@143@main nodes@2@main))
; [eval] n.left == old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@143@main) n@143@main))
(push) ; 8
(assert (not (and (img@127@main n@143@main) (Set_in (inv@126@main n@143@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
; [eval] old(n.left)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n@143@main) n@143@main))
(push) ; 8
(assert (not (and (img@79@main n@143@main) (Set_in (inv@78@main n@143@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@143@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@143@main nodes@2@main) (and (Set_in n@143@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@143@main) n@143@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n@143@main) n@143@main))))
; Joined path conditions
(assert (or (not (Set_in n@143@main nodes@2@main)) (Set_in n@143@main nodes@2@main)))
(declare-const sm@144@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@144@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@144@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef110|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@144@main $FVF<left>) r)) :qid |qp.psmResTrgDef111|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@144@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@144@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef110|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@144@main $FVF<left>) r)) :qid |qp.psmResTrgDef111|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@143@main $Ref)) (! (and (=> (Set_in n@143@main nodes@2@main) (and (Set_in n@143@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@143@main) n@143@main) ($FVF.loc_left ($FVF.lookup_left (as sm@108@main $FVF<left>) n@143@main) n@143@main))) (or (not (Set_in n@143@main nodes@2@main)) (Set_in n@143@main nodes@2@main))) :pattern ((Set_in n@143@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@144@main $FVF<left>) n@143@main) n@143@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86-aux|)))
(assert (forall ((n@143@main $Ref)) (! (=> (Set_in n@143@main nodes@2@main) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@143@main) ($FVF.lookup_left (as sm@108@main $FVF<left>) n@143@main))) :pattern ((Set_in n@143@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@144@main $FVF<left>) n@143@main) n@143@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@34@10@34@86|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.right } (n in nodes) ==> n.right == old(n.right))
(declare-const n@145@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> n.right == old(n.right)
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@145@main nodes@2@main))
; [eval] n.right == old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@145@main) n@145@main))
(push) ; 8
(assert (not (and (img@131@main n@145@main) (Set_in (inv@130@main n@145@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
; [eval] old(n.right)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n@145@main) n@145@main))
(push) ; 8
(assert (not (and (img@83@main n@145@main) (Set_in (inv@82@main n@145@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@145@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@145@main nodes@2@main) (and (Set_in n@145@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@145@main) n@145@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n@145@main) n@145@main))))
; Joined path conditions
(assert (or (not (Set_in n@145@main nodes@2@main)) (Set_in n@145@main nodes@2@main)))
(declare-const sm@146@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@146@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@146@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef112|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@146@main $FVF<right>) r)) :qid |qp.psmResTrgDef113|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@146@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@146@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef112|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@146@main $FVF<right>) r)) :qid |qp.psmResTrgDef113|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@145@main $Ref)) (! (and (=> (Set_in n@145@main nodes@2@main) (and (Set_in n@145@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@145@main) n@145@main) ($FVF.loc_right ($FVF.lookup_right (as sm@113@main $FVF<right>) n@145@main) n@145@main))) (or (not (Set_in n@145@main nodes@2@main)) (Set_in n@145@main nodes@2@main))) :pattern ((Set_in n@145@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@146@main $FVF<right>) n@145@main) n@145@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89-aux|)))
(assert (forall ((n@145@main $Ref)) (! (=> (Set_in n@145@main nodes@2@main) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@145@main) ($FVF.lookup_right (as sm@113@main $FVF<right>) n@145@main))) :pattern ((Set_in n@145@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@146@main $FVF<right>) n@145@main) n@145@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@35@10@35@89|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.left.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked)
(declare-const n@147@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@147@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.left == null || n.left.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main) n@147@main))
(push) ; 8
(assert (not (and (img@87@main n@147@main) (Set_in (inv@86@main n@147@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main))
(pop) ; 9
(push) ; 9
(assert (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) n@147@main))
(push) ; 10
(assert (not (and (img@135@main n@147@main) (Set_in (inv@134@main n@147@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) n@147@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)))
(push) ; 8
(push) ; 9
(assert (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main)))
; [eval] n.left == null || n.left.is_marked
; [eval] n.left == null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main))
(push) ; 10
(assert (not (and (img@127@main n@147@main) (Set_in (inv@126@main n@147@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(push) ; 11
(assert (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null))
(pop) ; 11
(push) ; 11
(assert (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))
(push) ; 12
(assert (not (and (img@127@main n@147@main) (Set_in (inv@126@main n@147@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 12
; 2ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))
(push) ; 12
(assert (not (and (img@135@main ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) (Set_in (inv@134@main ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(pop) ; 11
(pop) ; 10
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))))
(assert (or (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))
(pop) ; 9
(push) ; 9
(assert (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main) (=> (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))) (or (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))))
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@147@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@147@main nodes@2@main) (and (Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main) n@147@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) n@147@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main) (=> (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))) (or (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))))))
; Joined path conditions
(assert (or (not (Set_in n@147@main nodes@2@main)) (Set_in n@147@main nodes@2@main)))
(declare-const sm@148@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef114|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef115|)))
(declare-const sm@149@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef117|)))
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef114|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef115|)))
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef117|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@147@main $Ref)) (! (and (=> (Set_in n@147@main nodes@2@main) (and (Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main) n@147@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) n@147@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main) (=> (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))) (or (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))))) (or (not (Set_in n@147@main nodes@2@main)) (Set_in n@147@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main)) :pattern ((Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) n@147@main) n@147@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@147@main $Ref)) (! (and (=> (Set_in n@147@main nodes@2@main) (and (Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main) n@147@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) n@147@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main) (=> (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (and (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))) (or (not (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)) (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))))) (or (not (Set_in n@147@main nodes@2@main)) (Set_in n@147@main nodes@2@main)) ($FVF.loc_left ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) n@147@main)) :pattern ((Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103-aux|)))
(assert (forall ((n@147@main $Ref)) (! (=> (and (Set_in n@147@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@147@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@147@main))) (or (= ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main) $Ref.null) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)))) :pattern ((Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@148@main $FVF<is_marked>) n@147@main) n@147@main)) :pattern ((Set_in n@147@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@149@main $FVF<is_marked>) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main)) ($FVF.lookup_left (as sm@128@main $FVF<left>) n@147@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@38@10@39@103|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))))))))) $Snap.unit))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } { (n in nodes), n.right.is_marked } (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked)
(declare-const n@150@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@150@main nodes@2@main))
; [eval] old(!n.is_marked) && n.is_marked ==> n.right == null || n.right.is_marked
; [eval] old(!n.is_marked) && n.is_marked
; [eval] old(!n.is_marked)
; [eval] !n.is_marked
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main) n@150@main))
(push) ; 8
(assert (not (and (img@87@main n@150@main) (Set_in (inv@86@main n@150@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main))
(pop) ; 9
(push) ; 9
(assert (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) n@150@main))
(push) ; 10
(assert (not (and (img@135@main n@150@main) (Set_in (inv@134@main n@150@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) n@150@main))))
(assert (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)))
(push) ; 8
(push) ; 9
(assert (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main)))
; [eval] n.right == null || n.right.is_marked
; [eval] n.right == null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main))
(push) ; 10
(assert (not (and (img@131@main n@150@main) (Set_in (inv@130@main n@150@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(push) ; 11
(assert (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null))
(pop) ; 11
(push) ; 11
(assert (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))
(push) ; 12
(assert (not (and (img@131@main n@150@main) (Set_in (inv@130@main n@150@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 12
; 2ms
; (get-info :all-statistics)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))
(push) ; 12
(assert (not (and (img@135@main ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) (Set_in (inv@134@main ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(pop) ; 11
(pop) ; 10
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))))
(assert (or (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))
(pop) ; 9
(push) ; 9
(assert (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main) (=> (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))) (or (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))))
; Joined path conditions
(assert (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))))
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@150@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@150@main nodes@2@main) (and (Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main) n@150@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) n@150@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main) (=> (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))) (or (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))))))
; Joined path conditions
(assert (or (not (Set_in n@150@main nodes@2@main)) (Set_in n@150@main nodes@2@main)))
(declare-const sm@151@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef119|)))
(declare-const sm@152@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef120|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef121|)))
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef119|)))
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef120|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef121|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@150@main $Ref)) (! (and (=> (Set_in n@150@main nodes@2@main) (and (Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main) n@150@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) n@150@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main) (=> (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))) (or (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))))) (or (not (Set_in n@150@main nodes@2@main)) (Set_in n@150@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main)) :pattern ((Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) n@150@main) n@150@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@150@main $Ref)) (! (and (=> (Set_in n@150@main nodes@2@main) (and (Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main) n@150@main) (=> (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) n@150@main))) (or (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) (=> (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main)) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main) (=> (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (and (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))) (or (not (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)) (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null)))) (or (not (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))))) (or (not (Set_in n@150@main nodes@2@main)) (Set_in n@150@main nodes@2@main)) ($FVF.loc_right ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) n@150@main)) :pattern ((Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104-aux|)))
(assert (forall ((n@150@main $Ref)) (! (=> (and (Set_in n@150@main nodes@2@main) (and (not ($FVF.lookup_is_marked (as sm@118@main $FVF<is_marked>) n@150@main)) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) n@150@main))) (or (= ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main) $Ref.null) ($FVF.lookup_is_marked (as sm@136@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)))) :pattern ((Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@151@main $FVF<is_marked>) n@150@main) n@150@main)) :pattern ((Set_in n@150@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@152@main $FVF<is_marked>) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main)) ($FVF.lookup_right (as sm@132@main $FVF<right>) n@150@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@40@10@41@104|)))
; [eval] (node in nodes)
; [eval] !((null in nodes))
; [eval] (null in nodes)
(declare-const n$5@153@main $Ref)
(push) ; 5
; [eval] (n$5 in nodes)
(assert (Set_in n$5@153@main nodes@2@main))
(pop) ; 5
(declare-fun inv@154@main ($Ref) $Ref)
(declare-fun img@155@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@156@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@156@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@156@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@156@main $FVF<left>) r)) :qid |qp.psmResTrgDef123|)))
(push) ; 5
(assert (not (forall ((n$51@153@main $Ref) (n$52@153@main $Ref)) (! (=> (and (and (Set_in n$51@153@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$51@153@main) n$51@153@main)) (and (Set_in n$52@153@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$52@153@main) n$52@153@main)) (= n$51@153@main n$52@153@main)) (= n$51@153@main n$52@153@main)) :qid |left-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$5@153@main $Ref)) (! (=> (Set_in n$5@153@main nodes@2@main) (and (= (inv@154@main n$5@153@main) n$5@153@main) (img@155@main n$5@153@main))) :pattern ((Set_in n$5@153@main nodes@2@main)) :pattern ((inv@154@main n$5@153@main)) :pattern ((img@155@main n$5@153@main)) :qid |left-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@155@main r) (Set_in (inv@154@main r) nodes@2@main)) (= (inv@154@main r) r)) :pattern ((inv@154@main r)) :qid |left-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@154@main r) nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) r) r)) :pattern ((inv@154@main r)) :qid |quant-u-61|)))
(define-fun pTaken@157@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@154@main r) nodes@2@main) (img@155@main r) (= r (inv@154@main r))) ($Perm.min (ite (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@157@main r)) $Perm.No) :qid |quant-u-62|))))
(check-sat)
; unsat
(pop) ; 5
; 9ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@154@main r) nodes@2@main) (img@155@main r) (= r (inv@154@main r))) (= (- $Perm.Write (pTaken@157@main r)) $Perm.No)) :qid |quant-u-63|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
(declare-const n$6@158@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$6 in nodes)
(assert (Set_in n$6@158@main nodes@2@main))
(pop) ; 5
(declare-fun inv@159@main ($Ref) $Ref)
(declare-fun img@160@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@161@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@161@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@161@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef124|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@161@main $FVF<right>) r)) :qid |qp.psmResTrgDef125|)))
(push) ; 5
(assert (not (forall ((n$61@158@main $Ref) (n$62@158@main $Ref)) (! (=> (and (and (Set_in n$61@158@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$61@158@main) n$61@158@main)) (and (Set_in n$62@158@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$62@158@main) n$62@158@main)) (= n$61@158@main n$62@158@main)) (= n$61@158@main n$62@158@main)) :qid |right-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$6@158@main $Ref)) (! (=> (Set_in n$6@158@main nodes@2@main) (and (= (inv@159@main n$6@158@main) n$6@158@main) (img@160@main n$6@158@main))) :pattern ((Set_in n$6@158@main nodes@2@main)) :pattern ((inv@159@main n$6@158@main)) :pattern ((img@160@main n$6@158@main)) :qid |right-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@160@main r) (Set_in (inv@159@main r) nodes@2@main)) (= (inv@159@main r) r)) :pattern ((inv@159@main r)) :qid |right-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@159@main r) nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) r) r)) :pattern ((inv@159@main r)) :qid |quant-u-66|)))
(define-fun pTaken@162@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@159@main r) nodes@2@main) (img@160@main r) (= r (inv@159@main r))) ($Perm.min (ite (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@162@main r)) $Perm.No) :qid |quant-u-67|))))
(check-sat)
; unsat
(pop) ; 5
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@159@main r) nodes@2@main) (img@160@main r) (= r (inv@159@main r))) (= (- $Perm.Write (pTaken@162@main r)) $Perm.No)) :qid |quant-u-68|))))
(check-sat)
; unsat
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(declare-const n$7@163@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$7 in nodes)
(assert (Set_in n$7@163@main nodes@2@main))
(pop) ; 5
(declare-fun inv@164@main ($Ref) $Ref)
(declare-fun img@165@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(declare-const sm@166@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef127|)))
(push) ; 5
(assert (not (forall ((n$71@163@main $Ref) (n$72@163@main $Ref)) (! (=> (and (and (Set_in n$71@163@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n$71@163@main) n$71@163@main)) (and (Set_in n$72@163@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n$72@163@main) n$72@163@main)) (= n$71@163@main n$72@163@main)) (= n$71@163@main n$72@163@main)) :qid |is_marked-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((n$7@163@main $Ref)) (! (=> (Set_in n$7@163@main nodes@2@main) (and (= (inv@164@main n$7@163@main) n$7@163@main) (img@165@main n$7@163@main))) :pattern ((Set_in n$7@163@main nodes@2@main)) :pattern ((inv@164@main n$7@163@main)) :pattern ((img@165@main n$7@163@main)) :qid |is_marked-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@165@main r) (Set_in (inv@164@main r) nodes@2@main)) (= (inv@164@main r) r)) :pattern ((inv@164@main r)) :qid |is_marked-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (Set_in (inv@164@main r) nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) r) r)) :pattern ((inv@164@main r)) :qid |quant-u-71|)))
(define-fun pTaken@167@main ((r $Ref)) $Perm
  (ite (and (Set_in (inv@164@main r) nodes@2@main) (img@165@main r) (= r (inv@164@main r))) ($Perm.min (ite (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) $Perm.Write $Perm.No) (pTaken@167@main r)) $Perm.No) :qid |quant-u-72|))))
(check-sat)
; unsat
(pop) ; 5
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (Set_in (inv@164@main r) nodes@2@main) (img@165@main r) (= r (inv@164@main r))) (= (- $Perm.Write (pTaken@167@main r)) $Perm.No)) :qid |quant-u-73|))))
(check-sat)
; unsat
(pop) ; 5
; 2ms
; (get-info :all-statistics)
; [eval] (forall n$8: Ref :: { (n$8.left in nodes) } { (n$8 in nodes), n$8.left } (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes))
(declare-const n$8@168@main $Ref)
(set-option :rlimit 0)
(push) ; 5
; [eval] (n$8 in nodes) && n$8.left != null ==> (n$8.left in nodes)
; [eval] (n$8 in nodes) && n$8.left != null
; [eval] (n$8 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$8@168@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$8@168@main nodes@2@main))
; [eval] n$8.left != null
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))
(push) ; 8
(assert (not (and (img@127@main n$8@168@main) (Set_in (inv@126@main n$8@168@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$8@168@main nodes@2@main) (and (Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))))
(assert (or (Set_in n$8@168@main nodes@2@main) (not (Set_in n$8@168@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))))
; [eval] (n$8.left in nodes)
(assert ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))
(push) ; 8
(assert (not (and (img@127@main n$8@168@main) (Set_in (inv@126@main n$8@168@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 4ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)))))
(declare-const sm@169@main $FVF<left>)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@169@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@169@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef128|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@169@main $FVF<left>) r)) :qid |qp.psmResTrgDef129|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@127@main r) (Set_in (inv@126@main r) nodes@2@main)) (= ($FVF.lookup_left (as sm@169@main $FVF<left>) r) ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r))) :pattern (($FVF.lookup_left (as sm@169@main $FVF<left>) r)) :pattern (($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r)) :qid |qp.psmValDef128|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_left ($FVF.lookup_left ($SortWrappers.$SnapTo$FVF<left> ($Snap.first ($Snap.second ($Snap.second snapshot@124@main)))) r) r) :pattern (($FVF.lookup_left (as sm@169@main $FVF<left>) r)) :qid |qp.psmResTrgDef129|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$8@168@main $Ref)) (! (and (=> (Set_in n$8@168@main nodes@2@main) (and (Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))) (or (Set_in n$8@168@main nodes@2@main) (not (Set_in n$8@168@main nodes@2@main))) (=> (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))) (or (not (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$8@168@main $Ref)) (! (and (=> (Set_in n$8@168@main nodes@2@main) (and (Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))) (or (Set_in n$8@168@main nodes@2@main) (not (Set_in n$8@168@main nodes@2@main))) (=> (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)) ($FVF.loc_left ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) n$8@168@main))) (or (not (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null)))) (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))))) :pattern ((Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@169@main $FVF<left>) n$8@168@main) n$8@168@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(push) ; 5
(assert (not (forall ((n$8@168@main $Ref)) (! (=> (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) nodes@2@main)) :pattern ((Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@169@main $FVF<left>) n$8@168@main) n$8@168@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|))))
(check-sat)
; unsat
(pop) ; 5
; 3ms
; (get-info :all-statistics)
(assert (forall ((n$8@168@main $Ref)) (! (=> (and (Set_in n$8@168@main nodes@2@main) (not (= ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) $Ref.null))) (Set_in ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_left (as sm@156@main $FVF<left>) n$8@168@main) nodes@2@main)) :pattern ((Set_in n$8@168@main nodes@2@main) ($FVF.loc_left ($FVF.lookup_left (as sm@169@main $FVF<left>) n$8@168@main) n$8@168@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
; [eval] (forall n$9: Ref :: { (n$9.right in nodes) } { (n$9 in nodes), n$9.right } (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes))
(declare-const n$9@170@main $Ref)
(push) ; 5
; [eval] (n$9 in nodes) && n$9.right != null ==> (n$9.right in nodes)
; [eval] (n$9 in nodes) && n$9.right != null
; [eval] (n$9 in nodes)
(push) ; 6
(push) ; 7
(assert (not (Set_in n$9@170@main nodes@2@main)))
(pop) ; 7
(push) ; 7
(assert (Set_in n$9@170@main nodes@2@main))
; [eval] n$9.right != null
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))
(push) ; 8
(assert (not (and (img@131@main n$9@170@main) (Set_in (inv@130@main n$9@170@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Set_in n$9@170@main nodes@2@main) (and (Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))))
(assert (or (Set_in n$9@170@main nodes@2@main) (not (Set_in n$9@170@main nodes@2@main))))
(push) ; 6
(push) ; 7
(assert (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))))
; [eval] (n$9.right in nodes)
(assert ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))
(push) ; 8
(assert (not (and (img@131@main n$9@170@main) (Set_in (inv@130@main n$9@170@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 4ms
; (get-info :all-statistics)
(pop) ; 7
(push) ; 7
(assert (not (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))))
; Joined path conditions
(assert (or (not (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)))))
(declare-const sm@171@main $FVF<right>)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@171@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@171@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef130|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@171@main $FVF<right>) r)) :qid |qp.psmResTrgDef131|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@131@main r) (Set_in (inv@130@main r) nodes@2@main)) (= ($FVF.lookup_right (as sm@171@main $FVF<right>) r) ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r))) :pattern (($FVF.lookup_right (as sm@171@main $FVF<right>) r)) :pattern (($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r)) :qid |qp.psmValDef130|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_right ($FVF.lookup_right ($SortWrappers.$SnapTo$FVF<right> ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@124@main))))) r) r) :pattern (($FVF.lookup_right (as sm@171@main $FVF<right>) r)) :qid |qp.psmResTrgDef131|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n$9@170@main $Ref)) (! (and (=> (Set_in n$9@170@main nodes@2@main) (and (Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))) (or (Set_in n$9@170@main nodes@2@main) (not (Set_in n$9@170@main nodes@2@main))) (=> (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))) (or (not (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))))) :pattern ((Set_in ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) nodes@2@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(assert (forall ((n$9@170@main $Ref)) (! (and (=> (Set_in n$9@170@main nodes@2@main) (and (Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))) (or (Set_in n$9@170@main nodes@2@main) (not (Set_in n$9@170@main nodes@2@main))) (=> (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)) ($FVF.loc_right ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) n$9@170@main))) (or (not (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null)))) (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))))) :pattern ((Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@171@main $FVF<right>) n$9@170@main) n$9@170@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37-aux|)))
(push) ; 5
(assert (not (forall ((n$9@170@main $Ref)) (! (=> (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) nodes@2@main)) :pattern ((Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@171@main $FVF<right>) n$9@170@main) n$9@170@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|))))
(check-sat)
; unsat
(pop) ; 5
; 3ms
; (get-info :all-statistics)
(assert (forall ((n$9@170@main $Ref)) (! (=> (and (Set_in n$9@170@main nodes@2@main) (not (= ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) $Ref.null))) (Set_in ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) nodes@2@main)) :pattern ((Set_in ($FVF.lookup_right (as sm@161@main $FVF<right>) n$9@170@main) nodes@2@main)) :pattern ((Set_in n$9@170@main nodes@2@main) ($FVF.loc_right ($FVF.lookup_right (as sm@171@main $FVF<right>) n$9@170@main) n$9@170@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@26@27@26@37|)))
; [eval] (forall n: Ref :: { (n in nodes), n.is_marked } (n in nodes) ==> old(n.is_marked) ==> n.is_marked)
(declare-const n@172@main $Ref)
(push) ; 5
; [eval] (n in nodes) ==> old(n.is_marked) ==> n.is_marked
; [eval] (n in nodes)
(push) ; 6
(push) ; 7
(assert (Set_in n@172@main nodes@2@main))
; [eval] old(n.is_marked) ==> n.is_marked
; [eval] old(n.is_marked)
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) n@172@main))
(push) ; 8
(assert (not (and (img@15@main n@172@main) (Set_in (inv@14@main n@172@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(push) ; 8
(push) ; 9
(assert ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main))
(assert ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n@172@main) n@172@main))
(push) ; 10
(assert (not (and (img@135@main n@172@main) (Set_in (inv@134@main n@172@main) nodes@2@main))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(push) ; 9
(assert (not ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) (and ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n@172@main) n@172@main))))
; Joined path conditions
(assert (or (not ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)) ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)))
(pop) ; 7
(push) ; 7
(assert (not (Set_in n@172@main nodes@2@main)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=> (Set_in n@172@main nodes@2@main) (and (Set_in n@172@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) n@172@main) (=> ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) (and ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n@172@main) n@172@main))) (or (not ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)) ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)))))
; Joined path conditions
(assert (or (not (Set_in n@172@main nodes@2@main)) (Set_in n@172@main nodes@2@main)))
(declare-const sm@173@main $FVF<is_marked>)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef133|)))
(pop) ; 5
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@135@main r) (Set_in (inv@134@main r) nodes@2@main)) (= ($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r) ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r))) :pattern (($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r)) :pattern (($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_is_marked ($FVF.lookup_is_marked ($SortWrappers.$SnapTo$FVF<is_marked> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@124@main)))))) r) r) :pattern (($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) r)) :qid |qp.psmResTrgDef133|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@172@main $Ref)) (! (and (=> (Set_in n@172@main nodes@2@main) (and (Set_in n@172@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) n@172@main) (=> ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) (and ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n@172@main) n@172@main))) (or (not ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)) ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)))) (or (not (Set_in n@172@main nodes@2@main)) (Set_in n@172@main nodes@2@main))) :pattern ((Set_in n@172@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) n@172@main) n@172@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102-aux|)))
(push) ; 5
(assert (not (forall ((n@172@main $Ref)) (! (=> (and (Set_in n@172@main nodes@2@main) ($FVF.lookup_is_marked (as sm@50@main $FVF<is_marked>) n@172@main)) ($FVF.lookup_is_marked (as sm@166@main $FVF<is_marked>) n@172@main)) :pattern ((Set_in n@172@main nodes@2@main) ($FVF.loc_is_marked ($FVF.lookup_is_marked (as sm@173@main $FVF<is_marked>) n@172@main) n@172@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/graph-marking/graph-marking.vpr@30@10@30@102|))))
(check-sat)
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
