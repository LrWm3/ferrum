(get-info :version)
; (:version "4.16.0")
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :model.partial true)
(set-option :smt.qi.max_multi_patterns 1000)
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-const $Snap.null $Snap) ; hack
(declare-fun internalCondFrame (Bool $Snap $Snap) $Snap)
(assert (forall ((cnd Bool) (frst $Snap) (scnd $Snap)) (!
    (= (internalCondFrame cnd frst scnd) (ite cnd frst scnd))
    :pattern ((internalCondFrame cnd frst scnd)))))
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(declare-fun $Perm.min ($Perm $Perm) $Perm)
(assert (forall ((p1 $Perm) (p2 $Perm)) (!
    (= ($Perm.min p1 p2) (ite (<= p1 p2) p1 p2))
    :pattern (($Perm.min p1 p2)))))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
(declare-sort Seq<Int> 0)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
(declare-sort $MWSF 0)
(declare-fun MWSF_apply ($MWSF $Snap) $Snap)
(declare-fun MW_token ($MWSF $Snap) Bool)
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
(declare-fun $SortWrappers.$MWSFTo$Snap ($MWSF) $Snap)
(declare-fun $SortWrappers.$SnapTo$MWSF ($Snap) $MWSF)
(assert (forall ((x $MWSF)) (!
    (= x ($SortWrappers.$SnapTo$MWSF($SortWrappers.$MWSFTo$Snap x)))
    :pattern (($SortWrappers.$MWSFTo$Snap x))
    :qid |$Snap.$SnapTo$MWSFTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$MWSFTo$Snap($SortWrappers.$SnapTo$MWSF x)))
    :pattern (($SortWrappers.$SnapTo$MWSF x))
    :qid |$Snap.$MWSFTo$SnapTo$MWSF|
    )))
; Declaring predicate trigger functions
(declare-fun lseg%trigger ($Snap $Ref $Ref) Bool)
(declare-fun List%trigger ($Snap $Ref) Bool)
; Declaring symbols related to program functions (from program analysis)
(declare-fun contentNodes ($Snap $Ref $Ref) Seq<Int>)
(declare-fun contentNodes%limited ($Snap $Ref $Ref) Seq<Int>)
(declare-fun contentNodes%stateless ($Ref $Ref) Bool)
(declare-fun contentNodes%precondition ($Snap $Ref $Ref) Bool)
(declare-fun lengthNodes ($Snap $Ref $Ref) Int)
(declare-fun lengthNodes%limited ($Snap $Ref $Ref) Int)
(declare-fun lengthNodes%stateless ($Ref $Ref) Bool)
(declare-fun lengthNodes%precondition ($Snap $Ref $Ref) Bool)
(declare-fun content ($Snap $Ref) Seq<Int>)
(declare-fun content%limited ($Snap $Ref) Seq<Int>)
(declare-fun content%stateless ($Ref) Bool)
(declare-fun content%precondition ($Snap $Ref) Bool)
(declare-fun length ($Snap $Ref) Int)
(declare-fun length%limited ($Snap $Ref) Int)
(declare-fun length%stateless ($Ref) Bool)
(declare-fun length%precondition ($Snap $Ref) Bool)
(declare-fun peek ($Snap $Ref) Int)
(declare-fun peek%limited ($Snap $Ref) Int)
(declare-fun peek%stateless ($Ref) Bool)
(declare-fun peek%precondition ($Snap $Ref) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
(assert (forall ((s Seq<Int>)) (! (<= 0 (Seq_length s)) :pattern ((Seq_length s)) :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (! (=> (= (Seq_length s) 0) (= s (as Seq_empty Seq<Int>))) :pattern ((Seq_length s)) :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (! (= (Seq_length (Seq_singleton e)) 1) :pattern ((Seq_singleton e)) :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (not (= s1 (as Seq_empty Seq<Int>)))) (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1)))) :pattern ((Seq_length (Seq_append s0 s1))) :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (and (=> (= s0 (as Seq_empty Seq<Int>)) (= (Seq_append s0 s1) s1)) (=> (= s1 (as Seq_empty Seq<Int>)) (= (Seq_append s0 s1) s0))) :pattern ((Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (! (= (Seq_index (Seq_singleton e) 0) e) :pattern ((Seq_singleton e)) :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_add i j) (+ i j)) :pattern ((Seq_add i j)) :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_sub i j) (- i j)) :pattern ((Seq_sub i j)) :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (<= 0 n) (< n (Seq_length s0))))) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n))) :pattern ((Seq_index (Seq_append s0 s1) n)) :pattern ((Seq_index s0 n) (Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1)))))) (and (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s1 (Seq_sub n (Seq_length s0)))))) :pattern ((Seq_index (Seq_append s0 s1) n)) :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (not (= s0 (Seq_append s0 s1))) (and (not (= s1 (Seq_append s0 s1))) (and (<= 0 m) (< m (Seq_length s1))))))) (and (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m) (= (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0))) (Seq_index s1 m)))) :pattern ((Seq_index s1 m) (Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (= (Seq_length (Seq_update s i v)) (Seq_length s))) :pattern ((Seq_length (Seq_update s i v))) :pattern ((Seq_length s) (Seq_update s i v)) :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (! (=> (and (<= 0 n) (< n (Seq_length s))) (and (=> (= i n) (= (Seq_index (Seq_update s i v) n) v)) (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n))))) :pattern ((Seq_index (Seq_update s i v) n)) :pattern ((Seq_index s n) (Seq_update s i v)) :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n)) (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s))))) (=> (< n 0) (= (Seq_length (Seq_take s n)) 0))) :pattern ((Seq_length (Seq_take s n))) :pattern ((Seq_take s n) (Seq_length s)) :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (! (=> (and (<= 0 j) (and (< j n) (< j (Seq_length s)))) (= (Seq_index (Seq_take s n) j) (Seq_index s j))) :pattern ((Seq_index (Seq_take s n) j)) :pattern ((Seq_index s j) (Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n))) (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0)))) (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s)))) :pattern ((Seq_length (Seq_drop s n))) :pattern ((Seq_length s) (Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (! (=> (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n)))) (and (= (Seq_sub (Seq_add j n) n) j) (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n))))) :pattern ((Seq_index (Seq_drop s n) j)) :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (! (=> (and (< 0 n) (and (<= n i) (< i (Seq_length s)))) (and (= (Seq_add (Seq_sub i n) n) i) (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i)))) :pattern ((Seq_drop s n) (Seq_index s i)) :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_take (Seq_append s t) n) (Seq_take s n))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_take (Seq_append s t) n) (Seq_append s (Seq_take t (Seq_sub n (Seq_length s))))))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s)))))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (<= n 0) (= (Seq_take s n) (as Seq_empty Seq<Int>))) :pattern ((Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (<= n 0) (= (Seq_drop s n) s)) :pattern ((Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_take s n) s)) :pattern ((Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty Seq<Int>))) :pattern ((Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (! (=> (Seq_contains s x) (and (<= 0 (Seq_skolem s x)) (and (< (Seq_skolem s x) (Seq_length s)) (= (Seq_index s (Seq_skolem s x)) x)))) :pattern ((Seq_contains s x)) :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (! (=> (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x))) (Seq_contains s x)) :pattern ((Seq_contains s x) (Seq_index s i)) :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (Seq_contains_trigger s (Seq_index s i))) :pattern ((Seq_index s i)) :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (or (and (= s0 s1) (Seq_equal s0 s1)) (or (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1))))) (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (and (= (Seq_length s0) (Seq_length s1)) (and (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0)) (and (<= 0 (Seq_skolem_diff s0 s1)) (and (< (Seq_skolem_diff s0 s1) (Seq_length s0)) (not (= (Seq_index s0 (Seq_skolem_diff s0 s1)) (Seq_index s1 (Seq_skolem_diff s0 s1)))))))))))) :pattern ((Seq_equal s0 s1)) :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (! (=> (Seq_equal a b) (= a b)) :pattern ((Seq_equal a b)) :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (! (= (Seq_contains (Seq_singleton x) y) (= x y)) :pattern ((Seq_contains (Seq_singleton x) y)) :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (! (and (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_))) (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0))) :pattern ((Seq_length (Seq_range min_ max))) :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (! (=> (and (<= 0 j) (< j (- max min_))) (= (Seq_index (Seq_range min_ max) j) (+ min_ j))) :pattern ((Seq_index (Seq_range min_ max) j)) :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (! (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max))) :pattern ((Seq_contains (Seq_range min_ max) v)) :qid |$Seq[Int]_prog.Seq_range_contains|)))
; State saturation: after prelude
(set-option :rlimit 1000000)
(check-sat)
; unknown
(declare-fun this@0@main () $Ref)
(declare-fun end@1@main () $Ref)
(declare-fun result@2@main () Seq<Int>)
(set-option :rlimit 0)
(push) ; 1
(declare-const snapshot@12@main $Snap)
(assert (= snapshot@12@main ($Snap.combine ($Snap.first snapshot@12@main) ($Snap.second snapshot@12@main))))
(assert (= ($Snap.first snapshot@12@main) $Snap.unit))
; [eval] this == end ==> result == Seq[Int]()
; [eval] this == end
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@0@main end@1@main))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (= this@0@main end@1@main))
; [eval] result == Seq[Int]()
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
(assert (not (= this@0@main end@1@main)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= this@0@main end@1@main)) (= this@0@main end@1@main)))
(assert (=> (= this@0@main end@1@main) (Seq_equal result@2@main (as Seq_empty Seq<Int>))))
(assert (= ($Snap.second snapshot@12@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@12@main)) ($Snap.second ($Snap.second snapshot@12@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@12@main)) $Snap.unit))
; [eval] this != end ==> |result| > 0 && result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] this != end
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@0@main end@1@main))))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (not (= this@0@main end@1@main)))
; [eval] |result| > 0 && result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] |result| > 0
; [eval] |result|
(push) ; 4
(push) ; 5
(assert (not (> (Seq_length result@2@main) 0)))
(pop) ; 5
(push) ; 5
(assert (> (Seq_length result@2@main) 0))
; [eval] result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] result[0]
(push) ; 6
(assert (not (< 0 (Seq_length result@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this, end), write) in this.data)
(push) ; 6
(assert (lseg%trigger s@$ this@0@main end@1@main))
; [eval] this != end
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@0@main $Ref.null)))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 8
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
; [eval] this != end
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(check-sat)
; unknown
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))))
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@13@main ($Snap $Ref $Ref) Bool)
(assert (recunf@13@main s@$ this@0@main end@1@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 10
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
; [eval] this.data <= this.next.data
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 10
(push) ; 11
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(pop) ; 8
(declare-fun joined_unfolding@14@main ($Snap $Ref $Ref) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@13@main s@$ this@0@main end@1@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(assert (joined_unfolding@14@main s@$ this@0@main end@1@main))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (lseg%trigger s@$ this@0@main end@1@main))
(assert (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))))
(assert (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)))
(assert (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@13@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@14@main s@$ this@0@main end@1@main))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (> (Seq_length result@2@main) 0) (and (> (Seq_length result@2@main) 0) (lseg%trigger s@$ this@0@main end@1@main) (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))) (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)) (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@13@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@14@main s@$ this@0@main end@1@main))))))
(assert (or (> (Seq_length result@2@main) 0) (not (> (Seq_length result@2@main) 0))))
(pop) ; 3
(push) ; 3
(assert (= this@0@main end@1@main))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=> (not (= this@0@main end@1@main)) (and (not (= this@0@main end@1@main)) (=> (> (Seq_length result@2@main) 0) (and (> (Seq_length result@2@main) 0) (lseg%trigger s@$ this@0@main end@1@main) (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))) (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)) (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@14@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@13@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@14@main s@$ this@0@main end@1@main))))) (or (> (Seq_length result@2@main) 0) (not (> (Seq_length result@2@main) 0))))))
; Joined path conditions
(assert (or (= this@0@main end@1@main) (not (= this@0@main end@1@main))))
(assert (=> (not (= this@0@main end@1@main)) (and (> (Seq_length result@2@main) 0) (= (Seq_index result@2@main 0) ($SortWrappers.$SnapToInt ($Snap.first s@$))))))
(assert (= ($Snap.second ($Snap.second snapshot@12@main)) $Snap.unit))
; [eval] (forall i: Int, j: Int :: { result[i], result[j] } 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j])
(declare-const i@15@main Int)
(declare-const j@16@main Int)
(push) ; 2
; [eval] 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j]
; [eval] 0 <= i && (i < j && j < |result|)
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@15@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@15@main))
; [eval] i < j
(push) ; 5
(push) ; 6
(assert (not (< i@15@main j@16@main)))
(pop) ; 6
(push) ; 6
(assert (< i@15@main j@16@main))
; [eval] j < |result|
; [eval] |result|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (< i@15@main j@16@main) (not (< i@15@main j@16@main))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (<= 0 i@15@main) (and (<= 0 i@15@main) (or (< i@15@main j@16@main) (not (< i@15@main j@16@main))))))
(assert (or (<= 0 i@15@main) (not (<= 0 i@15@main))))
(push) ; 3
(push) ; 4
(assert (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))))
; [eval] result[i] <= result[j]
; [eval] result[i]
(push) ; 5
(assert (not (>= i@15@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< i@15@main (Seq_length result@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; [eval] result[j]
(push) ; 5
(assert (not (>= j@16@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))) (and (<= 0 i@15@main) (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))))
; Joined path conditions
(assert (or (not (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main))))) (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main))))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@15@main Int) (j@16@main Int)) (! (and (=> (<= 0 i@15@main) (and (<= 0 i@15@main) (or (< i@15@main j@16@main) (not (< i@15@main j@16@main))))) (or (<= 0 i@15@main) (not (<= 0 i@15@main))) (=> (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))) (and (<= 0 i@15@main) (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))) (or (not (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main))))) (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))))) :pattern ((Seq_index result@2@main i@15@main) (Seq_index result@2@main j@16@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@25@12@25@95-aux|)))
(assert (forall ((i@15@main Int) (j@16@main Int)) (! (=> (and (<= 0 i@15@main) (and (< i@15@main j@16@main) (< j@16@main (Seq_length result@2@main)))) (<= (Seq_index result@2@main i@15@main) (Seq_index result@2@main j@16@main))) :pattern ((Seq_index result@2@main i@15@main) (Seq_index result@2@main j@16@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@25@12@25@95|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (= (contentNodes%limited s@$ this@0@main end@1@main) (contentNodes s@$ this@0@main end@1@main)) :pattern ((contentNodes s@$ this@0@main end@1@main)) :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (contentNodes%stateless this@0@main end@1@main) :pattern ((contentNodes%limited s@$ this@0@main end@1@main)) :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (let ((result@2@main (contentNodes%limited s@$ this@0@main end@1@main))) (=> (contentNodes%precondition s@$ this@0@main end@1@main) (and (=> (= this@0@main end@1@main) (Seq_equal result@2@main (as Seq_empty Seq<Int>))) (=> (not (= this@0@main end@1@main)) (and (> (Seq_length result@2@main) 0) (= (Seq_index result@2@main 0) ($SortWrappers.$SnapToInt ($Snap.first s@$))))) (forall ((i Int) (j Int)) (! (=> (and (<= 0 i) (and (< i j) (< j (Seq_length result@2@main)))) (<= (Seq_index result@2@main i) (Seq_index result@2@main j))) :pattern ((Seq_index result@2@main i) (Seq_index result@2@main j))))))) :pattern ((contentNodes%limited s@$ this@0@main end@1@main)) :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (let ((result@2@main (contentNodes%limited s@$ this@0@main end@1@main))) true) :pattern ((contentNodes%limited s@$ this@0@main end@1@main)) :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (let ((result@2@main (contentNodes%limited s@$ this@0@main end@1@main))) true) :pattern ((contentNodes%limited s@$ this@0@main end@1@main)) :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (let ((result@2@main (contentNodes%limited s@$ this@0@main end@1@main))) true) :pattern ((contentNodes%limited s@$ this@0@main end@1@main)) :qid |quant-u-13|)))
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (this == end ? Seq[Int]() : (unfolding acc(lseg(this, end), write) in Seq(this.data) ++ contentNodes(this.next, end)))
; [eval] this == end
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@0@main end@1@main))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (= this@0@main end@1@main))
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
(assert (not (= this@0@main end@1@main)))
; [eval] (unfolding acc(lseg(this, end), write) in Seq(this.data) ++ contentNodes(this.next, end))
(push) ; 4
(assert (lseg%trigger s@$ this@0@main end@1@main))
; [eval] this != end
(push) ; 5
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@0@main $Ref.null)))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 6
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
; [eval] this != end
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))))
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@17@main ($Snap $Ref $Ref) Bool)
(assert (recunf@17@main s@$ this@0@main end@1@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
; [eval] this.data <= this.next.data
(pop) ; 9
(pop) ; 8
; Joined path conditions
(pop) ; 7
(push) ; 7
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 8
(push) ; 9
(pop) ; 9
(pop) ; 8
; Joined path conditions
(pop) ; 7
(pop) ; 6
(declare-fun joined_unfolding@18@main ($Snap $Ref $Ref) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@17@main s@$ this@0@main end@1@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(assert (joined_unfolding@18@main s@$ this@0@main end@1@main))
; [eval] Seq(this.data) ++ contentNodes(this.next, end)
; [eval] Seq(this.data)
(assert (= (Seq_length (Seq_singleton ($SortWrappers.$SnapToInt ($Snap.first s@$)))) 1))
; [eval] contentNodes(this.next, end)
(push) ; 6
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(pop) ; 6
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (lseg%trigger s@$ this@0@main end@1@main))
(assert (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))))
(assert (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)))
(assert (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@17@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@18@main s@$ this@0@main end@1@main))))
(assert (=> (not (= this@0@main end@1@main)) (= (Seq_length (Seq_singleton ($SortWrappers.$SnapToInt ($Snap.first s@$)))) 1)))
(assert (=> (not (= this@0@main end@1@main)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=> (not (= this@0@main end@1@main)) (and (not (= this@0@main end@1@main)) (lseg%trigger s@$ this@0@main end@1@main) (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))) (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)) (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@18@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@17@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@18@main s@$ this@0@main end@1@main))) (=> (not (= this@0@main end@1@main)) (= (Seq_length (Seq_singleton ($SortWrappers.$SnapToInt ($Snap.first s@$)))) 1)) (=> (not (= this@0@main end@1@main)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))))
(assert (or (not (= this@0@main end@1@main)) (= this@0@main end@1@main)))
(assert (= result@2@main (ite (= this@0@main end@1@main) (as Seq_empty Seq<Int>) (Seq_append (Seq_singleton ($SortWrappers.$SnapToInt ($Snap.first s@$))) (contentNodes ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))))
; [eval] this == end ==> result == Seq[Int]()
; [eval] this == end
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@0@main end@1@main))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (= this@0@main end@1@main))
; [eval] result == Seq[Int]()
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
(assert (not (= this@0@main end@1@main)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (= this@0@main end@1@main) (Seq_equal result@2@main (as Seq_empty Seq<Int>)))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(assert (=> (= this@0@main end@1@main) (Seq_equal result@2@main (as Seq_empty Seq<Int>))))
; [eval] this != end ==> |result| > 0 && result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] this != end
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@0@main end@1@main))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (not (= this@0@main end@1@main)))
; [eval] |result| > 0 && result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] |result| > 0
; [eval] |result|
(push) ; 4
(push) ; 5
(assert (not (> (Seq_length result@2@main) 0)))
(pop) ; 5
(push) ; 5
(assert (> (Seq_length result@2@main) 0))
; [eval] result[0] == (unfolding acc(lseg(this, end), write) in this.data)
; [eval] result[0]
(push) ; 6
(assert (not (< 0 (Seq_length result@2@main))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this, end), write) in this.data)
(push) ; 6
(assert (lseg%trigger s@$ this@0@main end@1@main))
; [eval] this != end
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= this@0@main end@1@main)))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@0@main $Ref.null)))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 8
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
; [eval] this != end
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))))
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= this@0@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@19@main ($Snap $Ref $Ref) Bool)
(assert (recunf@19@main s@$ this@0@main end@1@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 10
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
; [eval] this.data <= this.next.data
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 10
(push) ; 11
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(pop) ; 8
(declare-fun joined_unfolding@20@main ($Snap $Ref $Ref) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@19@main s@$ this@0@main end@1@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))
(assert (joined_unfolding@20@main s@$ this@0@main end@1@main))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (lseg%trigger s@$ this@0@main end@1@main))
(assert (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))))
(assert (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)))
(assert (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@19@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@20@main s@$ this@0@main end@1@main))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (> (Seq_length result@2@main) 0) (and (> (Seq_length result@2@main) 0) (lseg%trigger s@$ this@0@main end@1@main) (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))) (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)) (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@19@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@20@main s@$ this@0@main end@1@main))))))
(assert (or (> (Seq_length result@2@main) 0) (not (> (Seq_length result@2@main) 0))))
(pop) ; 3
(push) ; 3
(assert (= this@0@main end@1@main))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=> (not (= this@0@main end@1@main)) (and (not (= this@0@main end@1@main)) (=> (> (Seq_length result@2@main) 0) (and (> (Seq_length result@2@main) 0) (lseg%trigger s@$ this@0@main end@1@main) (=> (not (= this@0@main end@1@main)) (and (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))) (=> (not (= this@0@main end@1@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)) (=> (not (= this@0@main end@1@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= (joined_unfolding@20@main s@$ this@0@main end@1@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@19@main s@$ this@0@main end@1@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) (joined_unfolding@20@main s@$ this@0@main end@1@main))))) (or (> (Seq_length result@2@main) 0) (not (> (Seq_length result@2@main) 0))))))
; Joined path conditions
(assert (or (= this@0@main end@1@main) (not (= this@0@main end@1@main))))
(push) ; 2
(assert (not (=> (not (= this@0@main end@1@main)) (and (> (Seq_length result@2@main) 0) (= (Seq_index result@2@main 0) ($SortWrappers.$SnapToInt ($Snap.first s@$)))))))
(check-sat)
; unsat
(pop) ; 2
; 2ms
; (get-info :all-statistics)
(assert (=> (not (= this@0@main end@1@main)) (and (> (Seq_length result@2@main) 0) (= (Seq_index result@2@main 0) ($SortWrappers.$SnapToInt ($Snap.first s@$))))))
; [eval] (forall i: Int, j: Int :: { result[i], result[j] } 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j])
(declare-const i@21@main Int)
(declare-const j@22@main Int)
(push) ; 2
; [eval] 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j]
; [eval] 0 <= i && (i < j && j < |result|)
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@21@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@21@main))
; [eval] i < j
(push) ; 5
(push) ; 6
(assert (not (< i@21@main j@22@main)))
(pop) ; 6
(push) ; 6
(assert (< i@21@main j@22@main))
; [eval] j < |result|
; [eval] |result|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (< i@21@main j@22@main) (not (< i@21@main j@22@main))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (<= 0 i@21@main) (and (<= 0 i@21@main) (or (< i@21@main j@22@main) (not (< i@21@main j@22@main))))))
(assert (or (<= 0 i@21@main) (not (<= 0 i@21@main))))
(push) ; 3
(push) ; 4
(assert (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))))
; [eval] result[i] <= result[j]
; [eval] result[i]
(push) ; 5
(assert (not (>= i@21@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< i@21@main (Seq_length result@2@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; [eval] result[j]
(push) ; 5
(assert (not (>= j@22@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))) (and (<= 0 i@21@main) (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))))
; Joined path conditions
(assert (or (not (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main))))) (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main))))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@21@main Int) (j@22@main Int)) (! (and (=> (<= 0 i@21@main) (and (<= 0 i@21@main) (or (< i@21@main j@22@main) (not (< i@21@main j@22@main))))) (or (<= 0 i@21@main) (not (<= 0 i@21@main))) (=> (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))) (and (<= 0 i@21@main) (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))) (or (not (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main))))) (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))))) :pattern ((Seq_index result@2@main i@21@main) (Seq_index result@2@main j@22@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@25@12@25@95-aux|)))
(push) ; 2
(assert (not (forall ((i@21@main Int) (j@22@main Int)) (! (=> (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))) (<= (Seq_index result@2@main i@21@main) (Seq_index result@2@main j@22@main))) :pattern ((Seq_index result@2@main i@21@main) (Seq_index result@2@main j@22@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@25@12@25@95|))))
(check-sat)
; unsat
(pop) ; 2
; 6ms
; (get-info :all-statistics)
(assert (forall ((i@21@main Int) (j@22@main Int)) (! (=> (and (<= 0 i@21@main) (and (< i@21@main j@22@main) (< j@22@main (Seq_length result@2@main)))) (<= (Seq_index result@2@main i@21@main) (Seq_index result@2@main j@22@main))) :pattern ((Seq_index result@2@main i@21@main) (Seq_index result@2@main j@22@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@25@12@25@95|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (=> (contentNodes%precondition s@$ this@0@main end@1@main) (= (contentNodes s@$ this@0@main end@1@main) (ite (= this@0@main end@1@main) (as Seq_empty Seq<Int>) (Seq_append (Seq_singleton ($SortWrappers.$SnapToInt ($Snap.first s@$))) (contentNodes%limited ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))))) :pattern ((contentNodes s@$ this@0@main end@1@main)) :pattern ((contentNodes%stateless this@0@main end@1@main) (lseg%trigger s@$ this@0@main end@1@main)) :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref) (end@1@main $Ref)) (! (=> (contentNodes%precondition s@$ this@0@main end@1@main) (ite (= this@0@main end@1@main) true (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@1@main))) :pattern ((contentNodes s@$ this@0@main end@1@main)) :qid |quant-u-15|)))
(declare-fun this@3@main () $Ref)
(declare-fun end@4@main () $Ref)
(declare-fun result@5@main () Int)
(push) ; 1
(declare-const snapshot@23@main $Snap)
(assert (= snapshot@23@main $Snap.unit))
; [eval] result == |contentNodes(this, end)|
; [eval] |contentNodes(this, end)|
; [eval] contentNodes(this, end)
(push) ; 2
(assert (contentNodes%precondition s@$ this@3@main end@4@main))
(pop) ; 2
; Joined path conditions
(assert (contentNodes%precondition s@$ this@3@main end@4@main))
(assert (= result@5@main (Seq_length (contentNodes s@$ this@3@main end@4@main))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (= (lengthNodes%limited s@$ this@3@main end@4@main) (lengthNodes s@$ this@3@main end@4@main)) :pattern ((lengthNodes s@$ this@3@main end@4@main)) :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (lengthNodes%stateless this@3@main end@4@main) :pattern ((lengthNodes%limited s@$ this@3@main end@4@main)) :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (let ((result@5@main (lengthNodes%limited s@$ this@3@main end@4@main))) (=> (lengthNodes%precondition s@$ this@3@main end@4@main) (= result@5@main (Seq_length (contentNodes s@$ this@3@main end@4@main))))) :pattern ((lengthNodes%limited s@$ this@3@main end@4@main)) :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (let ((result@5@main (lengthNodes%limited s@$ this@3@main end@4@main))) (=> (lengthNodes%precondition s@$ this@3@main end@4@main) (contentNodes%precondition s@$ this@3@main end@4@main))) :pattern ((lengthNodes%limited s@$ this@3@main end@4@main)) :qid |quant-u-17|)))
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(lseg(this, end), write) in (this == end ? 0 : 1 + lengthNodes(this.next, end)))
(set-option :rlimit 0)
(push) ; 2
(assert (lseg%trigger s@$ this@3@main end@4@main))
; [eval] this != end
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= this@3@main end@4@main)))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= this@3@main end@4@main))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (not (= this@3@main end@4@main)))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@3@main $Ref.null)))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))
(push) ; 4
(set-option :rlimit 100000)
(assert (not (= this@3@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 4
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))
; [eval] this != end
(push) ; 5
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= this@3@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))))
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= this@3@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= this@3@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@24@main ($Snap $Ref $Ref) Bool)
(assert (recunf@24@main s@$ this@3@main end@4@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 6
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
; [eval] this.data <= this.next.data
(pop) ; 7
(pop) ; 6
; Joined path conditions
(pop) ; 5
(push) ; 5
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 6
(push) ; 7
(pop) ; 7
(pop) ; 6
; Joined path conditions
(pop) ; 5
(pop) ; 4
(declare-fun joined_unfolding@25@main ($Snap $Ref $Ref) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (= (joined_unfolding@25@main s@$ this@3@main end@4@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (= (joined_unfolding@25@main s@$ this@3@main end@4@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@24@main s@$ this@3@main end@4@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))))
(assert (joined_unfolding@25@main s@$ this@3@main end@4@main))
; [eval] (this == end ? 0 : 1 + lengthNodes(this.next, end))
; [eval] this == end
(push) ; 4
(push) ; 5
; [eval] 1 + lengthNodes(this.next, end)
; [eval] lengthNodes(this.next, end)
(push) ; 6
(assert (lengthNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))
(pop) ; 6
; Joined path conditions
(assert (lengthNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (not (= this@3@main end@4@main)) (lengthNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))
(pop) ; 3
(push) ; 3
(assert (= this@3@main end@4@main))
(assert (= s@$ $Snap.unit))
; [eval] (this == end ? 0 : 1 + lengthNodes(this.next, end))
; [eval] this == end
(push) ; 4
(push) ; 5
(set-option :rlimit 100000)
(assert (not (not (= this@3@main end@4@main))))
(check-sat)
; unknown
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(pop) ; 5
(pop) ; 4
; Joined path conditions
(pop) ; 3
(pop) ; 2
(declare-fun joined_unfolding@26@main ($Snap $Ref $Ref) Int)
(assert (=> (not (= this@3@main end@4@main)) (= (joined_unfolding@26@main s@$ this@3@main end@4@main) (+ 1 (lengthNodes ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))))
(assert (=> (= this@3@main end@4@main) (= (joined_unfolding@26@main s@$ this@3@main end@4@main) 0)))
; Joined path conditions
(assert (lseg%trigger s@$ this@3@main end@4@main))
(assert (=> (not (= this@3@main end@4@main)) (and (not (= this@3@main end@4@main)) (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@3@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))))
(assert (=> (not (= this@3@main end@4@main)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit)))
(assert (=> (not (= this@3@main end@4@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (= (joined_unfolding@25@main s@$ this@3@main end@4@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first s@$)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (= (joined_unfolding@25@main s@$ this@3@main end@4@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (= ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second s@$)))))) $Snap.unit) (recunf@24@main s@$ this@3@main end@4@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))) (joined_unfolding@25@main s@$ this@3@main end@4@main) (=> (not (= this@3@main end@4@main)) (lengthNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main)))))
; Joined path conditions
(assert (=> (= this@3@main end@4@main) (and (= this@3@main end@4@main) (= s@$ $Snap.unit))))
(assert (or (= this@3@main end@4@main) (not (= this@3@main end@4@main))))
(assert (= result@5@main (joined_unfolding@26@main s@$ this@3@main end@4@main)))
; [eval] result == |contentNodes(this, end)|
; [eval] |contentNodes(this, end)|
; [eval] contentNodes(this, end)
(push) ; 2
(assert (contentNodes%precondition s@$ this@3@main end@4@main))
(pop) ; 2
; Joined path conditions
(assert (contentNodes%precondition s@$ this@3@main end@4@main))
(push) ; 2
(assert (not (= result@5@main (Seq_length (contentNodes s@$ this@3@main end@4@main)))))
(check-sat)
; unsat
(pop) ; 2
; 2ms
; (get-info :all-statistics)
(assert (= result@5@main (Seq_length (contentNodes s@$ this@3@main end@4@main))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (=> (lengthNodes%precondition s@$ this@3@main end@4@main) (= (lengthNodes s@$ this@3@main end@4@main) (ite (= this@3@main end@4@main) 0 (+ 1 (lengthNodes%limited ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))))) :pattern ((lengthNodes s@$ this@3@main end@4@main)) :pattern ((lengthNodes%stateless this@3@main end@4@main) (lseg%trigger s@$ this@3@main end@4@main)) :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (this@3@main $Ref) (end@4@main $Ref)) (! (=> (lengthNodes%precondition s@$ this@3@main end@4@main) (ite (= this@3@main end@4@main) true (lengthNodes%precondition ($Snap.first ($Snap.second ($Snap.second s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second s@$))) end@4@main))) :pattern ((lengthNodes s@$ this@3@main end@4@main)) :qid |quant-u-19|)))
(declare-fun this@6@main () $Ref)
(declare-fun result@7@main () Seq<Int>)
(push) ; 1
(declare-const snapshot@27@main $Snap)
(assert (= snapshot@27@main $Snap.unit))
; [eval] (forall i: Int, j: Int :: { result[i], result[j] } 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j])
(declare-const i@28@main Int)
(declare-const j@29@main Int)
(push) ; 2
; [eval] 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j]
; [eval] 0 <= i && (i < j && j < |result|)
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@28@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@28@main))
; [eval] i < j
(push) ; 5
(push) ; 6
(assert (not (< i@28@main j@29@main)))
(pop) ; 6
(push) ; 6
(assert (< i@28@main j@29@main))
; [eval] j < |result|
; [eval] |result|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (< i@28@main j@29@main) (not (< i@28@main j@29@main))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (<= 0 i@28@main) (and (<= 0 i@28@main) (or (< i@28@main j@29@main) (not (< i@28@main j@29@main))))))
(assert (or (<= 0 i@28@main) (not (<= 0 i@28@main))))
(push) ; 3
(push) ; 4
(assert (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))))
; [eval] result[i] <= result[j]
; [eval] result[i]
(push) ; 5
(assert (not (>= i@28@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< i@28@main (Seq_length result@7@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; [eval] result[j]
(push) ; 5
(assert (not (>= j@29@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))) (and (<= 0 i@28@main) (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))))
; Joined path conditions
(assert (or (not (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main))))) (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main))))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@28@main Int) (j@29@main Int)) (! (and (=> (<= 0 i@28@main) (and (<= 0 i@28@main) (or (< i@28@main j@29@main) (not (< i@28@main j@29@main))))) (or (<= 0 i@28@main) (not (<= 0 i@28@main))) (=> (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))) (and (<= 0 i@28@main) (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))) (or (not (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main))))) (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))))) :pattern ((Seq_index result@7@main i@28@main) (Seq_index result@7@main j@29@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@56@12@56@95-aux|)))
(assert (forall ((i@28@main Int) (j@29@main Int)) (! (=> (and (<= 0 i@28@main) (and (< i@28@main j@29@main) (< j@29@main (Seq_length result@7@main)))) (<= (Seq_index result@7@main i@28@main) (Seq_index result@7@main j@29@main))) :pattern ((Seq_index result@7@main i@28@main) (Seq_index result@7@main j@29@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@56@12@56@95|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (= (content%limited s@$ this@6@main) (content s@$ this@6@main)) :pattern ((content s@$ this@6@main)) :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (content%stateless this@6@main) :pattern ((content%limited s@$ this@6@main)) :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (let ((result@7@main (content%limited s@$ this@6@main))) (=> (content%precondition s@$ this@6@main) (forall ((i Int) (j Int)) (! (=> (and (<= 0 i) (and (< i j) (< j (Seq_length result@7@main)))) (<= (Seq_index result@7@main i) (Seq_index result@7@main j))) :pattern ((Seq_index result@7@main i) (Seq_index result@7@main j)))))) :pattern ((content%limited s@$ this@6@main)) :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (let ((result@7@main (content%limited s@$ this@6@main))) true) :pattern ((content%limited s@$ this@6@main)) :qid |quant-u-21|)))
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(List(this), write) in contentNodes(this.head, null))
(set-option :rlimit 0)
(push) ; 2
(assert (List%trigger s@$ this@6@main))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@6@main $Ref.null)))
; [eval] contentNodes(this.head, null)
(push) ; 3
(assert (contentNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(pop) ; 3
; Joined path conditions
(assert (contentNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(pop) ; 2
; Joined path conditions
(assert (and (List%trigger s@$ this@6@main) (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@6@main $Ref.null))))
(assert (contentNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(assert (= result@7@main (contentNodes ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null)))
; [eval] (forall i: Int, j: Int :: { result[i], result[j] } 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j])
(declare-const i@30@main Int)
(declare-const j@31@main Int)
(push) ; 2
; [eval] 0 <= i && (i < j && j < |result|) ==> result[i] <= result[j]
; [eval] 0 <= i && (i < j && j < |result|)
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@30@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@30@main))
; [eval] i < j
(push) ; 5
(push) ; 6
(assert (not (< i@30@main j@31@main)))
(pop) ; 6
(push) ; 6
(assert (< i@30@main j@31@main))
; [eval] j < |result|
; [eval] |result|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (< i@30@main j@31@main) (not (< i@30@main j@31@main))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (<= 0 i@30@main) (and (<= 0 i@30@main) (or (< i@30@main j@31@main) (not (< i@30@main j@31@main))))))
(assert (or (<= 0 i@30@main) (not (<= 0 i@30@main))))
(push) ; 3
(push) ; 4
(assert (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))))
; [eval] result[i] <= result[j]
; [eval] result[i]
(push) ; 5
(assert (not (>= i@30@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< i@30@main (Seq_length result@7@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; [eval] result[j]
(push) ; 5
(assert (not (>= j@31@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))) (and (<= 0 i@30@main) (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))))
; Joined path conditions
(assert (or (not (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main))))) (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main))))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@30@main Int) (j@31@main Int)) (! (and (=> (<= 0 i@30@main) (and (<= 0 i@30@main) (or (< i@30@main j@31@main) (not (< i@30@main j@31@main))))) (or (<= 0 i@30@main) (not (<= 0 i@30@main))) (=> (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))) (and (<= 0 i@30@main) (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))) (or (not (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main))))) (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))))) :pattern ((Seq_index result@7@main i@30@main) (Seq_index result@7@main j@31@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@56@12@56@95-aux|)))
(push) ; 2
(assert (not (forall ((i@30@main Int) (j@31@main Int)) (! (=> (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))) (<= (Seq_index result@7@main i@30@main) (Seq_index result@7@main j@31@main))) :pattern ((Seq_index result@7@main i@30@main) (Seq_index result@7@main j@31@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@56@12@56@95|))))
(check-sat)
; unsat
(pop) ; 2
; 1ms
; (get-info :all-statistics)
(assert (forall ((i@30@main Int) (j@31@main Int)) (! (=> (and (<= 0 i@30@main) (and (< i@30@main j@31@main) (< j@31@main (Seq_length result@7@main)))) (<= (Seq_index result@7@main i@30@main) (Seq_index result@7@main j@31@main))) :pattern ((Seq_index result@7@main i@30@main) (Seq_index result@7@main j@31@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/examples/vmcai2016/linked-list-predicates-with-wands.vpr@56@12@56@95|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (=> (content%precondition s@$ this@6@main) (= (content s@$ this@6@main) (contentNodes ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))) :pattern ((content s@$ this@6@main)) :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (this@6@main $Ref)) (! (=> (content%precondition s@$ this@6@main) (contentNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null)) :pattern ((content s@$ this@6@main)) :qid |quant-u-23|)))
(declare-fun this@8@main () $Ref)
(declare-fun result@9@main () Int)
(push) ; 1
(declare-const snapshot@32@main $Snap)
(assert (= snapshot@32@main $Snap.unit))
; [eval] result == |content(this)|
; [eval] |content(this)|
; [eval] content(this)
(push) ; 2
(assert (content%precondition s@$ this@8@main))
(pop) ; 2
; Joined path conditions
(assert (content%precondition s@$ this@8@main))
(assert (= result@9@main (Seq_length (content s@$ this@8@main))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (= (length%limited s@$ this@8@main) (length s@$ this@8@main)) :pattern ((length s@$ this@8@main)) :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (length%stateless this@8@main) :pattern ((length%limited s@$ this@8@main)) :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (let ((result@9@main (length%limited s@$ this@8@main))) (=> (length%precondition s@$ this@8@main) (= result@9@main (Seq_length (content s@$ this@8@main))))) :pattern ((length%limited s@$ this@8@main)) :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (let ((result@9@main (length%limited s@$ this@8@main))) (=> (length%precondition s@$ this@8@main) (content%precondition s@$ this@8@main))) :pattern ((length%limited s@$ this@8@main)) :qid |quant-u-25|)))
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(List(this), write) in lengthNodes(this.head, null))
(set-option :rlimit 0)
(push) ; 2
(assert (List%trigger s@$ this@8@main))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@8@main $Ref.null)))
; [eval] lengthNodes(this.head, null)
(push) ; 3
(assert (lengthNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(pop) ; 3
; Joined path conditions
(assert (lengthNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(pop) ; 2
; Joined path conditions
(assert (and (List%trigger s@$ this@8@main) (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@8@main $Ref.null))))
(assert (lengthNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))
(assert (= result@9@main (lengthNodes ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null)))
; [eval] result == |content(this)|
; [eval] |content(this)|
; [eval] content(this)
(push) ; 2
(assert (content%precondition s@$ this@8@main))
(pop) ; 2
; Joined path conditions
(assert (content%precondition s@$ this@8@main))
(push) ; 2
(assert (not (= result@9@main (Seq_length (content s@$ this@8@main)))))
(check-sat)
; unsat
(pop) ; 2
; 1ms
; (get-info :all-statistics)
(assert (= result@9@main (Seq_length (content s@$ this@8@main))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (=> (length%precondition s@$ this@8@main) (= (length s@$ this@8@main) (lengthNodes ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null))) :pattern ((length s@$ this@8@main)) :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (this@8@main $Ref)) (! (=> (length%precondition s@$ this@8@main) (lengthNodes%precondition ($Snap.second s@$) ($SortWrappers.$SnapTo$Ref ($Snap.first s@$)) $Ref.null)) :pattern ((length s@$ this@8@main)) :qid |quant-u-27|)))
(declare-fun this@10@main () $Ref)
(declare-fun result@11@main () Int)
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] 0 < length(this)
; [eval] length(this)
(push) ; 2
(assert (length%precondition ($Snap.first s@$) this@10@main))
(pop) ; 2
; Joined path conditions
(assert (length%precondition ($Snap.first s@$) this@10@main))
(assert (< 0 (length ($Snap.first s@$) this@10@main)))
(declare-const snapshot@33@main $Snap)
(assert (= snapshot@33@main $Snap.unit))
; [eval] result == content(this)[0]
; [eval] content(this)[0]
; [eval] content(this)
(push) ; 2
(assert (content%precondition ($Snap.first s@$) this@10@main))
(pop) ; 2
; Joined path conditions
(assert (content%precondition ($Snap.first s@$) this@10@main))
(push) ; 2
(assert (not (< 0 (Seq_length (content ($Snap.first s@$) this@10@main)))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(assert (= result@11@main (Seq_index (content ($Snap.first s@$) this@10@main) 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! (= (peek%limited s@$ this@10@main) (peek s@$ this@10@main)) :pattern ((peek s@$ this@10@main)) :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! (peek%stateless this@10@main) :pattern ((peek%limited s@$ this@10@main)) :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! (let ((result@11@main (peek%limited s@$ this@10@main))) (=> (peek%precondition s@$ this@10@main) (= result@11@main (Seq_index (content ($Snap.first s@$) this@10@main) 0)))) :pattern ((peek%limited s@$ this@10@main)) :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! (let ((result@11@main (peek%limited s@$ this@10@main))) (=> (peek%precondition s@$ this@10@main) (content%precondition ($Snap.first s@$) this@10@main))) :pattern ((peek%limited s@$ this@10@main)) :qid |quant-u-29|)))
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (length%precondition ($Snap.first s@$) this@10@main))
(assert (< 0 (length ($Snap.first s@$) this@10@main)))
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(List(this), write) in (unfolding acc(lseg(this.head, null), write) in this.head.data))
(set-option :rlimit 0)
(push) ; 2
(assert (List%trigger ($Snap.first s@$) this@10@main))
(assert (= ($Snap.first s@$) ($Snap.combine ($Snap.first ($Snap.first s@$)) ($Snap.second ($Snap.first s@$)))))
(assert (not (= this@10@main $Ref.null)))
; [eval] (unfolding acc(lseg(this.head, null), write) in this.head.data)
(push) ; 3
(assert (lseg%trigger ($Snap.second ($Snap.first s@$)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null))
; [eval] this != end
(push) ; 4
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 4
; 4ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first s@$))) ($Snap.second ($Snap.second ($Snap.first s@$))))))
(assert (= ($Snap.second ($Snap.second ($Snap.first s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))
(push) ; 5
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))))))
(check-sat)
; unknown
(pop) ; 5
; 4ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 5
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))
; [eval] this != end
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 6
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 6
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))))))
(check-sat)
; unknown
(pop) ; 7
; 9ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))))))
(check-sat)
; unknown
(pop) ; 7
; 6ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))
(check-sat)
; unknown
(pop) ; 7
; 11ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))
(check-sat)
; unknown
(pop) ; 7
; 10ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@34@main ($Snap $Ref) Bool)
(assert (recunf@34@main s@$ this@10@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 7
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 8
; 4ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
; [eval] this.data <= this.next.data
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 7
(push) ; 8
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(pop) ; 5
(declare-fun joined_unfolding@35@main ($Snap $Ref) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= (joined_unfolding@35@main s@$ this@10@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.first s@$)))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= (joined_unfolding@35@main s@$ this@10@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) $Snap.unit) (recunf@34@main s@$ this@10@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))))
(assert (joined_unfolding@35@main s@$ this@10@main))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (lseg%trigger ($Snap.second ($Snap.first s@$)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (= ($Snap.second ($Snap.first s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first s@$))) ($Snap.second ($Snap.second ($Snap.first s@$))))) (= ($Snap.second ($Snap.second ($Snap.first s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= (joined_unfolding@35@main s@$ this@10@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.first s@$)))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= (joined_unfolding@35@main s@$ this@10@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) $Snap.unit) (recunf@34@main s@$ this@10@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))) (joined_unfolding@35@main s@$ this@10@main))))
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)))
(pop) ; 2
; Joined path conditions
(assert (and (List%trigger ($Snap.first s@$) this@10@main) (= ($Snap.first s@$) ($Snap.combine ($Snap.first ($Snap.first s@$)) ($Snap.second ($Snap.first s@$)))) (not (= this@10@main $Ref.null))))
(assert (and (lseg%trigger ($Snap.second ($Snap.first s@$)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (= ($Snap.second ($Snap.first s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first s@$))) ($Snap.second ($Snap.second ($Snap.first s@$))))) (= ($Snap.second ($Snap.second ($Snap.first s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= (joined_unfolding@35@main s@$ this@10@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.first s@$)))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= (joined_unfolding@35@main s@$ this@10@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))) $Snap.unit) (recunf@34@main s@$ this@10@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) $Ref.null))) (joined_unfolding@35@main s@$ this@10@main))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.first s@$))) $Ref.null))))
(assert (= result@11@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.first s@$))))))
; [eval] result == content(this)[0]
; [eval] content(this)[0]
; [eval] content(this)
(push) ; 2
(assert (content%precondition ($Snap.first s@$) this@10@main))
(pop) ; 2
; Joined path conditions
(assert (content%precondition ($Snap.first s@$) this@10@main))
(push) ; 2
(assert (not (< 0 (Seq_length (content ($Snap.first s@$) this@10@main)))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(push) ; 2
(assert (not (= result@11@main (Seq_index (content ($Snap.first s@$) this@10@main) 0))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(assert (= result@11@main (Seq_index (content ($Snap.first s@$) this@10@main) 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! (=> (peek%precondition s@$ this@10@main) (= (peek s@$ this@10@main) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.first s@$)))))) :pattern ((peek s@$ this@10@main)) :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (this@10@main $Ref)) (! true :pattern ((peek s@$ this@10@main)) :qid |quant-u-31|)))
(declare-const predicate@36@main $Snap)
(declare-const this@37@main $Ref)
(declare-const end@38@main $Ref)
(push) ; 1
; [eval] this != end
(push) ; 2
(set-option :rlimit 100000)
(assert (not (= this@37@main end@38@main)))
(check-sat)
; unknown
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 2
(set-option :rlimit 100000)
(assert (not (not (= this@37@main end@38@main))))
(check-sat)
; unknown
(pop) ; 2
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 2
(assert (not (= this@37@main end@38@main)))
(assert (= predicate@36@main ($Snap.combine ($Snap.first predicate@36@main) ($Snap.second predicate@36@main))))
(assert (not (= this@37@main $Ref.null)))
(assert (= ($Snap.second predicate@36@main) ($Snap.combine ($Snap.first ($Snap.second predicate@36@main)) ($Snap.second ($Snap.second predicate@36@main)))))
(assert (= ($Snap.second ($Snap.second predicate@36@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) ($Snap.second ($Snap.second ($Snap.second predicate@36@main))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second predicate@36@main))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(push) ; 3
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main))
; [eval] this != end
(push) ; 4
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)))
(check-sat)
; unknown
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main))))
(check-sat)
; unknown
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))
(push) ; 5
(set-option :rlimit 100000)
(assert (not (= this@37@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))))))
(check-sat)
; unknown
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 100000)
(assert (not (= this@37@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 5
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))
; [eval] this != end
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= this@37@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Ref.null)))
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= this@37@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))
(check-sat)
; unknown
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@39@main Bool)
(assert (as recunf@39@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 7
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)))
(check-sat)
; unknown
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
; [eval] this.data <= this.next.data
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 7
(push) ; 8
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(pop) ; 5
(declare-const joined_unfolding@40@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (= (as joined_unfolding@40@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (= (as joined_unfolding@40@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) $Snap.unit) (as recunf@39@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))))
(assert (as joined_unfolding@40@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 5
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
; [eval] this.data <= this.next.data
(pop) ; 6
(pop) ; 5
; Joined path conditions
(pop) ; 4
(push) ; 4
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main))
(assert (= ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 5
(push) ; 6
(pop) ; 6
(pop) ; 5
; Joined path conditions
(pop) ; 4
(pop) ; 3
(declare-const joined_unfolding@41@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (= (as joined_unfolding@41@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first predicate@36@main)) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main) (= (as joined_unfolding@41@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (= ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (= (as joined_unfolding@40@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (= (as joined_unfolding@40@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Ref.null)) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main))))))))) $Snap.unit) (as recunf@39@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second predicate@36@main)))))) end@38@main))) (as joined_unfolding@40@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main) (= ($Snap.first ($Snap.second ($Snap.second predicate@36@main))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second predicate@36@main))) end@38@main))))
(assert (as joined_unfolding@41@main Bool))
(pop) ; 2
(push) ; 2
(assert (= this@37@main end@38@main))
(assert (= predicate@36@main $Snap.unit))
(pop) ; 2
(pop) ; 1
(declare-const predicate@42@main $Snap)
(declare-const this@43@main $Ref)
(push) ; 1
(assert (= predicate@42@main ($Snap.combine ($Snap.first predicate@42@main) ($Snap.second predicate@42@main))))
(assert (not (= this@43@main $Ref.null)))
(pop) ; 1
(declare-const this@44@main $Ref)
(declare-const this@45@main $Ref)
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const snapshot@46@main $Snap)
(assert (= snapshot@46@main ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.second snapshot@46@main))))
(assert (= ($Snap.second snapshot@46@main) $Snap.unit))
; [eval] content(this) == Seq[Int]()
; [eval] content(this)
(push) ; 3
(assert (content%precondition ($Snap.first snapshot@46@main) this@45@main))
(pop) ; 3
; Joined path conditions
(assert (content%precondition ($Snap.first snapshot@46@main) this@45@main))
; [eval] Seq[Int]()
(assert (Seq_equal (content ($Snap.first snapshot@46@main) this@45@main) (as Seq_empty Seq<Int>)))
(pop) ; 2
(push) ; 2
; [exec]
; this := new(data, next, head, held, changed)
(declare-const this@47@main $Ref)
(assert (not (= this@47@main $Ref.null)))
(declare-const data@48@main Int)
(declare-const next@49@main $Ref)
(declare-const head@50@main $Ref)
(declare-const held@51@main Int)
(declare-const changed@52@main Bool)
(assert (not (= this@47@main this@45@main)))
; [exec]
; this.head := null
; [exec]
; fold acc(lseg(this.head, null), write)
; [eval] this != end
(push) ; 3
(assert (lseg%trigger $Snap.unit $Ref.null $Ref.null))
; [exec]
; fold acc(List(this), write)
(assert (List%trigger ($Snap.combine ($SortWrappers.$RefTo$Snap $Ref.null) $Snap.unit) this@47@main))
; [eval] content(this) == Seq[Int]()
; [eval] content(this)
(push) ; 4
(assert (content%precondition ($Snap.combine ($SortWrappers.$RefTo$Snap $Ref.null) $Snap.unit) this@47@main))
(pop) ; 4
; Joined path conditions
(assert (content%precondition ($Snap.combine ($SortWrappers.$RefTo$Snap $Ref.null) $Snap.unit) this@47@main))
; [eval] Seq[Int]()
(push) ; 4
(assert (not (Seq_equal (content ($Snap.combine ($SortWrappers.$RefTo$Snap $Ref.null) $Snap.unit) this@47@main) (as Seq_empty Seq<Int>))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (Seq_equal (content ($Snap.combine ($SortWrappers.$RefTo$Snap $Ref.null) $Snap.unit) this@47@main) (as Seq_empty Seq<Int>)))
(pop) ; 3
(pop) ; 2
(pop) ; 1
(declare-const this@53@main $Ref)
(declare-const elem@54@main Int)
(declare-const index@55@main Int)
(declare-const this@56@main $Ref)
(declare-const elem@57@main Int)
(declare-const index@58@main Int)
(push) ; 1
(declare-const snapshot@59@main $Snap)
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const snapshot@60@main $Snap)
(assert (= snapshot@60@main ($Snap.combine ($Snap.first snapshot@60@main) ($Snap.second snapshot@60@main))))
(assert (= ($Snap.second snapshot@60@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@60@main)) ($Snap.second ($Snap.second snapshot@60@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@60@main)) $Snap.unit))
; [eval] 0 <= index
(assert (<= 0 index@58@main))
(assert (= ($Snap.second ($Snap.second snapshot@60@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@60@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@60@main))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@60@main))) $Snap.unit))
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 3
(assert (content%precondition snapshot@59@main this@56@main))
(pop) ; 3
; Joined path conditions
(assert (content%precondition snapshot@59@main this@56@main))
(assert (<= index@58@main (Seq_length (content snapshot@59@main this@56@main))))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@60@main))) $Snap.unit))
; [eval] content(this) == old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] content(this)
(push) ; 3
(assert (content%precondition ($Snap.first snapshot@60@main) this@56@main))
(pop) ; 3
; Joined path conditions
(assert (content%precondition ($Snap.first snapshot@60@main) this@56@main))
; [eval] old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] old(content(this))[0..index] ++ Seq(elem)
; [eval] old(content(this))[0..index]
; [eval] old(content(this))[..index]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 3
(pop) ; 3
; Joined path conditions
; [eval] Seq(elem)
(assert (= (Seq_length (Seq_singleton elem@57@main)) 1))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 3
(pop) ; 3
; Joined path conditions
(assert (Seq_equal (content ($Snap.first snapshot@60@main) this@56@main) (Seq_append (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) index@58@main) 0) (Seq_singleton elem@57@main)) (Seq_drop (content snapshot@59@main this@56@main) index@58@main))))
(pop) ; 2
(push) ; 2
; [exec]
; var tmp: Ref
(declare-const tmp@61@main $Ref)
; [exec]
; index := 0
; [exec]
; unfold acc(List(this), write)
(assert (= snapshot@59@main ($Snap.combine ($Snap.first snapshot@59@main) ($Snap.second snapshot@59@main))))
(assert (not (= this@56@main $Ref.null)))
; State saturation: after unfold
(set-option :rlimit 400000)
(check-sat)
; unknown
(assert (List%trigger snapshot@59@main this@56@main))
; [eval] this.head != null
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null))))
(check-sat)
; unknown
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)))
; [exec]
; unfold acc(lseg(this.head, null), write)
; [eval] this != end
(push) ; 4
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(assert (= ($Snap.second snapshot@59@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.second ($Snap.second snapshot@59@main)))))
(assert (= ($Snap.second ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(push) ; 5
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
; [eval] this != end
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 7
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
; [eval] this != end
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@62@main Bool)
(assert (as recunf@62@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 9
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
; [eval] this.data <= this.next.data
(pop) ; 10
(pop) ; 9
; Joined path conditions
(pop) ; 8
(push) ; 8
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 9
(push) ; 10
(pop) ; 10
(pop) ; 9
; Joined path conditions
(pop) ; 8
(pop) ; 7
(declare-const joined_unfolding@63@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@63@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@63@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@62@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(assert (as joined_unfolding@63@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 7
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
; [eval] this.data <= this.next.data
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 7
(push) ; 8
(pop) ; 8
(pop) ; 7
; Joined path conditions
(pop) ; 6
(pop) ; 5
(declare-const joined_unfolding@64@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= (as joined_unfolding@64@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= (as joined_unfolding@64@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@63@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@63@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@62@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))) (as joined_unfolding@63@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(assert (as joined_unfolding@64@main Bool))
; State saturation: after unfold
(set-option :rlimit 400000)
(check-sat)
; unknown
(assert (lseg%trigger ($Snap.second snapshot@59@main) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null))
; [eval] this.head == null || elem <= this.head.data
; [eval] this.head == null
(set-option :rlimit 0)
(push) ; 5
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null))
(pop) ; 6
(push) ; 6
; [eval] elem <= this.head.data
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)) (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)))
(push) ; 5
(set-option :rlimit 100000)
(assert (not (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))))))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 100000)
(assert (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))))))
; [exec]
; tmp := new(data, next, head, held, changed)
(declare-const tmp@65@main $Ref)
(assert (not (= tmp@65@main $Ref.null)))
(declare-const data@66@main Int)
(declare-const next@67@main $Ref)
(declare-const head@68@main $Ref)
(declare-const held@69@main Int)
(declare-const changed@70@main Bool)
(assert (not (= tmp@65@main tmp@61@main)))
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)))))
(assert (not (= tmp@65@main this@56@main)))
; [exec]
; tmp.data := elem
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) tmp@65@main)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
; [exec]
; tmp.next := this.head
(declare-const next@71@main $Ref)
(assert (= next@71@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))))
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) tmp@65@main)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
; [exec]
; fold acc(lseg(this.head, null), write)
; [eval] this != end
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 6
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(push) ; 7
; [eval] this != end
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 9
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
; [eval] this != end
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@72@main Bool)
(assert (as recunf@72@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 11
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
; [eval] this.data <= this.next.data
(pop) ; 12
(pop) ; 11
; Joined path conditions
(pop) ; 10
(push) ; 10
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 11
(push) ; 12
(pop) ; 12
(pop) ; 11
; Joined path conditions
(pop) ; 10
(pop) ; 9
(declare-const joined_unfolding@73@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@73@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@73@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@72@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(assert (as joined_unfolding@73@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 9
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
; [eval] this.data <= this.next.data
(pop) ; 10
(pop) ; 9
; Joined path conditions
(pop) ; 8
(push) ; 8
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 9
(push) ; 10
(pop) ; 10
(pop) ; 9
; Joined path conditions
(pop) ; 8
(pop) ; 7
(declare-const joined_unfolding@74@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= (as joined_unfolding@74@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= (as joined_unfolding@74@main Bool) true)))
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@73@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@73@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@72@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))) (as joined_unfolding@73@main Bool))))
; Joined path conditions
(push) ; 7
(assert (not (as joined_unfolding@74@main Bool)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (as joined_unfolding@74@main Bool))
(assert (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null))
; [exec]
; fold acc(lseg(tmp, null), write)
; [eval] this != end
(push) ; 7
(set-option :rlimit 100000)
(assert (not (= tmp@65@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) next@71@main)))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) next@71@main)))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) next@71@main $Ref.null))
; [eval] this != end
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= next@71@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= next@71@main $Ref.null))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= next@71@main $Ref.null)))
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= tmp@65@main next@71@main)))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= tmp@65@main next@71@main)))
(check-sat)
; unknown
(pop) ; 10
; 1ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 10
; [eval] this != end
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= next@71@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= next@71@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= tmp@65@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@75@main Bool)
(assert (as recunf@75@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 12
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
; [eval] this.data <= this.next.data
(pop) ; 13
(pop) ; 12
; Joined path conditions
(pop) ; 11
(push) ; 11
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 12
(push) ; 13
(pop) ; 13
(pop) ; 12
; Joined path conditions
(pop) ; 11
(pop) ; 10
(declare-const joined_unfolding@76@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= (as joined_unfolding@76@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= (as joined_unfolding@76@main Bool) true)))
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit) (as recunf@75@main Bool))))
; Joined path conditions
(assert (as joined_unfolding@76@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 10
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= next@71@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
; [eval] this.data <= this.next.data
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) next@71@main $Ref.null))
(assert (=> (not (= next@71@main $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= (as joined_unfolding@76@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= (as joined_unfolding@76@main Bool) true)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit) (as recunf@75@main Bool))) (as joined_unfolding@76@main Bool))))
(assert (not (= next@71@main $Ref.null)))
(push) ; 8
(assert (not (=> (not (= next@71@main $Ref.null)) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main)))))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (=> (not (= next@71@main $Ref.null)) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))))))
(assert (lseg%trigger ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit))) tmp@65@main $Ref.null))
; [exec]
; this.head := tmp
(push) ; 8
(set-option :rlimit 100000)
(assert (not (= tmp@65@main this@56@main)))
(check-sat)
; unknown
(pop) ; 8
; 1ms
; (get-info :all-statistics)
; [exec]
; fold acc(List(this), write)
(assert (List%trigger ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@65@main) ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit)))) this@56@main))
; [eval] 0 <= index
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(set-option :rlimit 0)
(push) ; 8
(assert (content%precondition snapshot@59@main this@56@main))
(pop) ; 8
; Joined path conditions
(assert (content%precondition snapshot@59@main this@56@main))
(push) ; 8
(assert (not (<= 0 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (<= 0 (Seq_length (content snapshot@59@main this@56@main))))
; [eval] content(this) == old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] content(this)
(push) ; 8
(assert (content%precondition ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@65@main) ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit)))) this@56@main))
(pop) ; 8
; Joined path conditions
(assert (content%precondition ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@65@main) ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit)))) this@56@main))
; [eval] old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] old(content(this))[0..index] ++ Seq(elem)
; [eval] old(content(this))[0..index]
; [eval] old(content(this))[..index]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] Seq(elem)
(assert (= (Seq_length (Seq_singleton elem@57@main)) 1))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
(push) ; 8
(assert (not (Seq_equal (content ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@65@main) ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit)))) this@56@main) (Seq_append (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) 0) 0) (Seq_singleton elem@57@main)) (Seq_drop (content snapshot@59@main this@56@main) 0)))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(assert (Seq_equal (content ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@65@main) ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@71@main) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@59@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))) $Snap.unit)))) this@56@main) (Seq_append (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) 0) 0) (Seq_singleton elem@57@main)) (Seq_drop (content snapshot@59@main this@56@main) 0))))
(pop) ; 7
(pop) ; 6
(pop) ; 5
(push) ; 5
(assert (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main)))))))
(pop) ; 5
; [eval] !(this.head == null || elem <= this.head.data)
; [eval] this.head == null || elem <= this.head.data
; [eval] this.head == null
(push) ; 5
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null))
(pop) ; 6
(push) ; 6
; [eval] elem <= this.head.data
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(push) ; 5
(set-option :rlimit 100000)
(assert (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 100000)
(assert (not (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))))))))
(check-sat)
; unknown
(pop) ; 5
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(assert (not (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) $Ref.null) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main)))))))
; [exec]
; var hd: Ref
(declare-const hd@77@main $Ref)
; [exec]
; var ptr: Ref
(declare-const ptr@78@main $Ref)
; [exec]
; hd := this.head
(declare-const hd@79@main $Ref)
(assert (= hd@79@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))))
; [exec]
; ptr := hd
; [exec]
; fold acc(lseg(this.head, ptr), write)
; [eval] this != end
(push) ; 6
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) hd@79@main)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) hd@79@main))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))) (= $Ref.null hd@79@main))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(assert (lseg%trigger $Snap.unit ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) hd@79@main))
; [exec]
; index := index + 1
; [eval] index + 1
; [exec]
; package acc(lseg(ptr, null), write) &&
; contentNodes(ptr, null)[0] == old(content(this))[index - 1] --*
; acc(lseg(hd, null), write) &&
; contentNodes(hd, null) ==
; old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null)) {
; }
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (not (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) $Snap.unit))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (not (= $Snap.unit ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))
(check-sat)
; unknown
(pop) ; 7
; 1ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(set-option :rlimit 0)
(push) ; 7
(assert (content%precondition snapshot@59@main this@56@main))
(pop) ; 7
; Joined path conditions
(assert (content%precondition snapshot@59@main this@56@main))
; [eval] index - 1
(push) ; 7
(assert (not (< 0 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 7
; 1ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 7
(pop) ; 7
; Joined path conditions
; [eval] index - 1
(declare-const snap@80@main $Snap)
(declare-const mwsf@81@main $MWSF)
(push) ; 7
(assert (= snap@80@main ($Snap.combine ($Snap.first snap@80@main) ($Snap.second snap@80@main))))
(assert (= ($Snap.second snap@80@main) $Snap.unit))
; [eval] contentNodes(ptr, null)[0] == old(content(this))[index - 1]
; [eval] contentNodes(ptr, null)[0]
; [eval] contentNodes(ptr, null)
(push) ; 8
(assert (contentNodes%precondition ($Snap.first snap@80@main) hd@79@main $Ref.null))
(pop) ; 8
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first snap@80@main) hd@79@main $Ref.null))
(push) ; 8
(assert (not (< 0 (Seq_length (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (< 0 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(assert (= (Seq_index (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) 0)))
(push) ; 8
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 8
; 6ms
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
; [eval] contentNodes(hd, null) == old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(hd, null)
(set-option :rlimit 0)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
; [eval] old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(ptr, null)
(push) ; 8
(pop) ; 8
; Joined path conditions
(push) ; 8
(assert (not (Seq_equal (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) 0) 0) (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(assert (Seq_equal (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) 0) 0) (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null))))
(assert (= (MWSF_apply (as mwsf@81@main $MWSF) snap@80@main) ($Snap.combine ($Snap.first snap@80@main) $Snap.unit)))
(pop) ; 7
(declare-const snap@82@main $Snap)
(assert (forall ((snap@80@main $Snap)) (! (=> (MW_token (as mwsf@81@main $MWSF) snap@80@main) (and (and (= snap@80@main ($Snap.combine ($Snap.first snap@80@main) ($Snap.second snap@80@main))) (= ($Snap.second snap@80@main) $Snap.unit) (contentNodes%precondition ($Snap.first snap@80@main) hd@79@main $Ref.null) (= (Seq_index (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) 0))) (and (Seq_equal (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) 0) 0) (contentNodes ($Snap.first snap@80@main) hd@79@main $Ref.null))) (= (MWSF_apply (as mwsf@81@main $MWSF) snap@80@main) ($Snap.combine ($Snap.first snap@80@main) $Snap.unit))))) :pattern ((MW_token (as mwsf@81@main $MWSF) snap@80@main)) :qid |quant-u-32|)))
(declare-const prev@83@main $Ref)
(declare-const index@84@main Int)
(declare-const ptr@85@main $Ref)
(push) ; 7
(declare-const snapshot@86@main $Snap)
(assert (= snapshot@86@main ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.second snapshot@86@main))))
(assert (not (= ptr@85@main $Ref.null)))
(assert (= ($Snap.second snapshot@86@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.second ($Snap.second snapshot@86@main)))))
(assert (= ($Snap.second ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) $Snap.unit))
; [eval] 1 <= index
(assert (<= 1 index@84@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) $Snap.unit))
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
(assert (<= index@84@main (Seq_length (content snapshot@59@main this@56@main))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] ptr.next == null ==> index == |old(content(this))|
; [eval] ptr.next == null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] index == |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (or (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (= index@84@main (Seq_length (content snapshot@59@main this@56@main)))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) $Snap.unit))
; [eval] ptr.data == old(content(this))[index - 1]
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(push) ; 8
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) (Seq_index (content snapshot@59@main this@56@main) (- index@84@main 1))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) $Snap.unit))
; [eval] ptr.next != null ==> contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] ptr.next != null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] contentNodes(ptr.next, null)
(push) ; 10
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 10
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; Joined path conditions
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) index@84@main))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] ptr.data < elem
(assert (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) elem@57@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))) $Snap.unit))
; [eval] ptr.next != null ==> ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
; [eval] ptr.next != null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 15ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
(push) ; 10
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 11
; 11ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 12
; 8ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 12
; 9ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 12
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 38ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 13
; 8ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 14
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 14
; 31ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 14
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 14
; 35ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@87@main Bool)
(assert (as recunf@87@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 14
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 32ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
; [eval] this.data <= this.next.data
(pop) ; 15
(pop) ; 14
; Joined path conditions
(pop) ; 13
(push) ; 13
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 14
(push) ; 15
(pop) ; 15
(pop) ; 14
; Joined path conditions
(pop) ; 13
(pop) ; 12
(declare-const joined_unfolding@88@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@88@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@88@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@87@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@88@main Bool))
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@88@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@88@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@87@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@88@main Bool))))
(pop) ; 9
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@88@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@88@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@87@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@88@main Bool))))))
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(push) ; 8
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(push) ; 8
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(pop) ; 7
(push) ; 7
; [eval] 1 <= index
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
(push) ; 8
(assert (not (<= 1 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 2ms
; (get-info :all-statistics)
(assert (<= 1 (Seq_length (content snapshot@59@main this@56@main))))
; [eval] ptr.next == null ==> index == |old(content(this))|
; [eval] ptr.next == null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 13ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
; [eval] index == |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (or (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(push) ; 8
(assert (not (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= 1 (Seq_length (content snapshot@59@main this@56@main))))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (= 1 (Seq_length (content snapshot@59@main this@56@main)))))
; [eval] ptr.data == old(content(this))[index - 1]
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (< 0 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(push) ; 8
(assert (not (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) (Seq_index (content snapshot@59@main this@56@main) 0))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) (Seq_index (content snapshot@59@main this@56@main) 0)))
; [eval] ptr.next != null ==> contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] ptr.next != null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
; [eval] contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] contentNodes(ptr.next, null)
(push) ; 10
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(pop) ; 10
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
; Joined path conditions
(push) ; 8
(assert (not (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) 1)))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) 1))))
; [eval] ptr.data < elem
(push) ; 8
(assert (not (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) elem@57@main)))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
(assert (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) elem@57@main))
; [eval] ptr.next != null ==> ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
; [eval] ptr.next != null
(push) ; 8
(push) ; 9
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 9
; 16ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
; [eval] ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
(push) ; 10
; [eval] this != end
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 11
; 17ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 16ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))))))
(check-sat)
; unknown
(pop) ; 12
; 21ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 4ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 12
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
; [eval] this != end
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 14ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 13
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 14
; 12ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 14
; 13ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 14
; 20ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unknown
(pop) ; 14
; 17ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 12ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@89@main Bool)
(assert (as recunf@89@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 14
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 16ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
; [eval] this.data <= this.next.data
(pop) ; 15
(pop) ; 14
; Joined path conditions
(pop) ; 13
(push) ; 13
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 14
(push) ; 15
(pop) ; 15
(pop) ; 14
; Joined path conditions
(pop) ; 13
(pop) ; 12
(declare-const joined_unfolding@90@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@90@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@90@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@89@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))))
(assert (as joined_unfolding@90@main Bool))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) hd@79@main)))
(check-sat)
; unknown
(pop) ; 12
; 15ms
; (get-info :all-statistics)
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@90@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@90@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@89@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))) (as joined_unfolding@90@main Bool))))
(pop) ; 9
(set-option :rlimit 0)
(push) ; 9
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= (as joined_unfolding@90@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= (as joined_unfolding@90@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))) $Snap.unit) (as recunf@89@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))) $Ref.null))) (as joined_unfolding@90@main Bool))))))
; Joined path conditions
(push) ; 8
(assert (not (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main))))))))))
(check-sat)
; unsat
(pop) ; 8
; 1ms
; (get-info :all-statistics)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.second snapshot@59@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@59@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@59@main)))))))))
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (not (< 0 (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 8
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 8
(pop) ; 8
; Joined path conditions
; [eval] index - 1
(push) ; 8
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@88@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@88@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@87@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@88@main Bool))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(assert (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) elem@57@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))) $Snap.unit))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) index@84@main))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
(assert (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) (Seq_index (content snapshot@59@main this@56@main) (- index@84@main 1))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))) $Snap.unit))
(assert (or (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (= index@84@main (Seq_length (content snapshot@59@main this@56@main)))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))) $Snap.unit))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) $Snap.unit))
(assert (<= 1 index@84@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) $Snap.unit))
(assert (<= index@84@main (Seq_length (content snapshot@59@main this@56@main))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
(assert (= snapshot@86@main ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.second snapshot@86@main))))
(assert (not (= ptr@85@main $Ref.null)))
(assert (= ($Snap.second snapshot@86@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.second ($Snap.second snapshot@86@main)))))
(assert (= ($Snap.second ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))
(set-option :rlimit 100000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 9
; [eval] ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
; [eval] ptr.next != null
(push) ; 10
(push) ; 11
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 11
(push) ; 11
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
(push) ; 12
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 9ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 14
; 10ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 14
; 7ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 14
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 27ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 15
; 6ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 27ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 29ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 31ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 29ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@91@main Bool)
(assert (as recunf@91@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 16
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 17
; 31ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
; [eval] this.data <= this.next.data
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(push) ; 15
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 16
(push) ; 17
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(pop) ; 14
(declare-const joined_unfolding@92@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@92@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@92@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@91@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@92@main Bool))
; [eval] ptr.next.data < elem
(pop) ; 13
(pop) ; 12
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@92@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@92@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@91@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@92@main Bool))))
(pop) ; 11
(pop) ; 10
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@92@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@92@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@91@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@92@main Bool))))))
(pop) ; 9
(push) ; 9
; [eval] !(ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem))
; [eval] ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
; [eval] ptr.next != null
(push) ; 10
(push) ; 11
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 11
(push) ; 11
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
(push) ; 12
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 22ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 14
; 24ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 14
; 25ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 14
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 36ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 15
; 11ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 40ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 37ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 52ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 16
; 48ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@93@main Bool)
(assert (as recunf@93@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 16
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 17
; 50ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
; [eval] this.data <= this.next.data
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(push) ; 15
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 16
(push) ; 17
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(pop) ; 14
(declare-const joined_unfolding@94@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@94@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@94@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@93@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@94@main Bool))
; [eval] ptr.next.data < elem
(pop) ; 13
(pop) ; 12
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@94@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@94@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@93@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@94@main Bool))))
(pop) ; 11
(pop) ; 10
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@94@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@94@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@93@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@94@main Bool))))))
(pop) ; 9
; [eval] ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
; [eval] ptr.next != null
(push) ; 9
(push) ; 10
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 10
(push) ; 10
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
(push) ; 11
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 15ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 13
; 13ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 13
; 31ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 13
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 60ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 17ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 69ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 60ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 77ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 74ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@95@main Bool)
(assert (as recunf@95@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 15
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 77ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
; [eval] this.data <= this.next.data
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(push) ; 14
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 15
(push) ; 16
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(pop) ; 13
(declare-const joined_unfolding@96@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@96@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@96@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@95@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@96@main Bool))
; [eval] ptr.next.data < elem
(pop) ; 12
(pop) ; 11
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@96@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@96@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@95@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@96@main Bool))))
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@96@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@96@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@95@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@96@main Bool))))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main)))))
(check-sat)
; unknown
(pop) ; 9
; 34ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main))))
(check-sat)
; unknown
(pop) ; 9
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main)))
; [exec]
; var prev: Ref
(declare-const prev@97@main $Ref)
; [exec]
; assert acc(lseg(ptr, null), write) &&
;   contentNodes(ptr, null)[0] == old(content(this))[index - 1] --*
;   acc(lseg(hd, null), write) &&
;   contentNodes(hd, null) ==
;   old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
; [eval] index - 1
(push) ; 10
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 10
(pop) ; 10
; Joined path conditions
; [eval] index - 1
; [exec]
; prev := ptr
; [exec]
; unfold acc(lseg(ptr.next, null), write)
; [eval] this != end
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 10
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 11
; 10ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 11
; 8ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 11
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 35ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 7ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 13
; 40ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 13
; 31ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 13
; 45ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 13
; 38ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 13
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
; [eval] this != end
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 54ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 47ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 82ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 55ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 45ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 49ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 48ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 15
; 45ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@98@main Bool)
(assert (as recunf@98@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 15
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 41ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
; [eval] this.data <= this.next.data
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(push) ; 14
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 15
(push) ; 16
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(pop) ; 13
(declare-const joined_unfolding@99@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= (as joined_unfolding@99@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= (as joined_unfolding@99@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit) (as recunf@98@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))))
(assert (as joined_unfolding@99@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 13
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 57ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
; [eval] this.data <= this.next.data
(pop) ; 14
(pop) ; 13
; Joined path conditions
(pop) ; 12
(push) ; 12
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 13
(push) ; 14
(pop) ; 14
(pop) ; 13
; Joined path conditions
(pop) ; 12
(pop) ; 11
(declare-const joined_unfolding@100@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@100@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@100@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= (as joined_unfolding@99@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= (as joined_unfolding@99@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit) (as recunf@98@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))) (as joined_unfolding@99@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@100@main Bool))
; State saturation: after unfold
(set-option :rlimit 400000)
(check-sat)
; unknown
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [exec]
; index := index + 1
; [eval] index + 1
(declare-const index@101@main Int)
(assert (= index@101@main (+ index@84@main 1)))
; [exec]
; ptr := ptr.next
(declare-const ptr@102@main $Ref)
(assert (= ptr@102@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main))))
; [exec]
; package acc(lseg(ptr, null), write) &&
; contentNodes(ptr, null)[0] == old(content(this))[index - 1] --*
; acc(lseg(hd, null), write) &&
; contentNodes(hd, null) ==
; old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null)) {
;   fold acc(lseg(prev, null), write)
;   apply acc(lseg(prev, null), write) &&
;     contentNodes(prev, null)[0] == old(content(this))[index - 2] --*
;     acc(lseg(hd, null), write) &&
;     contentNodes(hd, null) ==
;     old(content(this))[0..index - 2] ++ old[lhs](contentNodes(prev, null))
; }
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@85@main)))
(check-sat)
; unknown
(pop) ; 11
; 40ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@85@main)))
(check-sat)
; unknown
(pop) ; 11
; 36ms
; (get-info :all-statistics)
(assert (and (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@85@main))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(check-sat)
; unknown
(pop) ; 11
; 54ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main))))))
(check-sat)
; unknown
(pop) ; 11
; 35ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 11
; 39ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main)))))))
(check-sat)
; unknown
(pop) ; 11
; 35ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(set-option :rlimit 0)
(push) ; 11
(pop) ; 11
; Joined path conditions
; [eval] index - 1
(push) ; 11
(assert (not (>= (- index@101@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (- index@101@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 11
(pop) ; 11
; Joined path conditions
; [eval] index - 1
(declare-const snap@103@main $Snap)
(declare-const mwsf@104@main $MWSF)
(push) ; 11
(assert (= snap@103@main ($Snap.combine ($Snap.first snap@103@main) ($Snap.second snap@103@main))))
(assert (= ($Snap.second snap@103@main) $Snap.unit))
; [eval] contentNodes(ptr, null)[0] == old(content(this))[index - 1]
; [eval] contentNodes(ptr, null)[0]
; [eval] contentNodes(ptr, null)
(push) ; 12
(assert (contentNodes%precondition ($Snap.first snap@103@main) ptr@102@main $Ref.null))
(pop) ; 12
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first snap@103@main) ptr@102@main $Ref.null))
(push) ; 12
(assert (not (< 0 (Seq_length (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 12
; 2ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] index - 1
(push) ; 12
(assert (not (>= (- index@101@main 1) 0)))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(push) ; 12
(assert (not (< (- index@101@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(assert (= (Seq_index (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 1))))
; [exec]
; fold acc(lseg(prev, null), write)
; [eval] this != end
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ptr@85@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 43ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 40ms
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 24ms
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 14ms
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 13
(assert (lseg%trigger ($Snap.first snap@103@main) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 13ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (= ($Snap.first snap@103@main) ($Snap.combine ($Snap.first ($Snap.first snap@103@main)) ($Snap.second ($Snap.first snap@103@main)))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 15
; 12ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first snap@103@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first snap@103@main))) ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 15
; 12ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first snap@103@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 15
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))
; [eval] this != end
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 16
; 18ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))))
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))))))
(check-sat)
; unknown
(pop) ; 17
; 29ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))))))
(check-sat)
; unknown
(pop) ; 17
; 33ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))))
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))))))
(check-sat)
; unknown
(pop) ; 17
; 32ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))))))
(check-sat)
; unknown
(pop) ; 17
; 32ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-fun recunf@105@main ($Snap) Bool)
(assert (recunf@105@main snap@103@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 17
(push) ; 18
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 18
; 27ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 18
; [eval] this.data <= this.next.data
(pop) ; 18
(pop) ; 17
; Joined path conditions
(pop) ; 16
(push) ; 16
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 17
(push) ; 18
(pop) ; 18
(pop) ; 17
; Joined path conditions
(pop) ; 16
(pop) ; 15
(declare-fun joined_unfolding@106@main ($Snap) Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= (joined_unfolding@106@main snap@103@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= (joined_unfolding@106@main snap@103@main) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) $Snap.unit) (recunf@105@main snap@103@main))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))))
(assert (joined_unfolding@106@main snap@103@main))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 15
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
; [eval] this.data <= this.next.data
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(pop) ; 13
; Joined path conditions
(assert (lseg%trigger ($Snap.first snap@103@main) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first snap@103@main) ($Snap.combine ($Snap.first ($Snap.first snap@103@main)) ($Snap.second ($Snap.first snap@103@main)))) (= ($Snap.second ($Snap.first snap@103@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first snap@103@main))) ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) (= ($Snap.second ($Snap.second ($Snap.first snap@103@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= (joined_unfolding@106@main snap@103@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= (joined_unfolding@106@main snap@103@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) $Snap.unit) (recunf@105@main snap@103@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))) (joined_unfolding@106@main snap@103@main))))
(push) ; 13
(assert (not (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main)))))))
(check-sat)
; unsat
(pop) ; 13
; 1ms
; (get-info :all-statistics)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main))))))
(assert (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))
; [exec]
; apply acc(lseg(prev, null), write) &&
;   contentNodes(prev, null)[0] == old(content(this))[index - 2] --*
;   acc(lseg(hd, null), write) &&
;   contentNodes(hd, null) ==
;   old(content(this))[0..index - 2] ++ old[lhs](contentNodes(prev, null))
; [eval] old(content(this))[index - 2]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] index - 2
(push) ; 13
(assert (not (>= (- index@101@main 2) 0)))
(check-sat)
; unsat
(pop) ; 13
; 0ms
; (get-info :all-statistics)
(push) ; 13
(assert (not (< (- index@101@main 2) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 13
; 1ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 2]
; [eval] old(content(this))[..index - 2]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] index - 2
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 34ms
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index (content snapshot@59@main this@56@main) (- index@84@main 1)) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 2))) (Seq_equal (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@84@main 1)) 0) (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 2)) 0)))))
(check-sat)
; unsat
(pop) ; 13
; 27ms
; (get-info :all-statistics)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 17ms
; (get-info :all-statistics)
(check-sat)
; unknown
; [eval] contentNodes(prev, null)[0] == old(content(this))[index - 2]
; [eval] contentNodes(prev, null)[0]
; [eval] contentNodes(prev, null)
(set-option :rlimit 0)
(push) ; 13
(assert (contentNodes%precondition ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))
(pop) ; 13
; Joined path conditions
(assert (contentNodes%precondition ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))
(push) ; 13
(assert (not (< 0 (Seq_length (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 13
; 2ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 2]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] index - 2
(push) ; 13
(assert (not (>= (- index@101@main 2) 0)))
(check-sat)
; unsat
(pop) ; 13
; 0ms
; (get-info :all-statistics)
(push) ; 13
(assert (not (< (- index@101@main 2) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 13
; 1ms
; (get-info :all-statistics)
(push) ; 13
(assert (not (= (Seq_index (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 2)))))
(check-sat)
; unsat
(pop) ; 13
; 2ms
; (get-info :all-statistics)
(assert (= (Seq_index (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 2))))
(assert (MW_token ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit)))
(assert (= (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit)) ($Snap.combine ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))))))
(assert (= ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) $Snap.unit))
; [eval] contentNodes(hd, null) == old(content(this))[0..index - 2] ++ old[lhs](contentNodes(prev, null))
; [eval] contentNodes(hd, null)
(push) ; 13
(assert (contentNodes%precondition ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null))
(pop) ; 13
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null))
; [eval] old(content(this))[0..index - 2] ++ old[lhs](contentNodes(prev, null))
; [eval] old(content(this))[0..index - 2]
; [eval] old(content(this))[..index - 2]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] index - 2
; [eval] old[lhs](contentNodes(prev, null))
; [eval] contentNodes(prev, null)
(push) ; 13
(pop) ; 13
; Joined path conditions
(assert (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 2)) 0) (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))))
(push) ; 13
(set-option :rlimit 100000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 13
; 45ms
; (get-info :all-statistics)
(check-sat)
; unknown
; [eval] contentNodes(hd, null) == old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(hd, null)
(set-option :rlimit 0)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
; [eval] index - 1
; [eval] old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(ptr, null)
(push) ; 13
(pop) ; 13
; Joined path conditions
(push) ; 13
(assert (not (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 1)) 0) (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 13
; 352ms
; (get-info :all-statistics)
(assert (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 1)) 0) (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null))))
(assert (= (MWSF_apply (as mwsf@104@main $MWSF) snap@103@main) ($Snap.combine ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) $Snap.unit)))
(pop) ; 12
(pop) ; 11
(declare-const snap@107@main $Snap)
(assert (forall ((snap@103@main $Snap)) (! (=> (MW_token (as mwsf@104@main $MWSF) snap@103@main) (and (not (= ptr@85@main $Ref.null)) (and (= snap@103@main ($Snap.combine ($Snap.first snap@103@main) ($Snap.second snap@103@main))) (= ($Snap.second snap@103@main) $Snap.unit) (contentNodes%precondition ($Snap.first snap@103@main) ptr@102@main $Ref.null) (= (Seq_index (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 1)))) (=> (not (= ptr@85@main $Ref.null)) (and (lseg%trigger ($Snap.first snap@103@main) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first snap@103@main) ($Snap.combine ($Snap.first ($Snap.first snap@103@main)) ($Snap.second ($Snap.first snap@103@main)))) (= ($Snap.second ($Snap.first snap@103@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first snap@103@main))) ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) (= ($Snap.second ($Snap.second ($Snap.first snap@103@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= (joined_unfolding@106@main snap@103@main) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= (joined_unfolding@106@main snap@103@main) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main))))))) $Snap.unit) (recunf@105@main snap@103@main))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first snap@103@main)))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first snap@103@main)))) $Ref.null))) (joined_unfolding@106@main snap@103@main))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first snap@103@main))))) (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))) (=> (not (= ptr@85@main $Ref.null)) (and (contentNodes%precondition ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null) (= (Seq_index (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 2))) (MW_token ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit)) (= (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit)) ($Snap.combine ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))))) (= ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) $Snap.unit) (contentNodes%precondition ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 2)) 0) (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) ptr@85@main $Ref.null))))) (=> (not (= ptr@85@main $Ref.null)) (and (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@101@main 1)) 0) (contentNodes ($Snap.first snap@103@main) ptr@102@main $Ref.null))) (= (MWSF_apply (as mwsf@104@main $MWSF) snap@103@main) ($Snap.combine ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($Snap.first snapshot@86@main) ($Snap.combine ($Snap.first snap@103@main) $Snap.unit))) $Snap.unit))) $Snap.unit)))))) :pattern ((MW_token (as mwsf@104@main $MWSF) snap@103@main)) :qid |quant-u-33|)))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] 1 <= index
(set-option :rlimit 0)
(push) ; 11
(assert (not (<= 1 index@101@main)))
(check-sat)
; unsat
(pop) ; 11
; 2ms
; (get-info :all-statistics)
(assert (<= 1 index@101@main))
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 11
(pop) ; 11
; Joined path conditions
(push) ; 11
(assert (not (<= index@101@main (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (<= index@101@main (Seq_length (content snapshot@59@main this@56@main))))
; [eval] ptr.next == null ==> index == |old(content(this))|
; [eval] ptr.next == null
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 9ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 42ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] index == |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
(pop) ; 12
(push) ; 12
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(pop) ; 12
(pop) ; 11
; Joined path conditions
; Joined path conditions
(assert (or (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(push) ; 11
(assert (not (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= index@101@main (Seq_length (content snapshot@59@main this@56@main))))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= index@101@main (Seq_length (content snapshot@59@main this@56@main)))))
; [eval] ptr.data == old(content(this))[index - 1]
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(set-option :rlimit 0)
(push) ; 11
(pop) ; 11
; Joined path conditions
; [eval] index - 1
(push) ; 11
(assert (not (>= (- index@101@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (- index@101@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 1)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert (= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) (Seq_index (content snapshot@59@main this@56@main) (- index@101@main 1))))
; [eval] ptr.next != null ==> contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] ptr.next != null
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 56ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 38ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
; [eval] contentNodes(ptr.next, null) == old(content(this))[index..]
; [eval] contentNodes(ptr.next, null)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 13
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(pop) ; 13
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 13
(pop) ; 13
; Joined path conditions
(pop) ; 12
(push) ; 12
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(pop) ; 12
(pop) ; 11
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (contentNodes%precondition ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
; Joined path conditions
(push) ; 11
(assert (not (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) index@101@main)))))
(check-sat)
; unsat
(pop) ; 11
; 86ms
; (get-info :all-statistics)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (Seq_equal (contentNodes ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (Seq_drop (content snapshot@59@main this@56@main) index@101@main))))
; [eval] ptr.data < elem
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] ptr.next != null ==> ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
; [eval] ptr.next != null
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 46ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 47ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
; [eval] ptr.data <= (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 13
; 2ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 13
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 14
; 0ms
; (get-info :all-statistics)
; [eval] this != end
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 49ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 28ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 32ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 15
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
; [eval] this != end
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 16
; 42ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 17
; 35ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 17
; 30ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 17
; 48ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unknown
(pop) ; 17
; 58ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@108@main Bool)
(assert (as recunf@108@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 17
(push) ; 18
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 18
; 63ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 18
; [eval] this.data <= this.next.data
(pop) ; 18
(pop) ; 17
; Joined path conditions
(pop) ; 16
(push) ; 16
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 17
(push) ; 18
(pop) ; 18
(pop) ; 17
; Joined path conditions
(pop) ; 16
(pop) ; 15
(declare-const joined_unfolding@109@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= (as joined_unfolding@109@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= (as joined_unfolding@109@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit) (as recunf@108@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))))
(assert (as joined_unfolding@109@main Bool))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ptr@102@main)))
(check-sat)
; unknown
(pop) ; 15
; 52ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ptr@102@main)))
(check-sat)
; unsat
(pop) ; 15
; 1ms
; (get-info :all-statistics)
(pop) ; 14
(pop) ; 13
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= (as joined_unfolding@109@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= (as joined_unfolding@109@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit) (as recunf@108@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))) (as joined_unfolding@109@main Bool))))
(pop) ; 12
(set-option :rlimit 0)
(push) ; 12
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(pop) ; 12
(pop) ; 11
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= (as joined_unfolding@109@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= (as joined_unfolding@109@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) $Snap.unit) (as recunf@108@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Ref.null))) (as joined_unfolding@109@main Bool))))))
; Joined path conditions
(push) ; 11
(assert (not (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(check-sat)
; unsat
(pop) ; 11
; 3ms
; (get-info :all-statistics)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 11
(pop) ; 11
; Joined path conditions
; [eval] index - 1
(push) ; 11
(assert (not (>= (- index@101@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (- index@101@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 11
(pop) ; 11
; Joined path conditions
; [eval] index - 1
(pop) ; 10
(pop) ; 9
(push) ; 9
(assert (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main))))
(pop) ; 9
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))) (= $Ref.null hd@79@main))))
(check-sat)
; unknown
(pop) ; 9
; 2ms
; (get-info :all-statistics)
; [eval] !(ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem))
; [eval] ptr.next != null && (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
; [eval] ptr.next != null
(set-option :rlimit 0)
(push) ; 9
(push) ; 10
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(pop) ; 10
(push) ; 10
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
; [eval] (unfolding acc(lseg(ptr.next, null), write) in ptr.next.data < elem)
(push) ; 11
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
; [eval] this != end
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 9ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 13
; 9ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(check-sat)
; unknown
(pop) ; 13
; 10ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 13
; 10ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 13
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 30ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 8ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 28ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 28ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 25ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 35ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 15
; 24ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@110@main Bool)
(assert (as recunf@110@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 15
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 24ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
; [eval] this.data <= this.next.data
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(push) ; 14
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 15
(push) ; 16
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(pop) ; 13
(declare-const joined_unfolding@111@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@111@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@111@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@110@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@111@main Bool))
; [eval] ptr.next.data < elem
(pop) ; 12
(pop) ; 11
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@111@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@111@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@110@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@111@main Bool))))
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@111@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@111@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@110@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@111@main Bool))))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main))))
(check-sat)
; unknown
(pop) ; 9
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main)))))
(check-sat)
; unknown
(pop) ; 9
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(assert (not (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) $Ref.null)) (< ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) elem@57@main))))
; [exec]
; tmp := new(data, next, head, held, changed)
(declare-const tmp@112@main $Ref)
(assert (not (= tmp@112@main $Ref.null)))
(declare-const data@113@main Int)
(declare-const next@114@main $Ref)
(declare-const head@115@main $Ref)
(declare-const held@116@main Int)
(declare-const changed@117@main Bool)
(assert (not (= tmp@112@main this@56@main)))
(assert (not (= tmp@112@main hd@79@main)))
(assert (not (= tmp@112@main prev@83@main)))
(assert (not (= tmp@112@main ptr@85@main)))
(assert (not (= tmp@112@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)))))
(assert (not (= tmp@112@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)))))
(assert (not (= tmp@112@main tmp@61@main)))
; [exec]
; tmp.data := elem
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ptr@85@main tmp@112@main)))
(check-sat)
; unknown
(pop) ; 10
; 3ms
; (get-info :all-statistics)
; [exec]
; tmp.next := ptr.next
(declare-const next@118@main $Ref)
(assert (= next@118@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main))))
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= ptr@85@main tmp@112@main)))
(check-sat)
; unknown
(pop) ; 10
; 3ms
; (get-info :all-statistics)
; [exec]
; ptr.next := tmp
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= tmp@112@main ptr@85@main)))
(check-sat)
; unknown
(pop) ; 10
; 3ms
; (get-info :all-statistics)
; [exec]
; fold acc(lseg(ptr.next, null), write)
; [eval] this != end
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 100000)
(assert (not (= tmp@112@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 10
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) next@118@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 11
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) next@118@main)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 11
(push) ; 12
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) next@118@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@86@main)) next@118@main)))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) next@118@main $Ref.null))
; [eval] this != end
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= next@118@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 18ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= next@118@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 4ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(assert (not (= next@118@main $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= tmp@112@main next@118@main)))
(check-sat)
; unknown
(pop) ; 13
; 21ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main next@118@main)))
(check-sat)
; unknown
(pop) ; 13
; 17ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= ptr@85@main next@118@main)))
(check-sat)
; unknown
(pop) ; 13
; 17ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= tmp@112@main next@118@main)))
(check-sat)
; unknown
(pop) ; 13
; 12ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 13
; 12ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 13
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
; [eval] this != end
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 55ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 14ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= next@118@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 66ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= tmp@112@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 51ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 42ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= next@118@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 53ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= ptr@85@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 56ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= tmp@112@main ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(check-sat)
; unknown
(pop) ; 15
; 50ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 15
; 56ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@119@main Bool)
(assert (as recunf@119@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 15
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)))
(check-sat)
; unknown
(pop) ; 16
; 81ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
; [eval] this.data <= this.next.data
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(push) ; 14
(assert (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 15
(push) ; 16
(pop) ; 16
(pop) ; 15
; Joined path conditions
(pop) ; 14
(pop) ; 13
(declare-const joined_unfolding@120@main Bool)
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@120@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))))
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@120@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))))
(assert (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@119@main Bool))))
; Joined path conditions
(assert (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))))
(assert (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))))
(assert (as joined_unfolding@120@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 13
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= next@118@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 14
; 21ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
; [eval] this.data <= this.next.data
(pop) ; 14
(pop) ; 13
; Joined path conditions
(pop) ; 12
(push) ; 12
(assert (= next@118@main $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 13
(push) ; 14
(pop) ; 14
(pop) ; 13
; Joined path conditions
(pop) ; 12
(pop) ; 11
(declare-const joined_unfolding@121@main Bool)
(assert (=> (not (= next@118@main $Ref.null)) (= (as joined_unfolding@121@main Bool) (=> (not (= next@118@main $Ref.null)) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(assert (=> (= next@118@main $Ref.null) (= (as joined_unfolding@121@main Bool) true)))
; Joined path conditions
(assert (lseg%trigger ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) next@118@main $Ref.null))
(assert (=> (not (= next@118@main $Ref.null)) (and (not (= next@118@main $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))
(assert (=> (not (= next@118@main $Ref.null)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit)))
(assert (=> (not (= next@118@main $Ref.null)) (and (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= (as joined_unfolding@120@main Bool) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= (as joined_unfolding@120@main Bool) true)) (lseg%trigger ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))) (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))))) (=> (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) $Snap.unit) (as recunf@119@main Bool))) (=> (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))) (or (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null) (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Ref.null))) (as joined_unfolding@120@main Bool))))
; Joined path conditions
(assert (=> (= next@118@main $Ref.null) (and (= next@118@main $Ref.null) (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))))
(assert (or (= next@118@main $Ref.null) (not (= next@118@main $Ref.null))))
(push) ; 11
(assert (not (as joined_unfolding@121@main Bool)))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(assert (as joined_unfolding@121@main Bool))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) tmp@112@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 11
; 3ms
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) tmp@112@main $Ref.null))
; [exec]
; fold acc(lseg(ptr, null), write)
; [eval] this != end
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (= ptr@85@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 11
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(push) ; 12
; [eval] this != end
(push) ; 13
(set-option :rlimit 100000)
(assert (not (= tmp@112@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 13
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main tmp@112@main)))
(check-sat)
; unknown
(pop) ; 14
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (= ptr@85@main tmp@112@main)))
(check-sat)
; unknown
(pop) ; 14
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) next@118@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 14
; 3ms
; (get-info :all-statistics)
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(set-option :rlimit 0)
(push) ; 14
; [eval] this != end
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= next@118@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 34ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 100000)
(assert (not (not (= next@118@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 15
; 4ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(assert (not (= next@118@main $Ref.null)))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) ($Snap.combine ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= tmp@112@main next@118@main)))
(check-sat)
; unknown
(pop) ; 16
; 28ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main next@118@main)))
(check-sat)
; unknown
(pop) ; 16
; 15ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= tmp@112@main next@118@main)))
(check-sat)
; unknown
(pop) ; 16
; 26ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (= ptr@85@main next@118@main)))
(check-sat)
; unknown
(pop) ; 16
; 27ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))))))
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 16
; 27ms
; (get-info :all-statistics)
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit))
; [eval] (unfolding acc(lseg(this.next, end), write) in this.next != end ==> this.data <= this.next.data)
(declare-const recunf@122@main Bool)
(assert (as recunf@122@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(set-option :rlimit 0)
(push) ; 16
(push) ; 17
(set-option :rlimit 100000)
(assert (not (= next@118@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 17
; 16ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
; [eval] this.data <= this.next.data
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(push) ; 15
(assert (= next@118@main $Ref.null))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 16
(push) ; 17
(pop) ; 17
(pop) ; 16
; Joined path conditions
(pop) ; 15
(pop) ; 14
(declare-const joined_unfolding@123@main Bool)
(assert (=> (not (= next@118@main $Ref.null)) (= (as joined_unfolding@123@main Bool) (=> (not (= next@118@main $Ref.null)) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))))
(assert (=> (= next@118@main $Ref.null) (= (as joined_unfolding@123@main Bool) true)))
; Joined path conditions
(assert (=> (not (= next@118@main $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit) (as recunf@122@main Bool))))
; Joined path conditions
(assert (as joined_unfolding@123@main Bool))
; [eval] this.next != end ==> this.data <= this.next.data
; [eval] this.next != end
(push) ; 14
(push) ; 15
(set-option :rlimit 100000)
(assert (not (= tmp@112@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 15
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
; [eval] this.data <= this.next.data
(pop) ; 15
(pop) ; 14
; Joined path conditions
(pop) ; 13
(pop) ; 12
; Joined path conditions
(assert (=> (not (= tmp@112@main $Ref.null)) (and (=> (not (= next@118@main $Ref.null)) (= (as joined_unfolding@123@main Bool) (=> (not (= next@118@main $Ref.null)) (<= elem@57@main ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))))))))) (=> (= next@118@main $Ref.null) (= (as joined_unfolding@123@main Bool) true)) (=> (not (= next@118@main $Ref.null)) (and (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first ($Snap.second ($Snap.second snapshot@86@main)))))) $Snap.unit) (as recunf@122@main Bool))) (as joined_unfolding@123@main Bool))))
(push) ; 12
(assert (not (=> (not (= tmp@112@main $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) elem@57@main))))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(assert (=> (not (= tmp@112@main $Ref.null)) (<= ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second snapshot@86@main))) elem@57@main)))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) ptr@85@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 2ms
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null))
; [exec]
; apply acc(lseg(ptr, null), write) &&
;   contentNodes(ptr, null)[0] == old(content(this))[index - 1] --*
;   acc(lseg(hd, null), write) &&
;   contentNodes(hd, null) ==
;   old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(set-option :rlimit 0)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] index - 1
(push) ; 12
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(push) ; 12
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] index - 1
; [eval] contentNodes(ptr, null)[0] == old(content(this))[index - 1]
; [eval] contentNodes(ptr, null)[0]
; [eval] contentNodes(ptr, null)
(push) ; 12
(assert (contentNodes%precondition ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null))
(pop) ; 12
; Joined path conditions
(assert (contentNodes%precondition ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null))
(push) ; 12
(assert (not (< 0 (Seq_length (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null)))))
(check-sat)
; unsat
(pop) ; 12
; 1ms
; (get-info :all-statistics)
; [eval] old(content(this))[index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] index - 1
(push) ; 12
(assert (not (>= (- index@84@main 1) 0)))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(push) ; 12
(assert (not (< (- index@84@main 1) (Seq_length (content snapshot@59@main this@56@main)))))
(check-sat)
; unsat
(pop) ; 12
; 0ms
; (get-info :all-statistics)
(push) ; 12
(assert (not (= (Seq_index (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@84@main 1)))))
(check-sat)
; unsat
(pop) ; 12
; 1ms
; (get-info :all-statistics)
(assert (= (Seq_index (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null) 0) (Seq_index (content snapshot@59@main this@56@main) (- index@84@main 1))))
(assert (MW_token ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))
(assert (= (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)) ($Snap.combine ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))))))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (and (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) hd@79@main) (= hd@79@main $Ref.null))))
(check-sat)
; unknown
(pop) ; 12
; 7ms
; (get-info :all-statistics)
(assert (= ($Snap.second (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) $Snap.unit))
; [eval] contentNodes(hd, null) == old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(hd, null)
(set-option :rlimit 0)
(push) ; 12
(assert (contentNodes%precondition ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null))
(pop) ; 12
; Joined path conditions
(assert (contentNodes%precondition ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null))
; [eval] old(content(this))[0..index - 1] ++ old[lhs](contentNodes(ptr, null))
; [eval] old(content(this))[0..index - 1]
; [eval] old(content(this))[..index - 1]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] index - 1
; [eval] old[lhs](contentNodes(ptr, null))
; [eval] contentNodes(ptr, null)
(push) ; 12
(pop) ; 12
; Joined path conditions
(assert (Seq_equal (contentNodes ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) hd@79@main $Ref.null) (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) (- index@84@main 1)) 0) (contentNodes ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) ptr@85@main $Ref.null))))
(push) ; 12
(set-option :rlimit 100000)
(assert (not (and (= hd@79@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))) (= $Ref.null hd@79@main))))
(check-sat)
; unknown
(pop) ; 12
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= this@56@main tmp@112@main)))
(check-sat)
; unknown
(pop) ; 12
; 10ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= $Snap.unit ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))))))
(check-sat)
; unknown
(pop) ; 12
; 11ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit))) $Snap.unit))))
(check-sat)
; unknown
(pop) ; 12
; 6ms
; (get-info :all-statistics)
(assert (and (not (= tmp@112@main this@56@main)) (not (= this@56@main tmp@112@main))))
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= head@115@main ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main))))))
(check-sat)
; unknown
(pop) ; 12
; 6ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (not (= ($SortWrappers.$SnapTo$Ref ($Snap.first snapshot@59@main)) head@115@main))))
(check-sat)
; unknown
(pop) ; 12
; 6ms
; (get-info :all-statistics)
; [exec]
; fold acc(List(this), write)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 100000)
(assert (not (= hd@79@main $Ref.null)))
(check-sat)
; unknown
(pop) ; 12
; 6ms
; (get-info :all-statistics)
(assert (List%trigger ($Snap.combine ($Snap.first snapshot@59@main) ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))) this@56@main))
; [eval] 0 <= index
(set-option :rlimit 0)
(push) ; 12
(assert (not (<= 0 index@84@main)))
(check-sat)
; unsat
(pop) ; 12
; 2ms
; (get-info :all-statistics)
(assert (<= 0 index@84@main))
; [eval] index <= |old(content(this))|
; [eval] |old(content(this))|
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] content(this) == old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] content(this)
(push) ; 12
(assert (content%precondition ($Snap.combine ($Snap.first snapshot@59@main) ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))) this@56@main))
(pop) ; 12
; Joined path conditions
(assert (content%precondition ($Snap.combine ($Snap.first snapshot@59@main) ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))) this@56@main))
; [eval] old(content(this))[0..index] ++ Seq(elem) ++ old(content(this))[index..]
; [eval] old(content(this))[0..index] ++ Seq(elem)
; [eval] old(content(this))[0..index]
; [eval] old(content(this))[..index]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
; [eval] Seq(elem)
(assert (= (Seq_length (Seq_singleton elem@57@main)) 1))
; [eval] old(content(this))[index..]
; [eval] old(content(this))
; [eval] content(this)
(push) ; 12
(pop) ; 12
; Joined path conditions
(push) ; 12
(assert (not (Seq_equal (content ($Snap.combine ($Snap.first snapshot@59@main) ($Snap.first (MWSF_apply ($SortWrappers.$SnapTo$MWSF ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second snapshot@86@main))))))))))) ($Snap.combine ($Snap.combine ($Snap.first ($Snap.second snapshot@86@main)) ($Snap.combine ($SortWrappers.$RefTo$Snap tmp@112@main) ($Snap.combine ($Snap.combine ($SortWrappers.IntTo$Snap elem@57@main) ($Snap.combine ($SortWrappers.$RefTo$Snap next@118@main) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@86@main))) $Snap.unit))) $Snap.unit))) $Snap.unit)))) this@56@main) (Seq_append (Seq_append (Seq_drop (Seq_take (content snapshot@59@main this@56@main) index@84@main) 0) (Seq_singleton elem@57@main)) (Seq_drop (content snapshot@59@main this@56@main) index@84@main)))))
(check-sat)
(pop) ; 12
(pop) ; 11
(pop) ; 10
(pop) ; 9
(pop) ; 8
(pop) ; 7
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
