#!/usr/bin/env python3
"""Preserve every timeout follow-up observation and bind its input artifacts."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/will/wk/exp/ferrum')
LABELS = ['source-30', 'old-30-controls', 'source-bounded-assert',
          'current-30-default', 'current-30-modes', 'current-old-triggers',
          'current-source-lifecycle', 'current-source-lifecycle-repeat',
          'current-separate-on', 'current-repeat-on', 'current-60-tree']
TRACE_LABELS = ['old-graph-trace', 'current-append-trace',
                'current-wand-trace-0', 'current-wand-trace-1']

def sha(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def compact_record(row):
    result = {k: v for k, v in row.items() if k != 'backend_warnings'}
    if 'backend_warnings' in row:
        result['backend_warning_count'] = len(row['backend_warnings'])
        result['backend_warnings_sha256'] = hashlib.sha256(
            json.dumps(row['backend_warnings'], sort_keys=True).encode()).hexdigest()
    return result

def main():
    selection = json.loads((ROOT / 'selection.json').read_text())
    annotations = json.loads((ROOT / 'fixture-annotations.json').read_text())
    experiments = []
    for label in LABELS:
        folder = ROOT / label
        plan = json.loads((folder / 'plan.json').read_text())
        records = json.loads((folder / 'complete.json').read_text())
        assert [r['id'] for r in records] == plan['ids']
        for row in records:
            raw = json.loads((folder / f"{row['id']:02d}.json").read_text())
            assert len(raw['records']) == 1 and len(row['records']) == 1
            assert raw['outcome'] == 'completed' and raw['exit_code'] == 0
            assert not raw['cleanup_pending'] and not raw['protocol_errors']
            assert sha(folder / f"{row['id']:02d}.json") == row['result_sha256']
            row['records'] = [compact_record(r) for r in row['records']]
        assert sha(plan['prefix'][0]) == plan['binary_sha256']
        assert sha(plan['prefix'][-1]) == plan['z3_sha256']
        experiments.append({'label': label, 'plan': plan, 'observations': records})
    traces = []
    for label in TRACE_LABELS:
        folder = ROOT / label
        result = json.loads((folder / 'result.json').read_text())
        assert result['outcome'] == 'completed' and result['exit_code'] == 0
        assert not result['cleanup_pending'] and not result['protocol_errors']
        streams = []
        for p in sorted((folder / 'streams').glob('*/analysis.json')):
            d = json.loads(p.read_text())
            cutoff = result['records'][0]['outcome'] == 'verifier_timeout'
            expected = ([f"Missing response to command {len(d['commands']) - 1} check-sat"]
                        if cutoff else [])
            assert d['issues'] == expected, (label, d['issues'])
            summary = {k: v for k, v in d.items() if k not in ['commands', 'queries']}
            summary['last_query'] = d['queries'][-1]
            summary['query_response_wait_sum_s'] = sum(q.get('response_wait_s', 0) for q in d['queries'])
            summary['last_query_sent_after_s'] = (d['queries'][-1]['received_ns'] - d['metadata']['started_monotonic_ns']) / 1e9
            summary['reason_unknown_responses'] = dict(Counter(c.get('response') for c in d['commands'] if c['preview'] == '( get-info :reason-unknown )'))
            streams.append(summary)
        traces.append({'label': label, 'command': result['command'],
                       'outcome': result['outcome'], 'wall_seconds': result['wall_seconds'],
                       'records': [compact_record(r) for r in result['records']],
                       'streams': streams, 'result_sha256': sha(folder / 'result.json')})

    postflight = []
    for old in json.loads((ROOT / 'preflight.json').read_text()):
        current = sha(old['path'])
        postflight.append({'path': old['path'], 'sha256': current, 'matches': current == old['expected']})
        assert current == old['expected'], old['path']
    with tarfile.open(ROOT / 'source.tar') as archive:
        members = [m for m in archive.getmembers() if m.isfile()]
        for m in members:
            assert archive.extractfile(m).read() == (ROOT / 'source' / m.name).read_bytes(), m.name
    (ROOT / 'postflight.json').write_text(json.dumps({'artifacts': postflight,
        'unchanged_source_files': len(members), 'completed_runs': sum(len(e['observations']) for e in experiments),
        'completed_traces': len(traces)}, indent=2) + '\n')

    evidence = REPO / 'porting/evidence/timeout-triage'
    evidence.mkdir(parents=True, exist_ok=True)
    output = evidence / 'observations.tar.gz'
    files = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in ['.json', '.log', '.py']]
    for label in LABELS + TRACE_LABELS:
        files.extend(p for p in (ROOT / label).rglob('*') if p.is_file())
    inventory = []
    with output.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as archive:
        def add(name, data):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
            inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        for p in sorted(set(files)):
            add(str(p.relative_to(ROOT)), p.read_bytes())
        unique = {r['path']: r for r in selection}
        for path, row in sorted(unique.items()):
            assert sha(path) == row['sha256']
            add('fixtures/' + row['key'].split('/', 1)[1], Path(path).read_bytes())
    report = {
        'kind': 'bounded_timeout_followup', 'runtime_revision': '2df948c9014de33b7baa13599eaf9d5078906b28',
        'baseline_runtime_revision': 'afdf10cf59106c38d09df32939f1aa9c77d0b989',
        'source_revisions': {'silicon': 'ff386aec4664231dc6f2cb56d8d35f1623088363', 'silver': 'c4f54b84703a04434b03e97bfea87dbd09870fd2'},
        'original_report_sha256': sha(REPO / 'porting/compatibility-final.json'),
        'source_archive_sha256': sha(ROOT / 'source.tar'),
        'selection': [{'id': r['id'], 'key': r['key'], 'path': r['path'], 'sha256': r['sha256'],
                       'original_options': r['options'], 'annotations': annotations[r['id']]['annotations'],
                       'original_outcomes': {b: r['old'][b]['observation']['outcome'] for b in ['source', 'native']}} for r in selection],
        'experiments': experiments, 'traces': traces,
        'wand_emission_comparison': json.loads((ROOT / 'wand-stream-comparison.json').read_text()),
        'audit': json.loads((ROOT / 'postflight.json').read_text()),
        'preserved_evidence': {'path': str(output.relative_to(REPO)), 'sha256': sha(output), 'inventory': inventory},
        'limitations': [
            'Fresh processes replace historical reused batches; the change in outcome is not solely attributable to code changes.',
            'Concurrent jobs use recorded CPU sets on a shared host. Timings are observations, not causal speedup estimates.',
            'Overall verifier budgets exclude some frontend/startup work; recorded wall times include the whole session.',
            'Unexpected proof failures do not resolve a timeout or prove the input incorrect.',
            'Killed diagnostic streams retain an unanswered final check and incomplete solver metadata.',
            'All experiments are retained; later configurations/repeats do not overwrite the first pass.',
            'No runtime code or defaults changed, no full corpus rerun, and no live Prusti worktree changes.',
        ],
    }
    (REPO / 'porting/timeout-followup.json').write_text(json.dumps(report, indent=2) + '\n')
    print('Preserved', len(files), 'evidence files plus', len(unique), 'fixtures;', output.stat().st_size, 'compressed bytes')
    print('Audited', report['audit']['completed_runs'], 'runs and', len(traces), 'traces;', len(members), 'unchanged source files')

if __name__ == '__main__':
    main()
