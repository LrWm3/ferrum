(get-info :version)
; (:version "4.16.0")
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :model.partial true)
(set-option :smt.qi.max_multi_patterns 1000)
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-const $Snap.null $Snap) ; hack
(declare-fun internalCondFrame (Bool $Snap $Snap) $Snap)
(assert (forall ((cnd Bool) (frst $Snap) (scnd $Snap)) (!
    (= (internalCondFrame cnd frst scnd) (ite cnd frst scnd))
    :pattern ((internalCondFrame cnd frst scnd)))))
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(declare-fun $Perm.min ($Perm $Perm) $Perm)
(assert (forall ((p1 $Perm) (p2 $Perm)) (!
    (= ($Perm.min p1 p2) (ite (<= p1 p2) p1 p2))
    :pattern (($Perm.min p1 p2)))))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
(declare-sort Seq<Int> 0)
(declare-sort Seq<$Ref> 0)
(declare-sort Set<Int> 0)
(declare-sort Set<$Ref> 0)
(declare-sort Set<$Snap> 0)
(declare-sort Set<Seq<Int>> 0)
(declare-sort Set<Seq<$Ref>> 0)
(declare-fun Set_card (Set<Int>) Int)
(declare-const Set_empty Set<Int>)
(declare-fun Set_in (Int Set<Int>) Bool)
(declare-fun Set_singleton (Int) Set<Int>)
(declare-fun Set_unionone (Set<Int> Int) Set<Int>)
(declare-fun Set_union (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_intersection (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_difference (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_subset (Set<Int> Set<Int>) Bool)
(declare-fun Set_equal (Set<Int> Set<Int>) Bool)
(declare-fun Set_skolem_diff (Set<Int> Set<Int>) Int)
(declare-fun Set_card (Set<$Ref>) Int)
(declare-const Set_empty Set<$Ref>)
(declare-fun Set_in ($Ref Set<$Ref>) Bool)
(declare-fun Set_singleton ($Ref) Set<$Ref>)
(declare-fun Set_unionone (Set<$Ref> $Ref) Set<$Ref>)
(declare-fun Set_union (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_intersection (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_difference (Set<$Ref> Set<$Ref>) Set<$Ref>)
(declare-fun Set_subset (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_equal (Set<$Ref> Set<$Ref>) Bool)
(declare-fun Set_skolem_diff (Set<$Ref> Set<$Ref>) $Ref)
(declare-fun Set_card (Set<$Snap>) Int)
(declare-const Set_empty Set<$Snap>)
(declare-fun Set_in ($Snap Set<$Snap>) Bool)
(declare-fun Set_singleton ($Snap) Set<$Snap>)
(declare-fun Set_unionone (Set<$Snap> $Snap) Set<$Snap>)
(declare-fun Set_union (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_intersection (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_difference (Set<$Snap> Set<$Snap>) Set<$Snap>)
(declare-fun Set_subset (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_equal (Set<$Snap> Set<$Snap>) Bool)
(declare-fun Set_skolem_diff (Set<$Snap> Set<$Snap>) $Snap)
(declare-fun Set_card (Set<Seq<Int>>) Int)
(declare-const Set_empty Set<Seq<Int>>)
(declare-fun Set_in (Seq<Int> Set<Seq<Int>>) Bool)
(declare-fun Set_singleton (Seq<Int>) Set<Seq<Int>>)
(declare-fun Set_unionone (Set<Seq<Int>> Seq<Int>) Set<Seq<Int>>)
(declare-fun Set_union (Set<Seq<Int>> Set<Seq<Int>>) Set<Seq<Int>>)
(declare-fun Set_intersection (Set<Seq<Int>> Set<Seq<Int>>) Set<Seq<Int>>)
(declare-fun Set_difference (Set<Seq<Int>> Set<Seq<Int>>) Set<Seq<Int>>)
(declare-fun Set_subset (Set<Seq<Int>> Set<Seq<Int>>) Bool)
(declare-fun Set_equal (Set<Seq<Int>> Set<Seq<Int>>) Bool)
(declare-fun Set_skolem_diff (Set<Seq<Int>> Set<Seq<Int>>) Seq<Int>)
(declare-fun Set_card (Set<Seq<$Ref>>) Int)
(declare-const Set_empty Set<Seq<$Ref>>)
(declare-fun Set_in (Seq<$Ref> Set<Seq<$Ref>>) Bool)
(declare-fun Set_singleton (Seq<$Ref>) Set<Seq<$Ref>>)
(declare-fun Set_unionone (Set<Seq<$Ref>> Seq<$Ref>) Set<Seq<$Ref>>)
(declare-fun Set_union (Set<Seq<$Ref>> Set<Seq<$Ref>>) Set<Seq<$Ref>>)
(declare-fun Set_intersection (Set<Seq<$Ref>> Set<Seq<$Ref>>) Set<Seq<$Ref>>)
(declare-fun Set_difference (Set<Seq<$Ref>> Set<Seq<$Ref>>) Set<Seq<$Ref>>)
(declare-fun Set_subset (Set<Seq<$Ref>> Set<Seq<$Ref>>) Bool)
(declare-fun Set_equal (Set<Seq<$Ref>> Set<Seq<$Ref>>) Bool)
(declare-fun Set_skolem_diff (Set<Seq<$Ref>> Set<Seq<$Ref>>) Seq<$Ref>)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
(declare-fun Seq_length (Seq<$Ref>) Int)
(declare-const Seq_empty Seq<$Ref>)
(declare-fun Seq_singleton ($Ref) Seq<$Ref>)
(declare-fun Seq_append (Seq<$Ref> Seq<$Ref>) Seq<$Ref>)
(declare-fun Seq_index (Seq<$Ref> Int) $Ref)
(declare-fun Seq_update (Seq<$Ref> Int $Ref) Seq<$Ref>)
(declare-fun Seq_take (Seq<$Ref> Int) Seq<$Ref>)
(declare-fun Seq_drop (Seq<$Ref> Int) Seq<$Ref>)
(declare-fun Seq_contains (Seq<$Ref> $Ref) Bool)
(declare-fun Seq_contains_trigger (Seq<$Ref> $Ref) Bool)
(declare-fun Seq_skolem (Seq<$Ref> $Ref) Int)
(declare-fun Seq_equal (Seq<$Ref> Seq<$Ref>) Bool)
(declare-fun Seq_skolem_diff (Seq<$Ref> Seq<$Ref>) Int)
(declare-sort $FVF<nodes> 0)
(declare-sort $FVF<val> 0)
(declare-sort $FVF<next> 0)
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
(declare-fun $SortWrappers.Seq<$Ref>To$Snap (Seq<$Ref>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<$Ref> ($Snap) Seq<$Ref>)
(assert (forall ((x Seq<$Ref>)) (!
    (= x ($SortWrappers.$SnapToSeq<$Ref>($SortWrappers.Seq<$Ref>To$Snap x)))
    :pattern (($SortWrappers.Seq<$Ref>To$Snap x))
    :qid |$Snap.$SnapToSeq<$Ref>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<$Ref>To$Snap($SortWrappers.$SnapToSeq<$Ref> x)))
    :pattern (($SortWrappers.$SnapToSeq<$Ref> x))
    :qid |$Snap.Seq<$Ref>To$SnapToSeq<$Ref>|
    )))
(declare-fun $SortWrappers.Set<Int>To$Snap (Set<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Int> ($Snap) Set<Int>)
(assert (forall ((x Set<Int>)) (!
    (= x ($SortWrappers.$SnapToSet<Int>($SortWrappers.Set<Int>To$Snap x)))
    :pattern (($SortWrappers.Set<Int>To$Snap x))
    :qid |$Snap.$SnapToSet<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Int>To$Snap($SortWrappers.$SnapToSet<Int> x)))
    :pattern (($SortWrappers.$SnapToSet<Int> x))
    :qid |$Snap.Set<Int>To$SnapToSet<Int>|
    )))
(declare-fun $SortWrappers.Set<$Ref>To$Snap (Set<$Ref>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Ref> ($Snap) Set<$Ref>)
(assert (forall ((x Set<$Ref>)) (!
    (= x ($SortWrappers.$SnapToSet<$Ref>($SortWrappers.Set<$Ref>To$Snap x)))
    :pattern (($SortWrappers.Set<$Ref>To$Snap x))
    :qid |$Snap.$SnapToSet<$Ref>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Ref>To$Snap($SortWrappers.$SnapToSet<$Ref> x)))
    :pattern (($SortWrappers.$SnapToSet<$Ref> x))
    :qid |$Snap.Set<$Ref>To$SnapToSet<$Ref>|
    )))
(declare-fun $SortWrappers.Set<$Snap>To$Snap (Set<$Snap>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<$Snap> ($Snap) Set<$Snap>)
(assert (forall ((x Set<$Snap>)) (!
    (= x ($SortWrappers.$SnapToSet<$Snap>($SortWrappers.Set<$Snap>To$Snap x)))
    :pattern (($SortWrappers.Set<$Snap>To$Snap x))
    :qid |$Snap.$SnapToSet<$Snap>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<$Snap>To$Snap($SortWrappers.$SnapToSet<$Snap> x)))
    :pattern (($SortWrappers.$SnapToSet<$Snap> x))
    :qid |$Snap.Set<$Snap>To$SnapToSet<$Snap>|
    )))
(declare-fun $SortWrappers.Set<Seq<Int>>To$Snap (Set<Seq<Int>>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Seq<Int>> ($Snap) Set<Seq<Int>>)
(assert (forall ((x Set<Seq<Int>>)) (!
    (= x ($SortWrappers.$SnapToSet<Seq<Int>>($SortWrappers.Set<Seq<Int>>To$Snap x)))
    :pattern (($SortWrappers.Set<Seq<Int>>To$Snap x))
    :qid |$Snap.$SnapToSet<Seq<Int>>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Seq<Int>>To$Snap($SortWrappers.$SnapToSet<Seq<Int>> x)))
    :pattern (($SortWrappers.$SnapToSet<Seq<Int>> x))
    :qid |$Snap.Set<Seq<Int>>To$SnapToSet<Seq<Int>>|
    )))
(declare-fun $SortWrappers.Set<Seq<$Ref>>To$Snap (Set<Seq<$Ref>>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Seq<$Ref>> ($Snap) Set<Seq<$Ref>>)
(assert (forall ((x Set<Seq<$Ref>>)) (!
    (= x ($SortWrappers.$SnapToSet<Seq<$Ref>>($SortWrappers.Set<Seq<$Ref>>To$Snap x)))
    :pattern (($SortWrappers.Set<Seq<$Ref>>To$Snap x))
    :qid |$Snap.$SnapToSet<Seq<$Ref>>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Seq<$Ref>>To$Snap($SortWrappers.$SnapToSet<Seq<$Ref>> x)))
    :pattern (($SortWrappers.$SnapToSet<Seq<$Ref>> x))
    :qid |$Snap.Set<Seq<$Ref>>To$SnapToSet<Seq<$Ref>>|
    )))
(declare-fun $SortWrappers.$FVF<nodes>To$Snap ($FVF<nodes>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<nodes> ($Snap) $FVF<nodes>)
(assert (forall ((x $FVF<nodes>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<nodes>($SortWrappers.$FVF<nodes>To$Snap x)))
    :pattern (($SortWrappers.$FVF<nodes>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<nodes>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<nodes>To$Snap($SortWrappers.$SnapTo$FVF<nodes> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<nodes> x))
    :qid |$Snap.$FVF<nodes>To$SnapTo$FVF<nodes>|
    )))
(declare-fun $SortWrappers.$FVF<val>To$Snap ($FVF<val>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<val> ($Snap) $FVF<val>)
(assert (forall ((x $FVF<val>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<val>($SortWrappers.$FVF<val>To$Snap x)))
    :pattern (($SortWrappers.$FVF<val>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<val>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<val>To$Snap($SortWrappers.$SnapTo$FVF<val> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<val> x))
    :qid |$Snap.$FVF<val>To$SnapTo$FVF<val>|
    )))
(declare-fun $SortWrappers.$FVF<next>To$Snap ($FVF<next>) $Snap)
(declare-fun $SortWrappers.$SnapTo$FVF<next> ($Snap) $FVF<next>)
(assert (forall ((x $FVF<next>)) (!
    (= x ($SortWrappers.$SnapTo$FVF<next>($SortWrappers.$FVF<next>To$Snap x)))
    :pattern (($SortWrappers.$FVF<next>To$Snap x))
    :qid |$Snap.$SnapTo$FVF<next>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$FVF<next>To$Snap($SortWrappers.$SnapTo$FVF<next> x)))
    :pattern (($SortWrappers.$SnapTo$FVF<next> x))
    :qid |$Snap.$FVF<next>To$SnapTo$FVF<next>|
    )))
; /field_value_functions_declarations.smt2 [nodes: Seq[Ref]]
(declare-fun $FVF.domain_nodes ($FVF<nodes>) Set<$Ref>)
(declare-fun $FVF.has_domain_nodes ($FVF<nodes>) Bool)
(declare-fun $FVF.lookup_nodes ($FVF<nodes> $Ref) Seq<$Ref>)
(declare-fun $FVF.after_nodes ($FVF<nodes> $FVF<nodes>) Bool)
(declare-fun $FVF.loc_nodes (Seq<$Ref> $Ref) Bool)
(declare-fun $FVF.perm_nodes ($FPM $Ref) $Perm)
(declare-const $fvfTOP_nodes $FVF<nodes>)
; /field_value_functions_declarations.smt2 [val: Int]
(declare-fun $FVF.domain_val ($FVF<val>) Set<$Ref>)
(declare-fun $FVF.has_domain_val ($FVF<val>) Bool)
(declare-fun $FVF.lookup_val ($FVF<val> $Ref) Int)
(declare-fun $FVF.after_val ($FVF<val> $FVF<val>) Bool)
(declare-fun $FVF.loc_val (Int $Ref) Bool)
(declare-fun $FVF.perm_val ($FPM $Ref) $Perm)
(declare-const $fvfTOP_val $FVF<val>)
; /field_value_functions_declarations.smt2 [next: Ref]
(declare-fun $FVF.domain_next ($FVF<next>) Set<$Ref>)
(declare-fun $FVF.has_domain_next ($FVF<next>) Bool)
(declare-fun $FVF.lookup_next ($FVF<next> $Ref) $Ref)
(declare-fun $FVF.after_next ($FVF<next> $FVF<next>) Bool)
(declare-fun $FVF.loc_next ($Ref $Ref) Bool)
(declare-fun $FVF.perm_next ($FPM $Ref) $Perm)
(declare-const $fvfTOP_next $FVF<next>)
; Declaring predicate trigger functions
(declare-fun List%trigger ($Snap $Ref) Bool)
; Declaring symbols related to program functions (from program analysis)
(declare-fun length ($Snap $Ref) Int)
(declare-fun length%limited ($Snap $Ref) Int)
(declare-fun length%stateless ($Ref) Bool)
(declare-fun length%precondition ($Snap $Ref) Bool)
(declare-fun itemAt ($Snap $Ref Int) Int)
(declare-fun itemAt%limited ($Snap $Ref Int) Int)
(declare-fun itemAt%stateless ($Ref Int) Bool)
(declare-fun itemAt%precondition ($Snap $Ref Int) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
(assert (forall ((s Seq<Int>)) (! (<= 0 (Seq_length s)) :pattern ((Seq_length s)) :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (! (=> (= (Seq_length s) 0) (= s (as Seq_empty Seq<Int>))) :pattern ((Seq_length s)) :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (! (= (Seq_length (Seq_singleton e)) 1) :pattern ((Seq_singleton e)) :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (not (= s1 (as Seq_empty Seq<Int>)))) (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1)))) :pattern ((Seq_length (Seq_append s0 s1))) :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (and (=> (= s0 (as Seq_empty Seq<Int>)) (= (Seq_append s0 s1) s1)) (=> (= s1 (as Seq_empty Seq<Int>)) (= (Seq_append s0 s1) s0))) :pattern ((Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (! (= (Seq_index (Seq_singleton e) 0) e) :pattern ((Seq_singleton e)) :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_add i j) (+ i j)) :pattern ((Seq_add i j)) :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_sub i j) (- i j)) :pattern ((Seq_sub i j)) :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (<= 0 n) (< n (Seq_length s0))))) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n))) :pattern ((Seq_index (Seq_append s0 s1) n)) :pattern ((Seq_index s0 n) (Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1)))))) (and (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s1 (Seq_sub n (Seq_length s0)))))) :pattern ((Seq_index (Seq_append s0 s1) n)) :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<Int>))) (and (not (= s1 (as Seq_empty Seq<Int>))) (and (not (= s0 (Seq_append s0 s1))) (and (not (= s1 (Seq_append s0 s1))) (and (<= 0 m) (< m (Seq_length s1))))))) (and (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m) (= (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0))) (Seq_index s1 m)))) :pattern ((Seq_index s1 m) (Seq_append s0 s1)) :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (= (Seq_length (Seq_update s i v)) (Seq_length s))) :pattern ((Seq_length (Seq_update s i v))) :pattern ((Seq_length s) (Seq_update s i v)) :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (! (=> (and (<= 0 n) (< n (Seq_length s))) (and (=> (= i n) (= (Seq_index (Seq_update s i v) n) v)) (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n))))) :pattern ((Seq_index (Seq_update s i v) n)) :pattern ((Seq_index s n) (Seq_update s i v)) :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n)) (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s))))) (=> (< n 0) (= (Seq_length (Seq_take s n)) 0))) :pattern ((Seq_length (Seq_take s n))) :pattern ((Seq_take s n) (Seq_length s)) :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (! (=> (and (<= 0 j) (and (< j n) (< j (Seq_length s)))) (= (Seq_index (Seq_take s n) j) (Seq_index s j))) :pattern ((Seq_index (Seq_take s n) j)) :pattern ((Seq_index s j) (Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n))) (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0)))) (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s)))) :pattern ((Seq_length (Seq_drop s n))) :pattern ((Seq_length s) (Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (! (=> (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n)))) (and (= (Seq_sub (Seq_add j n) n) j) (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n))))) :pattern ((Seq_index (Seq_drop s n) j)) :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (! (=> (and (< 0 n) (and (<= n i) (< i (Seq_length s)))) (and (= (Seq_add (Seq_sub i n) n) i) (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i)))) :pattern ((Seq_drop s n) (Seq_index s i)) :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_take (Seq_append s t) n) (Seq_take s n))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_take (Seq_append s t) n) (Seq_append s (Seq_take t (Seq_sub n (Seq_length s))))))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s)))))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (<= n 0) (= (Seq_take s n) (as Seq_empty Seq<Int>))) :pattern ((Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (<= n 0) (= (Seq_drop s n) s)) :pattern ((Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_take s n) s)) :pattern ((Seq_take s n)) :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty Seq<Int>))) :pattern ((Seq_drop s n)) :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (! (=> (Seq_contains s x) (and (<= 0 (Seq_skolem s x)) (and (< (Seq_skolem s x) (Seq_length s)) (= (Seq_index s (Seq_skolem s x)) x)))) :pattern ((Seq_contains s x)) :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (! (=> (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x))) (Seq_contains s x)) :pattern ((Seq_contains s x) (Seq_index s i)) :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (Seq_contains_trigger s (Seq_index s i))) :pattern ((Seq_index s i)) :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (! (or (and (= s0 s1) (Seq_equal s0 s1)) (or (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1))))) (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (and (= (Seq_length s0) (Seq_length s1)) (and (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0)) (and (<= 0 (Seq_skolem_diff s0 s1)) (and (< (Seq_skolem_diff s0 s1) (Seq_length s0)) (not (= (Seq_index s0 (Seq_skolem_diff s0 s1)) (Seq_index s1 (Seq_skolem_diff s0 s1)))))))))))) :pattern ((Seq_equal s0 s1)) :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (! (=> (Seq_equal a b) (= a b)) :pattern ((Seq_equal a b)) :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (! (= (Seq_contains (Seq_singleton x) y) (= x y)) :pattern ((Seq_contains (Seq_singleton x) y)) :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (! (and (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_))) (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0))) :pattern ((Seq_length (Seq_range min_ max))) :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (! (=> (and (<= 0 j) (< j (- max min_))) (= (Seq_index (Seq_range min_ max) j) (+ min_ j))) :pattern ((Seq_index (Seq_range min_ max) j)) :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (! (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max))) :pattern ((Seq_contains (Seq_range min_ max) v)) :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((s Seq<$Ref>)) (! (<= 0 (Seq_length s)) :pattern ((Seq_length s)) :qid |$Seq[Ref]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty Seq<$Ref>)) 0))
(assert (forall ((s Seq<$Ref>)) (! (=> (= (Seq_length s) 0) (= s (as Seq_empty Seq<$Ref>))) :pattern ((Seq_length s)) :qid |$Seq[Ref]_prog.Seq_length_zero|)))
(assert (forall ((e $Ref)) (! (= (Seq_length (Seq_singleton e)) 1) :pattern ((Seq_singleton e)) :qid |$Seq[Ref]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>)) (! (=> (and (not (= s0 (as Seq_empty Seq<$Ref>))) (not (= s1 (as Seq_empty Seq<$Ref>)))) (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1)))) :pattern ((Seq_length (Seq_append s0 s1))) :qid |$Seq[Ref]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>)) (! (and (=> (= s0 (as Seq_empty Seq<$Ref>)) (= (Seq_append s0 s1) s1)) (=> (= s1 (as Seq_empty Seq<$Ref>)) (= (Seq_append s0 s1) s0))) :pattern ((Seq_append s0 s1)) :qid |$Seq[Ref]_prog.Seq_append_empty|)))
(assert (forall ((e $Ref)) (! (= (Seq_index (Seq_singleton e) 0) e) :pattern ((Seq_singleton e)) :qid |$Seq[Ref]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_add i j) (+ i j)) :pattern ((Seq_add i j)) :qid |$Seq[Ref]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (! (= (Seq_sub i j) (- i j)) :pattern ((Seq_sub i j)) :qid |$Seq[Ref]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<$Ref>))) (and (not (= s1 (as Seq_empty Seq<$Ref>))) (and (<= 0 n) (< n (Seq_length s0))))) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n))) :pattern ((Seq_index (Seq_append s0 s1) n)) :pattern ((Seq_index s0 n) (Seq_append s0 s1)) :qid |$Seq[Ref]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>) (n Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<$Ref>))) (and (not (= s1 (as Seq_empty Seq<$Ref>))) (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1)))))) (and (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n) (= (Seq_index (Seq_append s0 s1) n) (Seq_index s1 (Seq_sub n (Seq_length s0)))))) :pattern ((Seq_index (Seq_append s0 s1) n)) :qid |$Seq[Ref]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>) (m Int)) (! (=> (and (not (= s0 (as Seq_empty Seq<$Ref>))) (and (not (= s1 (as Seq_empty Seq<$Ref>))) (and (not (= s0 (Seq_append s0 s1))) (and (not (= s1 (Seq_append s0 s1))) (and (<= 0 m) (< m (Seq_length s1))))))) (and (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m) (= (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0))) (Seq_index s1 m)))) :pattern ((Seq_index s1 m) (Seq_append s0 s1)) :qid |$Seq[Ref]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<$Ref>) (i Int) (v $Ref)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (= (Seq_length (Seq_update s i v)) (Seq_length s))) :pattern ((Seq_length (Seq_update s i v))) :pattern ((Seq_length s) (Seq_update s i v)) :qid |$Seq[Ref]_prog.Seq_update_length|)))
(assert (forall ((s Seq<$Ref>) (i Int) (v $Ref) (n Int)) (! (=> (and (<= 0 n) (< n (Seq_length s))) (and (=> (= i n) (= (Seq_index (Seq_update s i v) n) v)) (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n))))) :pattern ((Seq_index (Seq_update s i v) n)) :pattern ((Seq_index s n) (Seq_update s i v)) :qid |$Seq[Ref]_prog.Seq_update_index|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n)) (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s))))) (=> (< n 0) (= (Seq_length (Seq_take s n)) 0))) :pattern ((Seq_length (Seq_take s n))) :pattern ((Seq_take s n) (Seq_length s)) :qid |$Seq[Ref]_prog.Seq_take_length|)))
(assert (forall ((s Seq<$Ref>) (n Int) (j Int)) (! (=> (and (<= 0 j) (and (< j n) (< j (Seq_length s)))) (= (Seq_index (Seq_take s n) j) (Seq_index s j))) :pattern ((Seq_index (Seq_take s n) j)) :pattern ((Seq_index s j) (Seq_take s n)) :qid |$Seq[Ref]_prog.Seq_take_index|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (and (=> (<= 0 n) (and (=> (<= n (Seq_length s)) (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n))) (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0)))) (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s)))) :pattern ((Seq_length (Seq_drop s n))) :pattern ((Seq_length s) (Seq_drop s n)) :qid |$Seq[Ref]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<$Ref>) (n Int) (j Int)) (! (=> (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n)))) (and (= (Seq_sub (Seq_add j n) n) j) (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n))))) :pattern ((Seq_index (Seq_drop s n) j)) :qid |$Seq[Ref]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<$Ref>) (n Int) (i Int)) (! (=> (and (< 0 n) (and (<= n i) (< i (Seq_length s)))) (and (= (Seq_add (Seq_sub i n) n) i) (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i)))) :pattern ((Seq_drop s n) (Seq_index s i)) :qid |$Seq[Ref]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<$Ref>) (t Seq<$Ref>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_take (Seq_append s t) n) (Seq_take s n))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Ref]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<$Ref>) (t Seq<$Ref>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_take (Seq_append s t) n) (Seq_append s (Seq_take t (Seq_sub n (Seq_length s))))))) :pattern ((Seq_take (Seq_append s t) n)) :qid |$Seq[Ref]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<$Ref>) (t Seq<$Ref>) (n Int)) (! (=> (and (< 0 n) (<= n (Seq_length s))) (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Ref]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<$Ref>) (t Seq<$Ref>) (n Int)) (! (=> (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t))))) (and (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n) (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s)))))) :pattern ((Seq_drop (Seq_append s t) n)) :qid |$Seq[Ref]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (=> (<= n 0) (= (Seq_take s n) (as Seq_empty Seq<$Ref>))) :pattern ((Seq_take s n)) :qid |$Seq[Ref]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (=> (<= n 0) (= (Seq_drop s n) s)) :pattern ((Seq_drop s n)) :qid |$Seq[Ref]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_take s n) s)) :pattern ((Seq_take s n)) :qid |$Seq[Ref]_prog.Seq_take_all|)))
(assert (forall ((s Seq<$Ref>) (n Int)) (! (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty Seq<$Ref>))) :pattern ((Seq_drop s n)) :qid |$Seq[Ref]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<$Ref>) (x $Ref)) (! (=> (Seq_contains s x) (and (<= 0 (Seq_skolem s x)) (and (< (Seq_skolem s x) (Seq_length s)) (= (Seq_index s (Seq_skolem s x)) x)))) :pattern ((Seq_contains s x)) :qid |$Seq[Ref]_prog.Seq_contains1|)))
(assert (forall ((s Seq<$Ref>) (x $Ref) (i Int)) (! (=> (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x))) (Seq_contains s x)) :pattern ((Seq_contains s x) (Seq_index s i)) :qid |$Seq[Ref]_prog.Seq_contains2|)))
(assert (forall ((s Seq<$Ref>) (i Int)) (! (=> (and (<= 0 i) (< i (Seq_length s))) (Seq_contains_trigger s (Seq_index s i))) :pattern ((Seq_index s i)) :qid |$Seq[Ref]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<$Ref>) (s1 Seq<$Ref>)) (! (or (and (= s0 s1) (Seq_equal s0 s1)) (or (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1))))) (and (not (= s0 s1)) (and (not (Seq_equal s0 s1)) (and (= (Seq_length s0) (Seq_length s1)) (and (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0)) (and (<= 0 (Seq_skolem_diff s0 s1)) (and (< (Seq_skolem_diff s0 s1) (Seq_length s0)) (not (= (Seq_index s0 (Seq_skolem_diff s0 s1)) (Seq_index s1 (Seq_skolem_diff s0 s1)))))))))))) :pattern ((Seq_equal s0 s1)) :qid |$Seq[Ref]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<$Ref>) (b Seq<$Ref>)) (! (=> (Seq_equal a b) (= a b)) :pattern ((Seq_equal a b)) :qid |$Seq[Ref]_prog.Seq_equal_ext|)))
(assert (forall ((x $Ref) (y $Ref)) (! (= (Seq_contains (Seq_singleton x) y) (= x y)) :pattern ((Seq_contains (Seq_singleton x) y)) :qid |$Seq[Ref]_prog.Seq_singleton_contains|)))
(assert (forall ((s Set<Int>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Int]_prog.Set_card_nonneg|)))
(assert (forall ((o Int)) (! (not (Set_in o (as Set_empty Set<Int>))) :pattern ((Set_in o (as Set_empty Set<Int>))) :qid |$Set[Int]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Int>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<Int>))) (=> (not (= (Set_card s) 0)) (exists ((x Int)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Int]_prog.Set_card_zero|)))
(assert (forall ((r Int)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Int]_prog.Set_singleton_contains1|)))
(assert (forall ((r Int) (o Int)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Int]_prog.Set_singleton_contains2|)))
(assert (forall ((r Int)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Int]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Int>) (x Int) (o Int)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Int]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Int>) (x Int)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Int]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Int>) (x Int) (y Int)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Int]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Int>) (x Int)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Int]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Int>) (x Int)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Int]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Int]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Int]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Int]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Int]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Int]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Int]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Int]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Int]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Int]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Int]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Int]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Int]_prog.Set_diff_card|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (= (Set_subset a b) (forall ((o Int)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Int]_prog.Set_subset_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Int]_prog.Set_equal_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Int]_prog.Set_equal_ext|)))
(assert (forall ((s Set<$Ref>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Ref]_prog.Set_card_nonneg|)))
(assert (forall ((o $Ref)) (! (not (Set_in o (as Set_empty Set<$Ref>))) :pattern ((Set_in o (as Set_empty Set<$Ref>))) :qid |$Set[Ref]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Ref>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<$Ref>))) (=> (not (= (Set_card s) 0)) (exists ((x $Ref)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Ref]_prog.Set_card_zero|)))
(assert (forall ((r $Ref)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Ref]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Ref) (o $Ref)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Ref]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Ref)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Ref]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (o $Ref)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Ref]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Ref>) (x $Ref) (y $Ref)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Ref]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Ref>) (x $Ref)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Ref]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Ref]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Ref]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Ref]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Ref]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Ref]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Ref]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Ref]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Ref]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Ref]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (o $Ref)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Ref]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>) (y $Ref)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Ref]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Ref]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (= (Set_subset a b) (forall ((o $Ref)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Ref]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Ref]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Ref>) (b Set<$Ref>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Ref]_prog.Set_equal_ext|)))
(assert (forall ((s Set<$Snap>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Snap]_prog.Set_card_nonneg|)))
(assert (forall ((o $Snap)) (! (not (Set_in o (as Set_empty Set<$Snap>))) :pattern ((Set_in o (as Set_empty Set<$Snap>))) :qid |$Set[Snap]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<$Snap>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<$Snap>))) (=> (not (= (Set_card s) 0)) (exists ((x $Snap)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Snap]_prog.Set_card_zero|)))
(assert (forall ((r $Snap)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Snap]_prog.Set_singleton_contains1|)))
(assert (forall ((r $Snap) (o $Snap)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Snap]_prog.Set_singleton_contains2|)))
(assert (forall ((r $Snap)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Snap]_prog.Set_singleton_card|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (o $Snap)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Snap]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<$Snap>) (x $Snap) (y $Snap)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Snap]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<$Snap>) (x $Snap)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Snap]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Snap]_prog.Set_union_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Snap]_prog.Set_union_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Snap]_prog.Set_union_contains3|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Snap]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Snap]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Snap]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Snap]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Snap]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Snap]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (o $Snap)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Snap]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>) (y $Snap)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Snap]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Snap]_prog.Set_diff_card|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (= (Set_subset a b) (forall ((o $Snap)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Snap]_prog.Set_subset_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Snap]_prog.Set_equal_def|)))
(assert (forall ((a Set<$Snap>) (b Set<$Snap>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Snap]_prog.Set_equal_ext|)))
(assert (forall ((s Set<Seq<Int>>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Seq[Int]]_prog.Set_card_nonneg|)))
(assert (forall ((o Seq<Int>)) (! (not (Set_in o (as Set_empty Set<Seq<Int>>))) :pattern ((Set_in o (as Set_empty Set<Seq<Int>>))) :qid |$Set[Seq[Int]]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Seq<Int>>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<Seq<Int>>))) (=> (not (= (Set_card s) 0)) (exists ((x Seq<Int>)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Seq[Int]]_prog.Set_card_zero|)))
(assert (forall ((r Seq<Int>)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Seq[Int]]_prog.Set_singleton_contains1|)))
(assert (forall ((r Seq<Int>) (o Seq<Int>)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Seq[Int]]_prog.Set_singleton_contains2|)))
(assert (forall ((r Seq<Int>)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Seq[Int]]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Seq<Int>>) (x Seq<Int>) (o Seq<Int>)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Seq[Int]]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Seq<Int>>) (x Seq<Int>)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Seq[Int]]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Seq<Int>>) (x Seq<Int>) (y Seq<Int>)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Seq[Int]]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Seq<Int>>) (x Seq<Int>)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Seq[Int]]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Seq<Int>>) (x Seq<Int>)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Seq[Int]]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (o Seq<Int>)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Seq[Int]]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (y Seq<Int>)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Seq[Int]]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (y Seq<Int>)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Seq[Int]]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (o Seq<Int>)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Seq[Int]]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Seq[Int]]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Seq[Int]]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Seq[Int]]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Seq[Int]]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Seq[Int]]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (o Seq<Int>)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Seq[Int]]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>) (y Seq<Int>)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Seq[Int]]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Seq[Int]]_prog.Set_diff_card|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (= (Set_subset a b) (forall ((o Seq<Int>)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Seq[Int]]_prog.Set_subset_def|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Seq[Int]]_prog.Set_equal_def|)))
(assert (forall ((a Set<Seq<Int>>) (b Set<Seq<Int>>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Seq[Int]]_prog.Set_equal_ext|)))
(assert (forall ((s Set<Seq<$Ref>>)) (! (<= 0 (Set_card s)) :pattern ((Set_card s)) :qid |$Set[Seq[Ref]]_prog.Set_card_nonneg|)))
(assert (forall ((o Seq<$Ref>)) (! (not (Set_in o (as Set_empty Set<Seq<$Ref>>))) :pattern ((Set_in o (as Set_empty Set<Seq<$Ref>>))) :qid |$Set[Seq[Ref]]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Seq<$Ref>>)) (! (and (=> (= (Set_card s) 0) (= s (as Set_empty Set<Seq<$Ref>>))) (=> (not (= (Set_card s) 0)) (exists ((x Seq<$Ref>)) (Set_in x s)))) :pattern ((Set_card s)) :qid |$Set[Seq[Ref]]_prog.Set_card_zero|)))
(assert (forall ((r Seq<$Ref>)) (! (Set_in r (Set_singleton r)) :pattern ((Set_singleton r)) :qid |$Set[Seq[Ref]]_prog.Set_singleton_contains1|)))
(assert (forall ((r Seq<$Ref>) (o Seq<$Ref>)) (! (= (Set_in o (Set_singleton r)) (= r o)) :pattern ((Set_in o (Set_singleton r))) :qid |$Set[Seq[Ref]]_prog.Set_singleton_contains2|)))
(assert (forall ((r Seq<$Ref>)) (! (= (Set_card (Set_singleton r)) 1) :pattern ((Set_card (Set_singleton r))) :qid |$Set[Seq[Ref]]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Seq<$Ref>>) (x Seq<$Ref>) (o Seq<$Ref>)) (! (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a))) :pattern ((Set_in o (Set_unionone a x))) :qid |$Set[Seq[Ref]]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Seq<$Ref>>) (x Seq<$Ref>)) (! (Set_in x (Set_unionone a x)) :pattern ((Set_unionone a x)) :qid |$Set[Seq[Ref]]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Seq<$Ref>>) (x Seq<$Ref>) (y Seq<$Ref>)) (! (=> (Set_in y a) (Set_in y (Set_unionone a x))) :pattern ((Set_unionone a x) (Set_in y a)) :qid |$Set[Seq[Ref]]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Seq<$Ref>>) (x Seq<$Ref>)) (! (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Seq[Ref]]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Seq<$Ref>>) (x Seq<$Ref>)) (! (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1))) :pattern ((Set_card (Set_unionone a x))) :qid |$Set[Seq[Ref]]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (o Seq<$Ref>)) (! (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_union a b))) :qid |$Set[Seq[Ref]]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (y Seq<$Ref>)) (! (=> (Set_in y a) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y a)) :qid |$Set[Seq[Ref]]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (y Seq<$Ref>)) (! (=> (Set_in y b) (Set_in y (Set_union a b))) :pattern ((Set_union a b) (Set_in y b)) :qid |$Set[Seq[Ref]]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (o Seq<$Ref>)) (! (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b))) :pattern ((Set_in o (Set_intersection a b))) :pattern ((Set_intersection a b) (Set_in o a)) :pattern ((Set_intersection a b) (Set_in o b)) :qid |$Set[Seq[Ref]]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (Set_union (Set_union a b) b) (Set_union a b)) :pattern ((Set_union (Set_union a b) b)) :qid |$Set[Seq[Ref]]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (Set_union a (Set_union a b)) (Set_union a b)) :pattern ((Set_union a (Set_union a b))) :qid |$Set[Seq[Ref]]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b)) :pattern ((Set_intersection (Set_intersection a b) b)) :qid |$Set[Seq[Ref]]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b)) :pattern ((Set_intersection a (Set_intersection a b))) :qid |$Set[Seq[Ref]]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b))) (+ (Set_card a) (Set_card b))) :pattern ((Set_card (Set_union a b))) :pattern ((Set_card (Set_intersection a b))) :qid |$Set[Seq[Ref]]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (o Seq<$Ref>)) (! (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b)))) :pattern ((Set_in o (Set_difference a b))) :pattern ((Set_difference a b) (Set_in o a)) :qid |$Set[Seq[Ref]]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>) (y Seq<$Ref>)) (! (=> (Set_in y b) (not (Set_in y (Set_difference a b)))) :pattern ((Set_difference a b) (Set_in y b)) :qid |$Set[Seq[Ref]]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (and (= (+ (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a))) (Set_card (Set_intersection a b))) (Set_card (Set_union a b))) (= (Set_card (Set_difference a b)) (- (Set_card a) (Set_card (Set_intersection a b))))) :pattern ((Set_card (Set_difference a b))) :qid |$Set[Seq[Ref]]_prog.Set_diff_card|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (= (Set_subset a b) (forall ((o Seq<$Ref>)) (! (=> (Set_in o a) (Set_in o b)) :pattern ((Set_in o a)) :pattern ((Set_in o b))))) :pattern ((Set_subset a b)) :qid |$Set[Seq[Ref]]_prog.Set_subset_def|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (or (and (Set_equal a b) (= a b)) (and (not (Set_equal a b)) (and (not (= a b)) (and (= (Set_skolem_diff a b) (Set_skolem_diff b a)) (not (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b))))))) :pattern ((Set_equal a b)) :qid |$Set[Seq[Ref]]_prog.Set_equal_def|)))
(assert (forall ((a Set<Seq<$Ref>>) (b Set<Seq<$Ref>>)) (! (=> (Set_equal a b) (= a b)) :pattern ((Set_equal a b)) :qid |$Set[Seq[Ref]]_prog.Set_equal_ext|)))
; /field_value_functions_axioms.smt2 [nodes: Seq[Ref]]
(assert (forall ((vs $FVF<nodes>) (ws $FVF<nodes>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_nodes vs) ($FVF.domain_nodes ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_nodes vs))
            (= ($FVF.lookup_nodes vs x) ($FVF.lookup_nodes ws x)))
          :pattern (($FVF.lookup_nodes vs x) ($FVF.lookup_nodes ws x))
          :qid |qp.$FVF<nodes>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<nodes>To$Snap vs) ($FVF.has_domain_nodes vs)
              ($SortWrappers.$FVF<nodes>To$Snap ws) ($FVF.has_domain_nodes ws)
              )
    :qid |qp.$FVF<nodes>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_nodes pm r))
    :pattern (($FVF.perm_nodes pm r))
    :qid |qp.$FVF<nodes>-validvar|)))
(assert (forall ((r $Ref) (f Seq<$Ref>)) (!
    (= ($FVF.loc_nodes f r) true)
    :pattern (($FVF.loc_nodes f r))
    :qid |qp.$FVF<nodes>-loc|)))
; /field_value_functions_axioms.smt2 [val: Int]
(assert (forall ((vs $FVF<val>) (ws $FVF<val>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_val vs) ($FVF.domain_val ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_val vs))
            (= ($FVF.lookup_val vs x) ($FVF.lookup_val ws x)))
          :pattern (($FVF.lookup_val vs x) ($FVF.lookup_val ws x))
          :qid |qp.$FVF<val>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<val>To$Snap vs) ($FVF.has_domain_val vs)
              ($SortWrappers.$FVF<val>To$Snap ws) ($FVF.has_domain_val ws)
              )
    :qid |qp.$FVF<val>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_val pm r))
    :pattern (($FVF.perm_val pm r))
    :qid |qp.$FVF<val>-validvar|)))
(assert (forall ((r $Ref) (f Int)) (!
    (= ($FVF.loc_val f r) true)
    :pattern (($FVF.loc_val f r))
    :qid |qp.$FVF<val>-loc|)))
; /field_value_functions_axioms.smt2 [next: Ref]
(assert (forall ((vs $FVF<next>) (ws $FVF<next>)) (!
    (=>
      (and
        (Set_equal ($FVF.domain_next vs) ($FVF.domain_next ws))
        (forall ((x $Ref)) (!
          (=>
            (Set_in x ($FVF.domain_next vs))
            (= ($FVF.lookup_next vs x) ($FVF.lookup_next ws x)))
          :pattern (($FVF.lookup_next vs x) ($FVF.lookup_next ws x))
          :qid |qp.$FVF<next>-eq-inner|
          )))
      (= vs ws))
    :pattern (($SortWrappers.$FVF<next>To$Snap vs) ($FVF.has_domain_next vs)
              ($SortWrappers.$FVF<next>To$Snap ws) ($FVF.has_domain_next ws)
              )
    :qid |qp.$FVF<next>-eq-outer|
    )))
(assert (forall ((r $Ref) (pm $FPM)) (!
    ($Perm.isValidVar ($FVF.perm_next pm r))
    :pattern (($FVF.perm_next pm r))
    :qid |qp.$FVF<next>-validvar|)))
(assert (forall ((r $Ref) (f $Ref)) (!
    (= ($FVF.loc_next f r) true)
    :pattern (($FVF.loc_next f r))
    :qid |qp.$FVF<next>-loc|)))
; State saturation: after prelude
(set-option :rlimit 1000000)
(check-sat)
; unknown
(declare-fun this@0@main () $Ref)
(declare-fun result@1@main () Int)
(set-option :rlimit 0)
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@0@main $Ref)) (! (= (length%limited s@$ this@0@main) (length s@$ this@0@main)) :pattern ((length s@$ this@0@main)) :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref)) (! (length%stateless this@0@main) :pattern ((length%limited s@$ this@0@main)) :qid |quant-u-1|)))
(push) ; 1
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(List(this), write) in |this.nodes|)
(set-option :rlimit 0)
(push) ; 2
(assert (List%trigger s@$ this@0@main))
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (not (= this@0@main $Ref.null)))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] (forall i: Int, j: Int :: { this.nodes[i], this.nodes[j] } (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j])
(declare-const i@5@main Int)
(declare-const j@6@main Int)
(push) ; 3
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j]
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j)
; [eval] (i in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 4
(push) ; 5
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main)))
(pop) ; 5
(push) ; 5
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main))
; [eval] (j in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 6
(push) ; 7
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main)))
(pop) ; 7
(push) ; 7
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main))
; [eval] i != j
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main)))))
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main))))
(push) ; 4
(push) ; 5
(assert (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))))
; [eval] this.nodes[i] != this.nodes[j]
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@5@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< i@5@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[j]
(push) ; 6
(assert (not (>= j@6@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< j@6@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))))
; Joined path conditions
(assert (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main))))))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@5@main Int) (j@6@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)))
(assert (forall ((i@5@main Int) (j@6@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)))
(assert (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))))
(declare-const i@7@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@7@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@7@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@7@main) (not (<= 0 i@7@main))))
(assert (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@7@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@8@main ($Snap $Ref $Ref) Int)
(declare-fun img@9@main ($Snap $Ref $Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (or (<= 0 i@7@main) (not (<= 0 i@7@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-aux|)))
(push) ; 3
(assert (not (forall ((i1@7@main Int) (i2@7@main Int)) (! (=> (and (and (<= 0 i1@7@main) (< i1@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (<= 0 i2@7@main) (< i2@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i1@7@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i2@7@main))) (= i1@7@main i2@7@main)) :qid |val-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@8@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) i@7@main) (img@9@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@9@main s@$ this@0@main r) (and (<= 0 (inv@8@main s@$ this@0@main r)) (< (inv@8@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@8@main s@$ this@0@main r)) r)) :pattern ((inv@8@main s@$ this@0@main r)) :qid |val-fctOfInv|)))
(assert (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-permImpliesNonNull|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))))))
(declare-const i@10@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@10@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@10@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@10@main) (not (<= 0 i@10@main))))
(assert (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@10@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@11@main ($Snap $Ref $Ref) Int)
(declare-fun img@12@main ($Snap $Ref $Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (or (<= 0 i@10@main) (not (<= 0 i@10@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-aux|)))
(push) ; 3
(assert (not (forall ((i1@10@main Int) (i2@10@main Int)) (! (=> (and (and (<= 0 i1@10@main) (< i1@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (<= 0 i2@10@main) (< i2@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i1@10@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i2@10@main))) (= i1@10@main i2@10@main)) :qid |next-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) i@10@main) (img@12@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@11@main s@$ this@0@main r)) r)) :pattern ((inv@11@main s@$ this@0@main r)) :qid |next-fctOfInv|)))
(assert (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-permImpliesNonNull|)))
(declare-fun sm@13@main ($Snap $Ref) $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmValDef2|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef3|)))
(assert (forall ((r $Ref)) (! (=> (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) r) r)) :pattern ((inv@11@main s@$ this@0@main r)) :qid |quant-u-6|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@14@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@14@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@14@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@14@main) (not (<= 0 i@14@main))))
(push) ; 4
(push) ; 5
(assert (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@14@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))))
(pop) ; 7
(push) ; 7
(assert (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 8
(push) ; 9
(assert (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@14@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))
(push) ; 10
(assert (not (and (img@12@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (<= 0 (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (< (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 10
(assert (not (>= (+ i@14@main 1) 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(assert (not (< (+ i@14@main 1) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(push) ; 9
(assert (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@14@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))
(push) ; 10
(assert (not (and (img@12@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (<= 0 (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (< (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))))
; Joined path conditions
(assert (=> (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))))
(assert (or (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (=> (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (=> (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (or (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))))
(assert (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))))
(pop) ; 5
(push) ; 5
(assert (not (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (=> (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (=> (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (or (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))))))
; Joined path conditions
(assert (or (not (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))))
(declare-fun sm@15@main ($Snap $Ref) $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@15@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmValDef4|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef5|)))
; [eval] this.nodes[i]
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@15@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmValDef4|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef5|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@14@main Int)) (! (and (or (<= 0 i@14@main) (not (<= 0 i@14@main))) (=> (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (=> (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (=> (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (or (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))))) (or (not (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@15@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(assert (forall ((i@14@main Int)) (! (=> (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (ite (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (+ i@14@main 1))) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@15@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|)))
; [eval] |this.nodes|
(pop) ; 2
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (and (img@9@main s@$ this@0@main r) (and (<= 0 (inv@8@main s@$ this@0@main r)) (< (inv@8@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@8@main s@$ this@0@main r)) r)) :pattern ((inv@8@main s@$ this@0@main r)) :qid |val-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@11@main s@$ this@0@main r)) r)) :pattern ((inv@11@main s@$ this@0@main r)) :qid |next-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmValDef2|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef3|)))
(assert (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@15@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmValDef4|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef5|)))
(assert (and (List%trigger s@$ this@0@main) (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))) (not (= this@0@main $Ref.null)) (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))) (= ($Snap.first ($Snap.second s@$)) $Snap.unit) (forall ((i@5@main Int) (j@6@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)) (forall ((i@5@main Int) (j@6@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) i@5@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))) j@6@main) (not (= i@5@main j@6@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@5@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) j@6@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)) (= ($Snap.second ($Snap.second s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second s@$))) ($Snap.second ($Snap.second ($Snap.second s@$))))) (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (or (<= 0 i@7@main) (not (<= 0 i@7@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-aux|)) (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@8@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) i@7@main) (img@9@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-invOfFct|)) (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-permImpliesNonNull|)) (= ($Snap.second ($Snap.second ($Snap.second s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))))) (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (or (<= 0 i@10@main) (not (<= 0 i@10@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-aux|)) (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) i@10@main) (img@12@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-invOfFct|)) (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-permImpliesNonNull|)) (forall ((r $Ref)) (! (=> (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) r) r)) :pattern ((inv@11@main s@$ this@0@main r)) :qid |quant-u-6|)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit) (forall ((i@14@main Int)) (! (and (or (<= 0 i@14@main) (not (<= 0 i@14@main))) (=> (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (and (=> (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (=> (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) (or (not (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))) (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)))))) (or (not (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@15@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)) (forall ((i@14@main Int)) (! (=> (and (<= 0 i@14@main) (< i@14@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (ite (< i@14@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))) 1)) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (+ i@14@main 1))) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@15@main s@$ this@0@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@14@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(assert (= result@1@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@0@main $Ref)) (! (and (forall ((i@7@main Int)) (! (=> (and (<= 0 i@7@main) (< i@7@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@8@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) i@7@main) (img@9@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@7@main)) :qid |val-invOfFct|)) (forall ((r $Ref)) (! (=> (and (img@9@main s@$ this@0@main r) (and (<= 0 (inv@8@main s@$ this@0@main r)) (< (inv@8@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@8@main s@$ this@0@main r)) r)) :pattern ((inv@8@main s@$ this@0@main r)) :qid |val-fctOfInv|)) (forall ((i@10@main Int)) (! (=> (and (<= 0 i@10@main) (< i@10@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$))))) (and (= (inv@11@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) i@10@main) (img@12@main s@$ this@0@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) i@10@main)) :qid |next-invOfFct|)) (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)) (inv@11@main s@$ this@0@main r)) r)) :pattern ((inv@11@main s@$ this@0@main r)) :qid |next-fctOfInv|)) (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@13@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmValDef2|)) (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@13@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef3|)) (forall ((r $Ref)) (! (=> (and (img@12@main s@$ this@0@main r) (and (<= 0 (inv@11@main s@$ this@0@main r)) (< (inv@11@main s@$ this@0@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) (= ($FVF.lookup_next (sm@15@main s@$ this@0@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r))) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmValDef4|)) (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))) r) r) :pattern (($FVF.lookup_next (sm@15@main s@$ this@0@main) r)) :qid |qp.psmResTrgDef5|)) (=> (length%precondition s@$ this@0@main) (= (length s@$ this@0@main) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first s@$)))))) :pattern ((length s@$ this@0@main)) :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (this@0@main $Ref)) (! true :pattern ((length s@$ this@0@main)) :qid |quant-u-8|)))
(declare-fun this@2@main () $Ref)
(declare-fun index@3@main () Int)
(declare-fun result@4@main () Int)
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] 0 <= index
(assert (<= 0 index@3@main))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] index < length(this)
; [eval] length(this)
(push) ; 2
(assert (length%precondition ($Snap.first s@$) this@2@main))
(pop) ; 2
; Joined path conditions
(assert (length%precondition ($Snap.first s@$) this@2@main))
(assert (< index@3@main (length ($Snap.first s@$) this@2@main)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@2@main $Ref) (index@3@main Int)) (! (= (itemAt%limited s@$ this@2@main index@3@main) (itemAt s@$ this@2@main index@3@main)) :pattern ((itemAt s@$ this@2@main index@3@main)) :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (this@2@main $Ref) (index@3@main Int)) (! (itemAt%stateless this@2@main index@3@main) :pattern ((itemAt%limited s@$ this@2@main index@3@main)) :qid |quant-u-3|)))
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.second s@$) ($Snap.combine ($Snap.first ($Snap.second s@$)) ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (<= 0 index@3@main))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
(assert (length%precondition ($Snap.first s@$) this@2@main))
(assert (< index@3@main (length ($Snap.first s@$) this@2@main)))
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
; [eval] (unfolding acc(List(this), write) in this.nodes[index].val)
(set-option :rlimit 0)
(push) ; 2
(assert (List%trigger ($Snap.first s@$) this@2@main))
(assert (= ($Snap.first s@$) ($Snap.combine ($Snap.first ($Snap.first s@$)) ($Snap.second ($Snap.first s@$)))))
(assert (not (= this@2@main $Ref.null)))
(assert (= ($Snap.second ($Snap.first s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first s@$))) ($Snap.second ($Snap.second ($Snap.first s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.first s@$))) $Snap.unit))
; [eval] (forall i: Int, j: Int :: { this.nodes[i], this.nodes[j] } (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j])
(declare-const i@16@main Int)
(declare-const j@17@main Int)
(push) ; 3
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j]
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j)
; [eval] (i in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 4
(push) ; 5
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main)))
(pop) ; 5
(push) ; 5
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main))
; [eval] (j in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 6
(push) ; 7
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main)))
(pop) ; 7
(push) ; 7
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main))
; [eval] i != j
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main)))))
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main))))
(push) ; 4
(push) ; 5
(assert (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))))
; [eval] this.nodes[i] != this.nodes[j]
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@16@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< i@16@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[j]
(push) ; 6
(assert (not (>= j@17@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< j@17@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))))
; Joined path conditions
(assert (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main))))))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@16@main Int) (j@17@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)))
(assert (forall ((i@16@main Int) (j@17@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)))
(assert (= ($Snap.second ($Snap.second ($Snap.first s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))))
(declare-const i@18@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@18@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@18@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@18@main) (not (<= 0 i@18@main))))
(assert (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@18@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@19@main ($Snap $Ref Int $Ref) Int)
(declare-fun img@20@main ($Snap $Ref Int $Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (or (<= 0 i@18@main) (not (<= 0 i@18@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-aux|)))
(push) ; 3
(assert (not (forall ((i1@18@main Int) (i2@18@main Int)) (! (=> (and (and (<= 0 i1@18@main) (< i1@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (<= 0 i2@18@main) (< i2@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i1@18@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i2@18@main))) (= i1@18@main i2@18@main)) :qid |val-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@19@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) i@18@main) (img@20@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@20@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@19@main s@$ this@2@main index@3@main r)) (< (inv@19@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@19@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@19@main s@$ this@2@main index@3@main r)) :qid |val-fctOfInv|)))
(assert (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-permImpliesNonNull|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))))
(declare-const i@21@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@21@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@21@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@21@main) (not (<= 0 i@21@main))))
(assert (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@21@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@22@main ($Snap $Ref Int $Ref) Int)
(declare-fun img@23@main ($Snap $Ref Int $Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (or (<= 0 i@21@main) (not (<= 0 i@21@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-aux|)))
(push) ; 3
(assert (not (forall ((i1@21@main Int) (i2@21@main Int)) (! (=> (and (and (<= 0 i1@21@main) (< i1@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (<= 0 i2@21@main) (< i2@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i1@21@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i2@21@main))) (= i1@21@main i2@21@main)) :qid |next-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) i@21@main) (img@23@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@22@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@22@main s@$ this@2@main index@3@main r)) :qid |next-fctOfInv|)))
(assert (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-permImpliesNonNull|)))
(declare-fun sm@24@main ($Snap $Ref Int) $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef8|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef9|)))
(assert (forall ((r $Ref)) (! (=> (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r) r)) :pattern ((inv@22@main s@$ this@2@main index@3@main r)) :qid |quant-u-11|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@25@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@25@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@25@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@25@main) (not (<= 0 i@25@main))))
(push) ; 4
(push) ; 5
(assert (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@25@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))))
(pop) ; 7
(push) ; 7
(assert (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 8
(push) ; 9
(assert (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@25@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))
(push) ; 10
(assert (not (and (img@23@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (< (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 10
(assert (not (>= (+ i@25@main 1) 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(assert (not (< (+ i@25@main 1) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(push) ; 9
(assert (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@25@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))
(push) ; 10
(assert (not (and (img@23@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (< (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))))
; Joined path conditions
(assert (=> (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))))
(assert (or (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (=> (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (=> (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (or (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))))
(assert (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))))
(pop) ; 5
(push) ; 5
(assert (not (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (=> (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (=> (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (or (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))))))
; Joined path conditions
(assert (or (not (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))))
(declare-fun sm@26@main ($Snap $Ref Int) $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef10|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef11|)))
; [eval] this.nodes[i]
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef10|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef11|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@25@main Int)) (! (and (or (<= 0 i@25@main) (not (<= 0 i@25@main))) (=> (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (=> (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (=> (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (or (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))))) (or (not (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(assert (forall ((i@25@main Int)) (! (=> (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (ite (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (+ i@25@main 1))) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|)))
; [eval] this.nodes[index]
(push) ; 3
(assert (not (>= index@3@main 0)))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(push) ; 3
(assert (not (< index@3@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(declare-fun rcvr@27@main ($Snap $Ref Int) $Ref)
(push) ; 3
(assert (not (=> (= (rcvr@27@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main)) (and (img@20@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main)) (and (<= 0 (inv@19@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main))) (< (inv@19@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(pop) ; 2
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (and (img@20@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@19@main s@$ this@2@main index@3@main r)) (< (inv@19@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@19@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@19@main s@$ this@2@main index@3@main r)) :qid |val-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@22@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@22@main s@$ this@2@main index@3@main r)) :qid |next-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef8|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef9|)))
(assert (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef10|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef11|)))
(assert (and (List%trigger ($Snap.first s@$) this@2@main) (= ($Snap.first s@$) ($Snap.combine ($Snap.first ($Snap.first s@$)) ($Snap.second ($Snap.first s@$)))) (not (= this@2@main $Ref.null)) (= ($Snap.second ($Snap.first s@$)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first s@$))) ($Snap.second ($Snap.second ($Snap.first s@$))))) (= ($Snap.first ($Snap.second ($Snap.first s@$))) $Snap.unit) (forall ((i@16@main Int) (j@17@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)) (forall ((i@16@main Int) (j@17@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) i@16@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))) j@17@main) (not (= i@16@main j@17@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@16@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) j@17@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)) (= ($Snap.second ($Snap.second ($Snap.first s@$))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (or (<= 0 i@18@main) (not (<= 0 i@18@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-aux|)) (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@19@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) i@18@main) (img@20@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-invOfFct|)) (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-permImpliesNonNull|)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))))) (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (or (<= 0 i@21@main) (not (<= 0 i@21@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-aux|)) (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) i@21@main) (img@23@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-invOfFct|)) (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-permImpliesNonNull|)) (forall ((r $Ref)) (! (=> (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r) r)) :pattern ((inv@22@main s@$ this@2@main index@3@main r)) :qid |quant-u-11|)) (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$))))) $Snap.unit) (forall ((i@25@main Int)) (! (and (or (<= 0 i@25@main) (not (<= 0 i@25@main))) (=> (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (and (=> (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (=> (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) ($FVF.loc_next ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) (or (not (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))) (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)))))) (or (not (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)) (forall ((i@25@main Int)) (! (=> (and (<= 0 i@25@main) (< i@25@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (ite (< i@25@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))) 1)) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (+ i@25@main 1))) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@25@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(assert (= result@4@main ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (this@2@main $Ref) (index@3@main Int)) (! (and (forall ((i@18@main Int)) (! (=> (and (<= 0 i@18@main) (< i@18@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@19@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) i@18@main) (img@20@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@18@main)) :qid |val-invOfFct|)) (forall ((r $Ref)) (! (=> (and (img@20@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@19@main s@$ this@2@main index@3@main r)) (< (inv@19@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@19@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@19@main s@$ this@2@main index@3@main r)) :qid |val-fctOfInv|)) (forall ((i@21@main Int)) (! (=> (and (<= 0 i@21@main) (< i@21@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$)))))) (and (= (inv@22@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) i@21@main) (img@23@main s@$ this@2@main index@3@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) i@21@main)) :qid |next-invOfFct|)) (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) (inv@22@main s@$ this@2@main index@3@main r)) r)) :pattern ((inv@22@main s@$ this@2@main index@3@main r)) :qid |next-fctOfInv|)) (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef8|)) (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@24@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef9|)) (forall ((r $Ref)) (! (=> (and (img@23@main s@$ this@2@main index@3@main r) (and (<= 0 (inv@22@main s@$ this@2@main index@3@main r)) (< (inv@22@main s@$ this@2@main index@3@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))))))) (= ($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r))) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmValDef10|)) (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first s@$)))))) r) r) :pattern (($FVF.lookup_next (sm@26@main s@$ this@2@main index@3@main) r)) :qid |qp.psmResTrgDef11|)) (=> (itemAt%precondition s@$ this@2@main index@3@main) (= (itemAt s@$ this@2@main index@3@main) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first s@$))))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first s@$))) index@3@main))))) :pattern ((itemAt s@$ this@2@main index@3@main)) :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (this@2@main $Ref) (index@3@main Int)) (! true :pattern ((itemAt s@$ this@2@main index@3@main)) :qid |quant-u-13|)))
(declare-const predicate@28@main $Snap)
(declare-const this@29@main $Ref)
(push) ; 1
(assert (= predicate@28@main ($Snap.combine ($Snap.first predicate@28@main) ($Snap.second predicate@28@main))))
(assert (not (= this@29@main $Ref.null)))
(assert (= ($Snap.second predicate@28@main) ($Snap.combine ($Snap.first ($Snap.second predicate@28@main)) ($Snap.second ($Snap.second predicate@28@main)))))
(assert (= ($Snap.first ($Snap.second predicate@28@main)) $Snap.unit))
; [eval] (forall i: Int, j: Int :: { this.nodes[i], this.nodes[j] } (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j])
(declare-const i@30@main Int)
(declare-const j@31@main Int)
(push) ; 2
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j]
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j)
; [eval] (i in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 3
(push) ; 4
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main)))
(pop) ; 4
(push) ; 4
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main))
; [eval] (j in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 5
(push) ; 6
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main)))
(pop) ; 6
(push) ; 6
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main))
; [eval] i != j
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main)))))
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main))))
(push) ; 3
(push) ; 4
(assert (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))))
; [eval] this.nodes[i] != this.nodes[j]
; [eval] this.nodes[i]
(push) ; 5
(assert (not (>= i@30@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< i@30@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[j]
(push) ; 5
(assert (not (>= j@31@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(assert (not (< j@31@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
(assert (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))))
; Joined path conditions
(assert (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main))))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@30@main Int) (j@31@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@30@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) j@31@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)))
(assert (forall ((i@30@main Int) (j@31@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) i@30@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))) j@31@main) (not (= i@30@main j@31@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@30@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) j@31@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@30@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) j@31@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)))
(assert (= ($Snap.second ($Snap.second predicate@28@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second predicate@28@main))) ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))))
(declare-const i@32@main Int)
(push) ; 2
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@32@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@32@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@32@main) (not (<= 0 i@32@main))))
(assert (and (<= 0 i@32@main) (< i@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
; [eval] this.nodes[i]
(push) ; 3
(assert (not (>= i@32@main 0)))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(pop) ; 2
(declare-fun inv@33@main ($Ref) Int)
(declare-fun img@34@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@32@main Int)) (! (=> (and (<= 0 i@32@main) (< i@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (or (<= 0 i@32@main) (not (<= 0 i@32@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main)) :qid |val-aux|)))
(push) ; 2
(assert (not (forall ((i1@32@main Int) (i2@32@main Int)) (! (=> (and (and (<= 0 i1@32@main) (< i1@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (<= 0 i2@32@main) (< i2@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i1@32@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i2@32@main))) (= i1@32@main i2@32@main)) :qid |val-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@32@main Int)) (! (=> (and (<= 0 i@32@main) (< i@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (= (inv@33@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main)) i@32@main) (img@34@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main)) :qid |val-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@34@main r) (and (<= 0 (inv@33@main r)) (< (inv@33@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (inv@33@main r)) r)) :pattern ((inv@33@main r)) :qid |val-fctOfInv|)))
(assert (forall ((i@32@main Int)) (! (=> (and (<= 0 i@32@main) (< i@32@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@32@main)) :qid |val-permImpliesNonNull|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second predicate@28@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second predicate@28@main)))))))
(declare-const i@35@main Int)
(push) ; 2
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@35@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@35@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@35@main) (not (<= 0 i@35@main))))
(assert (and (<= 0 i@35@main) (< i@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
; [eval] this.nodes[i]
(push) ; 3
(assert (not (>= i@35@main 0)))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(pop) ; 2
(declare-fun inv@36@main ($Ref) Int)
(declare-fun img@37@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@35@main Int)) (! (=> (and (<= 0 i@35@main) (< i@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (or (<= 0 i@35@main) (not (<= 0 i@35@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main)) :qid |next-aux|)))
(push) ; 2
(assert (not (forall ((i1@35@main Int) (i2@35@main Int)) (! (=> (and (and (<= 0 i1@35@main) (< i1@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (<= 0 i2@35@main) (< i2@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i1@35@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i2@35@main))) (= i1@35@main i2@35@main)) :qid |next-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 2
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@35@main Int)) (! (=> (and (<= 0 i@35@main) (< i@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (= (inv@36@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main)) i@35@main) (img@37@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main)) :qid |next-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@37@main r) (and (<= 0 (inv@36@main r)) (< (inv@36@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (inv@36@main r)) r)) :pattern ((inv@36@main r)) :qid |next-fctOfInv|)))
(assert (forall ((i@35@main Int)) (! (=> (and (<= 0 i@35@main) (< i@35@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@35@main)) :qid |next-permImpliesNonNull|)))
(declare-const sm@38@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@37@main r) (and (<= 0 (inv@36@main r)) (< (inv@36@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (= ($FVF.lookup_next (as sm@38@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r))) :pattern (($FVF.lookup_next (as sm@38@main $FVF<next>) r)) :qid |qp.psmValDef14|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r) r) :pattern (($FVF.lookup_next (as sm@38@main $FVF<next>) r)) :qid |qp.psmResTrgDef15|)))
(assert (forall ((r $Ref)) (! (=> (and (<= 0 (inv@36@main r)) (< (inv@36@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) r) r)) :pattern ((inv@36@main r)) :qid |quant-u-16|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second predicate@28@main)))) $Snap.unit))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@39@main Int)
(push) ; 2
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 3
(push) ; 4
(assert (not (<= 0 i@39@main)))
(pop) ; 4
(push) ; 4
(assert (<= 0 i@39@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@39@main) (not (<= 0 i@39@main))))
(push) ; 3
(push) ; 4
(assert (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(push) ; 5
(assert (not (>= i@39@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(push) ; 5
(push) ; 6
(assert (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))))
(pop) ; 6
(push) ; 6
(assert (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 7
(push) ; 8
(assert (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(push) ; 9
(assert (not (>= i@39@main 0)))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))
(push) ; 9
(assert (not (and (img@37@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (and (<= 0 (inv@36@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (< (inv@36@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 9
(assert (not (>= (+ i@39@main 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(push) ; 9
(assert (not (< (+ i@39@main 1) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(pop) ; 8
(push) ; 8
(assert (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(push) ; 9
(assert (not (>= i@39@main 0)))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))
(push) ; 9
(assert (not (and (img@37@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (and (<= 0 (inv@36@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (< (inv@36@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (=> (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))))
; Joined path conditions
(assert (=> (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))))
(assert (or (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (and (=> (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (=> (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (or (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))))))
(assert (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))))
(pop) ; 4
(push) ; 4
(assert (not (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=> (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (and (=> (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (=> (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (or (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))))))
; Joined path conditions
(assert (or (not (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))))
(declare-const sm@40@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@37@main r) (and (<= 0 (inv@36@main r)) (< (inv@36@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (= ($FVF.lookup_next (as sm@40@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r))) :pattern (($FVF.lookup_next (as sm@40@main $FVF<next>) r)) :qid |qp.psmValDef16|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r) r) :pattern (($FVF.lookup_next (as sm@40@main $FVF<next>) r)) :qid |qp.psmResTrgDef17|)))
; [eval] this.nodes[i]
(pop) ; 2
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@37@main r) (and (<= 0 (inv@36@main r)) (< (inv@36@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (= ($FVF.lookup_next (as sm@40@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r))) :pattern (($FVF.lookup_next (as sm@40@main $FVF<next>) r)) :qid |qp.psmValDef16|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second predicate@28@main))))) r) r) :pattern (($FVF.lookup_next (as sm@40@main $FVF<next>) r)) :qid |qp.psmResTrgDef17|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@39@main Int)) (! (and (or (<= 0 i@39@main) (not (<= 0 i@39@main))) (=> (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (and (=> (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (=> (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) (or (not (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))) (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)))))) (or (not (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)))))) (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@40@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(assert (forall ((i@39@main Int)) (! (=> (and (<= 0 i@39@main) (< i@39@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (ite (< i@39@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main))) 1)) (= ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) (+ i@39@main 1))) (= ($FVF.lookup_next (as sm@38@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@40@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first predicate@28@main)) i@39@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|)))
(pop) ; 1
(declare-const this@41@main $Ref)
(declare-const elem@42@main Int)
(declare-const this@43@main $Ref)
(declare-const elem@44@main Int)
(push) ; 1
(declare-const snapshot@45@main $Snap)
(assert (= snapshot@45@main ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.second snapshot@45@main))))
(assert (= ($Snap.second snapshot@45@main) $Snap.unit))
; [eval] 0 < length(this) ==> itemAt(this, length(this) - 1) <= elem
; [eval] 0 < length(this)
; [eval] length(this)
(push) ; 2
(assert (length%precondition ($Snap.first snapshot@45@main) this@43@main))
(pop) ; 2
; Joined path conditions
(assert (length%precondition ($Snap.first snapshot@45@main) this@43@main))
(push) ; 2
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (< 0 (length ($Snap.first snapshot@45@main) this@43@main)))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (< 0 (length ($Snap.first snapshot@45@main) this@43@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (< 0 (length ($Snap.first snapshot@45@main) this@43@main)))
; [eval] itemAt(this, length(this) - 1) <= elem
; [eval] itemAt(this, length(this) - 1)
; [eval] length(this) - 1
; [eval] length(this)
(push) ; 4
(pop) ; 4
; Joined path conditions
(push) ; 4
; [eval] 0 <= index
(push) ; 5
(assert (not (<= 0 (- (length ($Snap.first snapshot@45@main) this@43@main) 1))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(assert (<= 0 (- (length ($Snap.first snapshot@45@main) this@43@main) 1)))
; [eval] index < length(this)
; [eval] length(this)
(push) ; 5
(pop) ; 5
; Joined path conditions
(push) ; 5
(assert (not (< (- (length ($Snap.first snapshot@45@main) this@43@main) 1) (length ($Snap.first snapshot@45@main) this@43@main))))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(assert (< (- (length ($Snap.first snapshot@45@main) this@43@main) 1) (length ($Snap.first snapshot@45@main) this@43@main)))
(assert (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@45@main) this@43@main) 1)))
(pop) ; 4
; Joined path conditions
(assert (<= 0 (- (length ($Snap.first snapshot@45@main) this@43@main) 1)))
(assert (and (< (- (length ($Snap.first snapshot@45@main) this@43@main) 1) (length ($Snap.first snapshot@45@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@45@main) this@43@main) 1))))
(pop) ; 3
(push) ; 3
(assert (not (< 0 (length ($Snap.first snapshot@45@main) this@43@main))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=> (< 0 (length ($Snap.first snapshot@45@main) this@43@main)) (and (< 0 (length ($Snap.first snapshot@45@main) this@43@main)) (<= 0 (- (length ($Snap.first snapshot@45@main) this@43@main) 1)) (< (- (length ($Snap.first snapshot@45@main) this@43@main) 1) (length ($Snap.first snapshot@45@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@45@main) this@43@main) 1)))))
; Joined path conditions
(assert (or (not (< 0 (length ($Snap.first snapshot@45@main) this@43@main))) (< 0 (length ($Snap.first snapshot@45@main) this@43@main))))
(assert (=> (< 0 (length ($Snap.first snapshot@45@main) this@43@main)) (<= (itemAt ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@45@main) this@43@main) 1)) elem@44@main)))
; State saturation: after contract
(set-option :rlimit 500000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const snapshot@46@main $Snap)
(assert (= snapshot@46@main ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.second snapshot@46@main))))
(assert (= ($Snap.second snapshot@46@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@46@main)) ($Snap.second ($Snap.second snapshot@46@main)))))
(assert (= ($Snap.first ($Snap.second snapshot@46@main)) $Snap.unit))
; [eval] length(this) == old(length(this)) + 1
; [eval] length(this)
(push) ; 3
(assert (length%precondition ($Snap.first snapshot@46@main) this@43@main))
(pop) ; 3
; Joined path conditions
(assert (length%precondition ($Snap.first snapshot@46@main) this@43@main))
; [eval] old(length(this)) + 1
; [eval] old(length(this))
; [eval] length(this)
(push) ; 3
(pop) ; 3
; Joined path conditions
(assert (= (length ($Snap.first snapshot@46@main) this@43@main) (+ (length ($Snap.first snapshot@45@main) this@43@main) 1)))
(assert (= ($Snap.second ($Snap.second snapshot@46@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second snapshot@46@main))) ($Snap.second ($Snap.second ($Snap.second snapshot@46@main))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second snapshot@46@main))) $Snap.unit))
; [eval] itemAt(this, length(this) - 1) == elem
; [eval] itemAt(this, length(this) - 1)
; [eval] length(this) - 1
; [eval] length(this)
(push) ; 3
(pop) ; 3
; Joined path conditions
(push) ; 3
; [eval] 0 <= index
(push) ; 4
(assert (not (<= 0 (- (length ($Snap.first snapshot@46@main) this@43@main) 1))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (<= 0 (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))
; [eval] index < length(this)
; [eval] length(this)
(push) ; 4
(pop) ; 4
; Joined path conditions
(push) ; 4
(assert (not (< (- (length ($Snap.first snapshot@46@main) this@43@main) 1) (length ($Snap.first snapshot@46@main) this@43@main))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (< (- (length ($Snap.first snapshot@46@main) this@43@main) 1) (length ($Snap.first snapshot@46@main) this@43@main)))
(assert (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))
(pop) ; 3
; Joined path conditions
(assert (<= 0 (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))
(assert (and (< (- (length ($Snap.first snapshot@46@main) this@43@main) 1) (length ($Snap.first snapshot@46@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))))
(assert (= (itemAt ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)) elem@44@main))
(assert (= ($Snap.second ($Snap.second ($Snap.second snapshot@46@main))) $Snap.unit))
; [eval] (forall i: Int :: { itemAt(this, i) } 0 <= i && i < length(this) - 1 ==> itemAt(this, i) == old(itemAt(this, i)))
(declare-const i@47@main Int)
(push) ; 3
; [eval] 0 <= i && i < length(this) - 1 ==> itemAt(this, i) == old(itemAt(this, i))
; [eval] 0 <= i && i < length(this) - 1
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@47@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@47@main))
; [eval] i < length(this) - 1
; [eval] length(this) - 1
; [eval] length(this)
(push) ; 6
(pop) ; 6
; Joined path conditions
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@47@main) (not (<= 0 i@47@main))))
(push) ; 4
(push) ; 5
(assert (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))))
; [eval] itemAt(this, i) == old(itemAt(this, i))
; [eval] itemAt(this, i)
(push) ; 6
; [eval] 0 <= index
; [eval] index < length(this)
; [eval] length(this)
(push) ; 7
(pop) ; 7
; Joined path conditions
(push) ; 7
(assert (not (< i@47@main (length ($Snap.first snapshot@46@main) this@43@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (< i@47@main (length ($Snap.first snapshot@46@main) this@43@main)))
(assert (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main))
(pop) ; 6
; Joined path conditions
(assert (and (< i@47@main (length ($Snap.first snapshot@46@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main)))
; [eval] old(itemAt(this, i))
; [eval] itemAt(this, i)
(push) ; 6
; [eval] 0 <= index
; [eval] index < length(this)
; [eval] length(this)
(push) ; 7
(pop) ; 7
; Joined path conditions
(push) ; 7
(assert (not (< i@47@main (length ($Snap.first snapshot@45@main) this@43@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (< i@47@main (length ($Snap.first snapshot@45@main) this@43@main)))
(assert (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main))
(pop) ; 6
; Joined path conditions
(assert (and (< i@47@main (length ($Snap.first snapshot@45@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main)))
(pop) ; 5
(push) ; 5
(assert (not (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))) (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)) (< i@47@main (length ($Snap.first snapshot@46@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main) (< i@47@main (length ($Snap.first snapshot@45@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main))))
; Joined path conditions
(assert (or (not (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))) (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@47@main Int)) (! (and (or (<= 0 i@47@main) (not (<= 0 i@47@main))) (=> (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))) (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)) (< i@47@main (length ($Snap.first snapshot@46@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main) (< i@47@main (length ($Snap.first snapshot@45@main) this@43@main)) (itemAt%precondition ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main))) (or (not (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1)))) (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))))) :pattern ((itemAt%limited ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@43@11@43@122-aux|)))
(assert (forall ((i@47@main Int)) (! (=> (and (<= 0 i@47@main) (< i@47@main (- (length ($Snap.first snapshot@46@main) this@43@main) 1))) (= (itemAt ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main) (itemAt ($Snap.combine ($Snap.first snapshot@45@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main))) :pattern ((itemAt%limited ($Snap.combine ($Snap.first snapshot@46@main) ($Snap.combine $Snap.unit $Snap.unit)) this@43@main i@47@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@43@11@43@122|)))
(pop) ; 2
(push) ; 2
; [exec]
; var n: Ref
(declare-const n@48@main $Ref)
; [exec]
; unfold acc(List(this), write)
(assert (= ($Snap.first snapshot@45@main) ($Snap.combine ($Snap.first ($Snap.first snapshot@45@main)) ($Snap.second ($Snap.first snapshot@45@main)))))
(assert (not (= this@43@main $Ref.null)))
(assert (= ($Snap.second ($Snap.first snapshot@45@main)) ($Snap.combine ($Snap.first ($Snap.second ($Snap.first snapshot@45@main))) ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))))
(assert (= ($Snap.first ($Snap.second ($Snap.first snapshot@45@main))) $Snap.unit))
; [eval] (forall i: Int, j: Int :: { this.nodes[i], this.nodes[j] } (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j])
(declare-const i@49@main Int)
(declare-const j@50@main Int)
(push) ; 3
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j]
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j)
; [eval] (i in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 4
(push) ; 5
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main)))
(pop) ; 5
(push) ; 5
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main))
; [eval] (j in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 6
(push) ; 7
(assert (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main)))
(pop) ; 7
(push) ; 7
(assert (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main))
; [eval] i != j
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main)))))
(assert (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main))))
(push) ; 4
(push) ; 5
(assert (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))))
; [eval] this.nodes[i] != this.nodes[j]
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@49@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< i@49@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[j]
(push) ; 6
(assert (not (>= j@50@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(assert (not (< j@50@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))))
; Joined path conditions
(assert (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main))))))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@49@main Int) (j@50@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main)))) (or (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (not (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main))))) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@49@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) j@50@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)))
(assert (forall ((i@49@main Int) (j@50@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) i@49@main) (and (Seq_contains (Seq_range 0 (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))) j@50@main) (not (= i@49@main j@50@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@49@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) j@50@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@49@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) j@50@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)))
(assert (= ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))) ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))))
(declare-const i@51@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@51@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@51@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@51@main) (not (<= 0 i@51@main))))
(assert (and (<= 0 i@51@main) (< i@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@51@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@52@main ($Ref) Int)
(declare-fun img@53@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@51@main Int)) (! (=> (and (<= 0 i@51@main) (< i@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (or (<= 0 i@51@main) (not (<= 0 i@51@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main)) :qid |val-aux|)))
(push) ; 3
(assert (not (forall ((i1@51@main Int) (i2@51@main Int)) (! (=> (and (and (<= 0 i1@51@main) (< i1@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (<= 0 i2@51@main) (< i2@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i1@51@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i2@51@main))) (= i1@51@main i2@51@main)) :qid |val-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@51@main Int)) (! (=> (and (<= 0 i@51@main) (< i@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (= (inv@52@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main)) i@51@main) (img@53@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main)) :qid |val-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (inv@52@main r)) r)) :pattern ((inv@52@main r)) :qid |val-fctOfInv|)))
(assert (forall ((i@51@main Int)) (! (=> (and (<= 0 i@51@main) (< i@51@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@51@main)) :qid |val-permImpliesNonNull|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))) ($Snap.combine ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))))))
(declare-const i@54@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@54@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@54@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@54@main) (not (<= 0 i@54@main))))
(assert (and (<= 0 i@54@main) (< i@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
; [eval] this.nodes[i]
(push) ; 4
(assert (not (>= i@54@main 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(pop) ; 3
(declare-fun inv@55@main ($Ref) Int)
(declare-fun img@56@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@54@main Int)) (! (=> (and (<= 0 i@54@main) (< i@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (or (<= 0 i@54@main) (not (<= 0 i@54@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main)) :qid |next-aux|)))
(push) ; 3
(assert (not (forall ((i1@54@main Int) (i2@54@main Int)) (! (=> (and (and (<= 0 i1@54@main) (< i1@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (<= 0 i2@54@main) (< i2@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i1@54@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i2@54@main))) (= i1@54@main i2@54@main)) :qid |next-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@54@main Int)) (! (=> (and (<= 0 i@54@main) (< i@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (= (inv@55@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main)) i@54@main) (img@56@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main)))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main)) :qid |next-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (inv@55@main r)) r)) :pattern ((inv@55@main r)) :qid |next-fctOfInv|)))
(assert (forall ((i@54@main Int)) (! (=> (and (<= 0 i@54@main) (< i@54@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main) $Ref.null))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@54@main)) :qid |next-permImpliesNonNull|)))
(declare-const sm@57@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@57@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@57@main $FVF<next>) r)) :qid |qp.psmValDef20|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) :pattern (($FVF.lookup_next (as sm@57@main $FVF<next>) r)) :qid |qp.psmResTrgDef21|)))
(assert (forall ((r $Ref)) (! (=> (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) r) r)) :pattern ((inv@55@main r)) :qid |quant-u-19|)))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) $Snap.unit))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@58@main Int)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@58@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@58@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@58@main) (not (<= 0 i@58@main))))
(push) ; 4
(push) ; 5
(assert (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@58@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(assert (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))))
(pop) ; 7
(push) ; 7
(assert (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 8
(push) ; 9
(assert (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@58@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))
(push) ; 10
(assert (not (and (img@56@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (and (<= 0 (inv@55@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (< (inv@55@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 10
(assert (not (>= (+ i@58@main 1) 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(push) ; 10
(assert (not (< (+ i@58@main 1) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(push) ; 9
(assert (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(push) ; 10
(assert (not (>= i@58@main 0)))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))
(push) ; 10
(assert (not (and (img@56@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (and (<= 0 (inv@55@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (< (inv@55@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))))
(check-sat)
; unsat
(pop) ; 10
; 0ms
; (get-info :all-statistics)
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=> (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))))
; Joined path conditions
(assert (=> (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))))
(assert (or (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (and (=> (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (=> (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (or (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(assert (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))))
(pop) ; 5
(push) ; 5
(assert (not (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=> (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (and (=> (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (=> (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (or (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))))))
; Joined path conditions
(assert (or (not (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))))
(declare-const sm@59@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@59@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@59@main $FVF<next>) r)) :qid |qp.psmValDef22|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) :pattern (($FVF.lookup_next (as sm@59@main $FVF<next>) r)) :qid |qp.psmResTrgDef23|)))
; [eval] this.nodes[i]
(pop) ; 3
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@59@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@59@main $FVF<next>) r)) :qid |qp.psmValDef22|)))
(assert (forall ((r $Ref)) (! ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) :pattern (($FVF.lookup_next (as sm@59@main $FVF<next>) r)) :qid |qp.psmResTrgDef23|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@58@main Int)) (! (and (or (<= 0 i@58@main) (not (<= 0 i@58@main))) (=> (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (=> (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (and (=> (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (=> (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) (or (not (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))) (or (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)))))) (or (not (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@59@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(assert (forall ((i@58@main Int)) (! (=> (and (<= 0 i@58@main) (< i@58@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (and (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (ite (< i@58@main (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (= ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (+ i@58@main 1))) (= ($FVF.lookup_next (as sm@57@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@59@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@58@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|)))
; State saturation: after unfold
(set-option :rlimit 400000)
(check-sat)
; unknown
(assert (List%trigger ($Snap.first snapshot@45@main) this@43@main))
; [exec]
; n := new()
(declare-const n@60@main $Ref)
(assert (not (= n@60@main $Ref.null)))
(assert (not (= n@60@main this@43@main)))
(assert (not (= n@60@main n@48@main)))
(assert (not (Seq_contains ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) n@60@main)))
; [exec]
; inhale acc(n.val, write) &&
;   (acc(n.next, write) &&
;   (forall i: Int ::
;     { this.nodes[i] }
;     0 <= i && i < |this.nodes| ==> this.nodes[i] != n))
(declare-const snapshot@61@main $Snap)
(assert (= snapshot@61@main ($Snap.combine ($Snap.first snapshot@61@main) ($Snap.second snapshot@61@main))))
(declare-const sm@62@main $FVF<val>)
(assert (= ($FVF.lookup_val (as sm@62@main $FVF<val>) n@60@main) ($SortWrappers.$SnapToInt ($Snap.first snapshot@61@main))))
(assert (= ($Snap.second snapshot@61@main) ($Snap.combine ($Snap.first ($Snap.second snapshot@61@main)) ($Snap.second ($Snap.second snapshot@61@main)))))
(declare-const sm@63@main $FVF<next>)
(assert (= ($FVF.lookup_next (as sm@63@main $FVF<next>) n@60@main) ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second snapshot@61@main)))))
(declare-const sm@64@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@64@main $FVF<next>) r) ($FVF.lookup_next (as sm@63@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@64@main $FVF<next>) r)) :qid |qp.psmValDef26|)))
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@64@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@64@main $FVF<next>) r)) :qid |qp.psmValDef27|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@63@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@64@main $FVF<next>) r)) :qid |qp.psmResTrgDef28|)))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@64@main $FVF<next>) n@60@main) n@60@main))
(assert (= ($Snap.second ($Snap.second snapshot@61@main)) $Snap.unit))
; [eval] (forall i: Int :: { this.nodes[i] } 0 <= i && i < |this.nodes| ==> this.nodes[i] != n)
(declare-const i@65@main Int)
(set-option :rlimit 0)
(push) ; 3
; [eval] 0 <= i && i < |this.nodes| ==> this.nodes[i] != n
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 4
(push) ; 5
(assert (not (<= 0 i@65@main)))
(pop) ; 5
(push) ; 5
(assert (<= 0 i@65@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@65@main) (not (<= 0 i@65@main))))
(push) ; 4
(push) ; 5
(assert (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
; [eval] this.nodes[i] != n
; [eval] this.nodes[i]
(push) ; 6
(assert (not (>= i@65@main 0)))
(check-sat)
; unsat
(pop) ; 6
; 0ms
; (get-info :all-statistics)
(pop) ; 5
(push) ; 5
(assert (not (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))))
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@65@main Int)) (! (and (or (<= 0 i@65@main) (not (<= 0 i@65@main))) (or (not (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@65@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@49@39@49@123-aux|)))
(assert (forall ((i@65@main Int)) (! (=> (and (<= 0 i@65@main) (< i@65@main (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@65@main) n@60@main))) :pattern ((Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@65@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@49@39@49@123|)))
; [exec]
; n.next := null
(declare-const sm@66@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@66@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@66@main $FVF<next>) r)) :qid |qp.psmValDef29|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@66@main $FVF<next>) r) ($FVF.lookup_next (as sm@63@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@66@main $FVF<next>) r)) :qid |qp.psmValDef30|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@63@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@66@main $FVF<next>) r)) :qid |qp.psmResTrgDef31|)))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@66@main $FVF<next>) n@60@main) n@60@main))
(define-fun pTaken@67@main ((r $Ref)) $Perm
  (ite (= r n@60@main) ($Perm.min (ite (= r n@60@main) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r n@60@main) $Perm.Write $Perm.No) (pTaken@67@main r)) $Perm.No) :qid |quant-u-20|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (= r n@60@main) (= (- $Perm.Write (pTaken@67@main r)) $Perm.No)) :qid |quant-u-21|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(declare-const sm@68@main $FVF<next>)
(assert (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) $Ref.null))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) n@60@main))
; [exec]
; n.val := elem
(define-fun pTaken@69@main ((r $Ref)) $Perm
  (ite (= r n@60@main) ($Perm.min (ite (= r n@60@main) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r n@60@main) $Perm.Write $Perm.No) (pTaken@69@main r)) $Perm.No) :qid |quant-u-23|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (= r n@60@main) (= (- $Perm.Write (pTaken@69@main r)) $Perm.No)) :qid |quant-u-24|))))
(check-sat)
; unsat
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(declare-const sm@70@main $FVF<val>)
(assert (= ($FVF.lookup_val (as sm@70@main $FVF<val>) n@60@main) elem@44@main))
; [eval] |this.nodes| > 0
; [eval] |this.nodes|
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (not (> (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 0))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 3
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 100000)
(assert (not (> (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 0)))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 3
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(assert (> (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 0))
; [exec]
; this.nodes[|this.nodes| - 1].next := n
; [eval] this.nodes[|this.nodes| - 1]
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 4
(assert (not (>= (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1) 0)))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(push) ; 4
(assert (not (< (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(declare-const sm@71@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_next (as sm@71@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@71@main $FVF<next>) r)) :qid |qp.psmValDef32|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@71@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@71@main $FVF<next>) r)) :qid |qp.psmValDef33|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@71@main $FVF<next>) r)) :qid |qp.psmResTrgDef34|)))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@71@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))
(define-fun pTaken@72@main ((r $Ref)) $Perm
  (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($Perm.min (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (pTaken@72@main r)) $Perm.No) :qid |quant-u-26|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (forall ((r $Ref)) (! (= (pTaken@72@main r) $Perm.No) :qid |quant-u-27|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (- $Perm.Write (pTaken@72@main r)) $Perm.No)) :qid |quant-u-28|))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(declare-const sm@73@main $FVF<next>)
(assert (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) n@60@main))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))
; [exec]
; this.nodes := this.nodes ++ Seq(n)
; [eval] this.nodes ++ Seq(n)
; [eval] Seq(n)
(assert (= (Seq_length (Seq_singleton n@60@main)) 1))
(declare-const nodes@74@main Seq<$Ref>)
(assert (= nodes@74@main (Seq_append ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (Seq_singleton n@60@main))))
; [exec]
; fold acc(List(this), write)
; [eval] (forall i: Int, j: Int :: { this.nodes[i], this.nodes[j] } (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j])
(declare-const i@75@main Int)
(declare-const j@76@main Int)
(set-option :rlimit 0)
(push) ; 4
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j) ==> this.nodes[i] != this.nodes[j]
; [eval] (i in [0..|this.nodes|)) && ((j in [0..|this.nodes|)) && i != j)
; [eval] (i in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 5
(push) ; 6
(assert (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main)))
(pop) ; 6
(push) ; 6
(assert (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main))
; [eval] (j in [0..|this.nodes|))
; [eval] [0..|this.nodes|)
; [eval] |this.nodes|
(push) ; 7
(push) ; 8
(assert (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main)))
(pop) ; 8
(push) ; 8
(assert (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main))
; [eval] i != j
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (=> (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (or (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main)))))
(assert (or (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main))))
(push) ; 5
(push) ; 6
(assert (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))))
; [eval] this.nodes[i] != this.nodes[j]
; [eval] this.nodes[i]
(push) ; 7
(assert (not (>= i@75@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(assert (not (< i@75@main (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
; [eval] this.nodes[j]
(push) ; 7
(assert (not (>= j@76@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(assert (not (< j@76@main (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(pop) ; 6
(push) ; 6
(assert (not (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main))))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=> (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))))
; Joined path conditions
(assert (or (not (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main))))) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main))))))
(pop) ; 4
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@75@main Int) (j@76@main Int)) (! (and (=> (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (or (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main)))) (or (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (not (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main))) (=> (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))) (or (not (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main))))) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))))) :pattern ((Seq_index nodes@74@main i@75@main) (Seq_index nodes@74@main j@76@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159-aux|)))
(push) ; 4
(assert (not (forall ((i@75@main Int) (j@76@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))) (not (= (Seq_index nodes@74@main i@75@main) (Seq_index nodes@74@main j@76@main)))) :pattern ((Seq_index nodes@74@main i@75@main) (Seq_index nodes@74@main j@76@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|))))
(check-sat)
; unsat
(pop) ; 4
; 4ms
; (get-info :all-statistics)
(assert (forall ((i@75@main Int) (j@76@main Int)) (! (=> (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) i@75@main) (and (Seq_contains (Seq_range 0 (Seq_length nodes@74@main)) j@76@main) (not (= i@75@main j@76@main)))) (not (= (Seq_index nodes@74@main i@75@main) (Seq_index nodes@74@main j@76@main)))) :pattern ((Seq_index nodes@74@main i@75@main) (Seq_index nodes@74@main j@76@main)) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@16@8@16@159|)))
(declare-const i@77@main Int)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@77@main)))
(pop) ; 6
(push) ; 6
(assert (<= 0 i@77@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@77@main) (not (<= 0 i@77@main))))
(assert (and (<= 0 i@77@main) (< i@77@main (Seq_length nodes@74@main))))
; [eval] this.nodes[i]
(push) ; 5
(assert (not (>= i@77@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(declare-fun inv@78@main ($Ref) Int)
(declare-fun img@79@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@77@main Int)) (! (=> (and (<= 0 i@77@main) (< i@77@main (Seq_length nodes@74@main))) (or (<= 0 i@77@main) (not (<= 0 i@77@main)))) :pattern ((Seq_index nodes@74@main i@77@main)) :qid |val-aux|)))
(push) ; 4
(assert (not (forall ((i1@77@main Int) (i2@77@main Int)) (! (=> (and (and (<= 0 i1@77@main) (< i1@77@main (Seq_length nodes@74@main))) (and (<= 0 i2@77@main) (< i2@77@main (Seq_length nodes@74@main))) (= (Seq_index nodes@74@main i1@77@main) (Seq_index nodes@74@main i2@77@main))) (= i1@77@main i2@77@main)) :qid |val-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@77@main Int)) (! (=> (and (<= 0 i@77@main) (< i@77@main (Seq_length nodes@74@main))) (and (= (inv@78@main (Seq_index nodes@74@main i@77@main)) i@77@main) (img@79@main (Seq_index nodes@74@main i@77@main)))) :pattern ((Seq_index nodes@74@main i@77@main)) :qid |val-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@79@main r) (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main)))) (= (Seq_index nodes@74@main (inv@78@main r)) r)) :pattern ((inv@78@main r)) :qid |val-fctOfInv|)))
(push) ; 4
(set-option :rlimit 100000)
(assert (not (forall ((i@77@main Int)) (! (= (Seq_index nodes@74@main i@77@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@77@main)) :qid |quant-u-31|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(define-fun pTaken@80@main ((r $Ref)) $Perm
  (ite (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r) (= r (Seq_index nodes@74@main (inv@78@main r)))) ($Perm.min (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) $Perm.Write) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (pTaken@80@main r)) $Perm.No) :qid |quant-u-32|))))
(check-sat)
; unsat
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r) (= r (Seq_index nodes@74@main (inv@78@main r)))) (= (- $Perm.Write (pTaken@80@main r)) $Perm.No)) :qid |quant-u-33|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(define-fun pTaken@81@main ((r $Ref)) $Perm
  (ite (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r) (= r (Seq_index nodes@74@main (inv@78@main r)))) ($Perm.min (ite (= r n@60@main) $Perm.Write $Perm.No) (- $Perm.Write (pTaken@80@main r))) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r n@60@main) $Perm.Write $Perm.No) (pTaken@81@main r)) $Perm.No) :qid |quant-u-34|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r) (= r (Seq_index nodes@74@main (inv@78@main r)))) (= (- (- $Perm.Write (pTaken@80@main r)) (pTaken@81@main r)) $Perm.No)) :qid |quant-u-35|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(declare-const sm@82@main $FVF<val>)
(assert (forall ((r $Ref)) (! (and (=> (Set_in r ($FVF.domain_val (as sm@82@main $FVF<val>))) (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r))) (=> (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r)) (Set_in r ($FVF.domain_val (as sm@82@main $FVF<val>))))) :pattern ((Set_in r ($FVF.domain_val (as sm@82@main $FVF<val>)))) :qid |qp.psmDomDef37|)))
(assert ($FVF.has_domain_val (as sm@82@main $FVF<val>)))
(assert (forall ((r $Ref)) (! (=> (and (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r)) (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))))))) (= ($FVF.lookup_val (as sm@82@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@82@main $FVF<val>) r)) :qid |qp.psmValDef35|)))
(assert (forall ((r $Ref)) (! (=> (and (and (and (<= 0 (inv@78@main r)) (< (inv@78@main r) (Seq_length nodes@74@main))) (img@79@main r)) (= r n@60@main)) (= ($FVF.lookup_val (as sm@82@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@82@main $FVF<val>) r)) :qid |qp.psmValDef36|)))
(declare-const i@83@main Int)
(set-option :rlimit 0)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@83@main)))
(pop) ; 6
(push) ; 6
(assert (<= 0 i@83@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@83@main) (not (<= 0 i@83@main))))
(assert (and (<= 0 i@83@main) (< i@83@main (Seq_length nodes@74@main))))
; [eval] this.nodes[i]
(push) ; 5
(assert (not (>= i@83@main 0)))
(check-sat)
; unsat
(pop) ; 5
; 0ms
; (get-info :all-statistics)
(pop) ; 4
(declare-fun inv@84@main ($Ref) Int)
(declare-fun img@85@main ($Ref) Bool)
; Nested auxiliary terms: globals
; Nested auxiliary terms: non-globals
(assert (forall ((i@83@main Int)) (! (=> (and (<= 0 i@83@main) (< i@83@main (Seq_length nodes@74@main))) (or (<= 0 i@83@main) (not (<= 0 i@83@main)))) :pattern ((Seq_index nodes@74@main i@83@main)) :qid |next-aux|)))
(declare-const sm@86@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@86@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@86@main $FVF<next>) r)) :qid |qp.psmValDef38|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@86@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@86@main $FVF<next>) r)) :qid |qp.psmValDef39|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@86@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@86@main $FVF<next>) r)) :qid |qp.psmValDef40|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@86@main $FVF<next>) r)) :qid |qp.psmResTrgDef41|)))
(push) ; 4
(assert (not (forall ((i1@83@main Int) (i2@83@main Int)) (! (=> (and (and (and (<= 0 i1@83@main) (< i1@83@main (Seq_length nodes@74@main))) ($FVF.loc_next ($FVF.lookup_next (as sm@86@main $FVF<next>) (Seq_index nodes@74@main i1@83@main)) (Seq_index nodes@74@main i1@83@main))) (and (and (<= 0 i2@83@main) (< i2@83@main (Seq_length nodes@74@main))) ($FVF.loc_next ($FVF.lookup_next (as sm@86@main $FVF<next>) (Seq_index nodes@74@main i2@83@main)) (Seq_index nodes@74@main i2@83@main))) (= (Seq_index nodes@74@main i1@83@main) (Seq_index nodes@74@main i2@83@main))) (= i1@83@main i2@83@main)) :qid |next-rcvrInj|))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
; Definitional axioms for inverse functions
(assert (forall ((i@83@main Int)) (! (=> (and (<= 0 i@83@main) (< i@83@main (Seq_length nodes@74@main))) (and (= (inv@84@main (Seq_index nodes@74@main i@83@main)) i@83@main) (img@85@main (Seq_index nodes@74@main i@83@main)))) :pattern ((Seq_index nodes@74@main i@83@main)) :qid |next-invOfFct|)))
(assert (forall ((r $Ref)) (! (=> (and (img@85@main r) (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main)))) (= (Seq_index nodes@74@main (inv@84@main r)) r)) :pattern ((inv@84@main r)) :qid |next-fctOfInv|)))
(assert (forall ((r $Ref)) (! (=> (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) ($FVF.loc_next ($FVF.lookup_next (as sm@86@main $FVF<next>) r) r)) :pattern ((inv@84@main r)) :qid |quant-u-38|)))
(push) ; 4
(set-option :rlimit 100000)
(assert (not (forall ((i@83@main Int)) (! (= (Seq_index nodes@74@main i@83@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) i@83@main)) :qid |quant-u-39|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(define-fun pTaken@87@main ((r $Ref)) $Perm
  (ite (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) ($Perm.min (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) $Perm.Write) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (pTaken@87@main r)) $Perm.No) :qid |quant-u-40|))))
(check-sat)
; unsat
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) (= (- $Perm.Write (pTaken@87@main r)) $Perm.No)) :qid |quant-u-41|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(define-fun pTaken@88@main ((r $Ref)) $Perm
  (ite (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) ($Perm.min (ite (= r n@60@main) $Perm.Write $Perm.No) (- $Perm.Write (pTaken@87@main r))) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r n@60@main) $Perm.Write $Perm.No) (pTaken@88@main r)) $Perm.No) :qid |quant-u-42|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) (= (- (- $Perm.Write (pTaken@87@main r)) (pTaken@88@main r)) $Perm.No)) :qid |quant-u-43|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(define-fun pTaken@89@main ((r $Ref)) $Perm
  (ite (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) ($Perm.min (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (- (- $Perm.Write (pTaken@87@main r)) (pTaken@88@main r))) $Perm.No))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (= (- (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (pTaken@89@main r)) $Perm.No) :qid |quant-u-44|))))
(check-sat)
; unsat
(pop) ; 4
; 3ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 5000000)
(assert (not (forall ((r $Ref)) (! (=> (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r) (= r (Seq_index nodes@74@main (inv@84@main r)))) (= (- (- (- $Perm.Write (pTaken@87@main r)) (pTaken@88@main r)) (pTaken@89@main r)) $Perm.No)) :qid |quant-u-45|))))
(check-sat)
; unsat
(pop) ; 4
; 2ms
; (get-info :all-statistics)
(declare-const sm@90@main $FVF<next>)
(assert (forall ((r $Ref)) (! (and (=> (Set_in r ($FVF.domain_next (as sm@90@main $FVF<next>))) (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r))) (=> (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r)) (Set_in r ($FVF.domain_next (as sm@90@main $FVF<next>))))) :pattern ((Set_in r ($FVF.domain_next (as sm@90@main $FVF<next>)))) :qid |qp.psmDomDef46|)))
(assert ($FVF.has_domain_next (as sm@90@main $FVF<next>)))
(assert (forall ((r $Ref)) (! (=> (and (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false)) (= ($FVF.lookup_next (as sm@90@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@90@main $FVF<next>) r)) :qid |qp.psmValDef42|)))
(assert (forall ((r $Ref)) (! (=> (and (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r)) (= r n@60@main)) (= ($FVF.lookup_next (as sm@90@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@90@main $FVF<next>) r)) :qid |qp.psmValDef43|)))
(assert (forall ((r $Ref)) (! (=> (and (and (and (<= 0 (inv@84@main r)) (< (inv@84@main r) (Seq_length nodes@74@main))) (img@85@main r)) (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (= ($FVF.lookup_next (as sm@90@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@90@main $FVF<next>) r)) :qid |qp.psmValDef44|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@90@main $FVF<next>) r)) :qid |qp.psmResTrgDef45|)))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@91@main Int)
(set-option :rlimit 0)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@91@main)))
(pop) ; 6
(push) ; 6
(assert (<= 0 i@91@main))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@91@main) (not (<= 0 i@91@main))))
(push) ; 5
(push) ; 6
(assert (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main))))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(push) ; 7
(assert (not (>= i@91@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main))))
(pop) ; 8
(push) ; 8
(assert (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(push) ; 9
(push) ; 10
(assert (< i@91@main (- (Seq_length nodes@74@main) 1)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(push) ; 11
(assert (not (>= i@91@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(declare-const sm@92@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef48|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmResTrgDef50|)))
(declare-const pm@93@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@93@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resPrmSumDef51|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resTrgDef52|)))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main)))
(declare-fun rcvr@94@main (Int) $Ref)
(push) ; 11
(assert (not (=> (= (rcvr@94@main i@91@main) (Seq_index nodes@74@main i@91@main)) (< $Perm.No ($FVF.perm_next (as pm@93@main $FPM) (Seq_index nodes@74@main i@91@main))))))
(check-sat)
; unsat
(pop) ; 11
; 2ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 11
(assert (not (>= (+ i@91@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (+ i@91@main 1) (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(push) ; 10
(assert (not (< i@91@main (- (Seq_length nodes@74@main) 1))))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(push) ; 11
(assert (not (>= i@91@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(declare-const sm@95@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef53|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef55|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmResTrgDef56|)))
(declare-const pm@96@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@96@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resPrmSumDef57|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resTrgDef58|)))
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main)))
(declare-fun rcvr@97@main (Int) $Ref)
(push) ; 11
(assert (not (=> (= (rcvr@97@main i@91@main) (Seq_index nodes@74@main i@91@main)) (< $Perm.No ($FVF.perm_next (as pm@96@main $FPM) (Seq_index nodes@74@main i@91@main))))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef48|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmResTrgDef50|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@93@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resPrmSumDef51|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resTrgDef52|)))
(assert (=> (< i@91@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef53|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef55|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmResTrgDef56|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@96@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resPrmSumDef57|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resTrgDef58|)))
(assert (=> (not (< i@91@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))))
(assert (or (not (< i@91@main (- (Seq_length nodes@74@main) 1))) (< i@91@main (- (Seq_length nodes@74@main) 1))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef48|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmResTrgDef50|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@93@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resPrmSumDef51|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resTrgDef52|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef53|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef55|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmResTrgDef56|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@96@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resPrmSumDef57|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resTrgDef58|)))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (and (=> (< i@91@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (=> (not (< i@91@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (or (not (< i@91@main (- (Seq_length nodes@74@main) 1))) (< i@91@main (- (Seq_length nodes@74@main) 1))))))
(assert (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)))))
(pop) ; 6
(push) ; 6
(assert (not (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef48|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmResTrgDef50|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@93@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resPrmSumDef51|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resTrgDef52|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef53|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef55|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmResTrgDef56|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@96@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resPrmSumDef57|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resTrgDef58|)))
(assert (=> (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main))) (and (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (and (=> (< i@91@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (=> (not (< i@91@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (or (not (< i@91@main (- (Seq_length nodes@74@main) 1))) (< i@91@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)))))))
; Joined path conditions
(assert (or (not (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main)))) (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main)))))
(declare-const sm@98@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef59|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef60|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef61|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmResTrgDef62|)))
; [eval] this.nodes[i]
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef47|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef48|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmValDef49|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@92@main $FVF<next>) r)) :qid |qp.psmResTrgDef50|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@93@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resPrmSumDef51|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@93@main $FPM) r)) :qid |qp.resTrgDef52|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef53|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef54|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmValDef55|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@95@main $FVF<next>) r)) :qid |qp.psmResTrgDef56|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@96@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resPrmSumDef57|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@96@main $FPM) r)) :qid |qp.resTrgDef58|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef59|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef60|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@98@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmValDef61|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@98@main $FVF<next>) r)) :qid |qp.psmResTrgDef62|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@91@main Int)) (! (and (or (<= 0 i@91@main) (not (<= 0 i@91@main))) (=> (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main))) (and (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (and (=> (< i@91@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (=> (not (< i@91@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) (or (not (< i@91@main (- (Seq_length nodes@74@main) 1))) (< i@91@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)))))) (or (not (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main)))) (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@98@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(push) ; 4
(assert (not (forall ((i@91@main Int)) (! (=> (and (<= 0 i@91@main) (< i@91@main (Seq_length nodes@74@main))) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@91@main)) (ite (< i@91@main (- (Seq_length nodes@74@main) 1)) (= ($FVF.lookup_next (as sm@92@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main (+ i@91@main 1))) (= ($FVF.lookup_next (as sm@95@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@98@main $FVF<next>) (Seq_index nodes@74@main i@91@main)) (Seq_index nodes@74@main i@91@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 4ms
; (get-info :all-statistics)
(push) ; 4
(assert (not false))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@99@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@99@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@99@main $FVF<next>) r)) :qid |qp.psmValDef63|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@99@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@99@main $FVF<next>) r)) :qid |qp.psmValDef64|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@99@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@99@main $FVF<next>) r)) :qid |qp.psmValDef65|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@99@main $FVF<next>) r)) :qid |qp.psmResTrgDef66|)))
(declare-const pm@100@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@100@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@100@main $FPM) r)) :qid |qp.resPrmSumDef67|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@99@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@100@main $FPM) r)) :qid |qp.resTrgDef68|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@100@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@99@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@101@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@101@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@101@main $FVF<val>) r)) :qid |qp.psmValDef69|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@101@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@101@main $FVF<val>) r)) :qid |qp.psmValDef70|)))
(declare-const pm@102@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@102@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@102@main $FPM) r)) :qid |qp.resPrmSumDef71|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@102@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@102@main $FPM) n@60@main) $Perm.Write))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@103@main Int)
(set-option :rlimit 0)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@103@main)))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@104@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef72|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef73|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef74|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmResTrgDef75|)))
(declare-const pm@105@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@105@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resPrmSumDef76|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resTrgDef77|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@105@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@106@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef78|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef79|)))
(declare-const pm@107@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@107@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@107@main $FPM) r)) :qid |qp.resPrmSumDef80|)))
(assert (<= ($FVF.perm_val (as pm@107@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@107@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 6
(set-option :rlimit 0)
(push) ; 6
(assert (<= 0 i@103@main))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@108@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef81|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef82|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef83|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmResTrgDef84|)))
(declare-const pm@109@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@109@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resPrmSumDef85|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resTrgDef86|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@109@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@110@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef87|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef88|)))
(declare-const pm@111@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@111@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@111@main $FPM) r)) :qid |qp.resPrmSumDef89|)))
(assert (<= ($FVF.perm_val (as pm@111@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@111@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef72|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef73|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef74|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmResTrgDef75|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@105@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resPrmSumDef76|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resTrgDef77|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef78|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef79|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@107@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@107@main $FPM) r)) :qid |qp.resPrmSumDef80|)))
(assert (=> (not (<= 0 i@103@main)) (and (not (<= 0 i@103@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@105@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@107@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@107@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef81|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef82|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef83|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmResTrgDef84|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@109@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resPrmSumDef85|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resTrgDef86|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef87|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef88|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@111@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@111@main $FPM) r)) :qid |qp.resPrmSumDef89|)))
(assert (=> (<= 0 i@103@main) (and (<= 0 i@103@main) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@109@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@111@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@111@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (or (<= 0 i@103@main) (not (<= 0 i@103@main))))
(set-option :rlimit 0)
(push) ; 5
(push) ; 6
(assert (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@112@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef90|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef91|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef92|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmResTrgDef93|)))
(declare-const pm@113@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@113@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resPrmSumDef94|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resTrgDef95|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@113@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@114@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef96|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef97|)))
(declare-const pm@115@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@115@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@115@main $FPM) r)) :qid |qp.resPrmSumDef98|)))
(assert (<= ($FVF.perm_val (as pm@115@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@115@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= i@103@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))
(declare-const ms@116@main $FVF<next>)
(assert (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@116@main $FVF<next>) r)) :qid |quant-u-48|)))
(declare-const sm@117@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef99|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next (as ms@116@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef100|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmResTrgDef101|)))
(declare-const pm@118@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@118@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resPrmSumDef102|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resTrgDef103|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@118@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@119@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef105|)))
(declare-const pm@120@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@120@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@120@main $FPM) r)) :qid |qp.resPrmSumDef106|)))
(assert (<= ($FVF.perm_val (as pm@120@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@120@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 8
(set-option :rlimit 0)
(push) ; 8
(assert (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@121@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef107|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef109|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmResTrgDef110|)))
(declare-const pm@122@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@122@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resPrmSumDef111|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resTrgDef112|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@122@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@123@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef113|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef114|)))
(declare-const pm@124@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@124@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@124@main $FPM) r)) :qid |qp.resPrmSumDef115|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@124@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@124@main $FPM) n@60@main) $Perm.Write))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(set-option :rlimit 0)
(push) ; 9
(push) ; 10
(assert (< i@103@main (- (Seq_length nodes@74@main) 1)))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@125@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef117|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmResTrgDef119|)))
(declare-const pm@126@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@126@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resPrmSumDef120|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resTrgDef121|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@126@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@127@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef123|)))
(declare-const pm@128@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@128@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@128@main $FPM) r)) :qid |qp.resPrmSumDef124|)))
(assert (<= ($FVF.perm_val (as pm@128@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@128@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@103@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (= (Seq_index nodes@74@main i@103@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= (Seq_index nodes@74@main i@103@main) n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main (Seq_index nodes@74@main i@103@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@103@main))) (< (inv@55@main (Seq_index nodes@74@main i@103@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@103@main))) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 11
(assert (not (>= (+ i@103@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (+ i@103@main 1) (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(push) ; 10
(assert (not (< i@103@main (- (Seq_length nodes@74@main) 1))))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@129@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef125|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef127|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmResTrgDef128|)))
(declare-const pm@130@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@130@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resPrmSumDef129|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resTrgDef130|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@130@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@131@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef131|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef132|)))
(declare-const pm@132@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@132@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@132@main $FPM) r)) :qid |qp.resPrmSumDef133|)))
(assert (<= ($FVF.perm_val (as pm@132@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@132@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@103@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (= (Seq_index nodes@74@main i@103@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= (Seq_index nodes@74@main i@103@main) n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main (Seq_index nodes@74@main i@103@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@103@main))) (< (inv@55@main (Seq_index nodes@74@main i@103@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@103@main))) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef117|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmResTrgDef119|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@126@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resPrmSumDef120|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resTrgDef121|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef123|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@128@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@128@main $FPM) r)) :qid |qp.resPrmSumDef124|)))
(assert (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) (and (< i@103@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@126@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@128@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@128@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef125|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef127|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmResTrgDef128|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@130@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resPrmSumDef129|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resTrgDef130|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef131|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@132@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@132@main $FPM) r)) :qid |qp.resPrmSumDef133|)))
(assert (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@130@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@132@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@132@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))))
(assert (or (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (< i@103@main (- (Seq_length nodes@74@main) 1))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef99|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next (as ms@116@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef100|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmResTrgDef101|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@118@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resPrmSumDef102|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resTrgDef103|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef105|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@120@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@120@main $FPM) r)) :qid |qp.resPrmSumDef106|)))
(assert (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@116@main $FVF<next>) r)) :qid |quant-u-48|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@118@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@120@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@120@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef107|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef109|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmResTrgDef110|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@122@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resPrmSumDef111|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resTrgDef112|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef113|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef114|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@124@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@124@main $FPM) r)) :qid |qp.resPrmSumDef115|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef117|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmResTrgDef119|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@126@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resPrmSumDef120|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resTrgDef121|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef123|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@128@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@128@main $FPM) r)) :qid |qp.resPrmSumDef124|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef125|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef127|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmResTrgDef128|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@130@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resPrmSumDef129|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resTrgDef130|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef131|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@132@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@132@main $FPM) r)) :qid |qp.resPrmSumDef133|)))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@122@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@124@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@124@main $FPM) n@60@main) $Perm.Write))))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) (and (< i@103@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@126@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@128@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@128@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@130@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@132@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@132@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (or (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (< i@103@main (- (Seq_length nodes@74@main) 1))))))
(assert (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)))))
(pop) ; 6
(push) ; 6
(assert (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@133@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef134|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef135|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef136|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmResTrgDef137|)))
(declare-const pm@134@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@134@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resPrmSumDef138|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resTrgDef139|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@134@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@135@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef140|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef141|)))
(declare-const pm@136@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@136@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@136@main $FPM) r)) :qid |qp.resPrmSumDef142|)))
(assert (<= ($FVF.perm_val (as pm@136@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@136@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef90|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef91|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef92|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmResTrgDef93|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@113@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resPrmSumDef94|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resTrgDef95|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef96|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef97|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@115@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@115@main $FPM) r)) :qid |qp.resPrmSumDef98|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef99|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next (as ms@116@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef100|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmResTrgDef101|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@118@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resPrmSumDef102|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resTrgDef103|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef105|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@120@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@120@main $FPM) r)) :qid |qp.resPrmSumDef106|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef107|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef109|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmResTrgDef110|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@122@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resPrmSumDef111|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resTrgDef112|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef113|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef114|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@124@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@124@main $FPM) r)) :qid |qp.resPrmSumDef115|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef117|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmResTrgDef119|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@126@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resPrmSumDef120|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resTrgDef121|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef123|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@128@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@128@main $FPM) r)) :qid |qp.resPrmSumDef124|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef125|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef127|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmResTrgDef128|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@130@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resPrmSumDef129|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resTrgDef130|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef131|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@132@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@132@main $FPM) r)) :qid |qp.resPrmSumDef133|)))
(assert (=> (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))) (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@113@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@115@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@115@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@116@main $FVF<next>) r)) :qid |quant-u-48|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@118@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@120@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@120@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@122@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@124@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@124@main $FPM) n@60@main) $Perm.Write))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) (and (< i@103@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@126@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@128@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@128@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@130@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@132@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@132@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (or (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (< i@103@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)))))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef134|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef135|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef136|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmResTrgDef137|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@134@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resPrmSumDef138|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resTrgDef139|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef140|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef141|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@136@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@136@main $FPM) r)) :qid |qp.resPrmSumDef142|)))
(assert (=> (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@134@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@136@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@136@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (or (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))))
(declare-const sm@137@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef143|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef144|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef145|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmResTrgDef146|)))
; [eval] this.nodes[i]
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef72|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef73|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@104@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmValDef74|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@104@main $FVF<next>) r)) :qid |qp.psmResTrgDef75|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@105@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resPrmSumDef76|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@105@main $FPM) r)) :qid |qp.resTrgDef77|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef78|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@106@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@106@main $FVF<val>) r)) :qid |qp.psmValDef79|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@107@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@107@main $FPM) r)) :qid |qp.resPrmSumDef80|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef81|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef82|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@108@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmValDef83|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@108@main $FVF<next>) r)) :qid |qp.psmResTrgDef84|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@109@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resPrmSumDef85|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@109@main $FPM) r)) :qid |qp.resTrgDef86|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef87|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@110@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@110@main $FVF<val>) r)) :qid |qp.psmValDef88|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@111@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@111@main $FPM) r)) :qid |qp.resPrmSumDef89|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef90|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef91|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@112@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmValDef92|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@112@main $FVF<next>) r)) :qid |qp.psmResTrgDef93|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@113@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resPrmSumDef94|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@113@main $FPM) r)) :qid |qp.resTrgDef95|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef96|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@114@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@114@main $FVF<val>) r)) :qid |qp.psmValDef97|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@115@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@115@main $FPM) r)) :qid |qp.resPrmSumDef98|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef99|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@117@main $FVF<next>) r) ($FVF.lookup_next (as ms@116@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmValDef100|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@117@main $FVF<next>) r)) :qid |qp.psmResTrgDef101|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@118@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resPrmSumDef102|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@116@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@118@main $FPM) r)) :qid |qp.resTrgDef103|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef104|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@119@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@119@main $FVF<val>) r)) :qid |qp.psmValDef105|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@120@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@120@main $FPM) r)) :qid |qp.resPrmSumDef106|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef107|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef108|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmValDef109|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@121@main $FVF<next>) r)) :qid |qp.psmResTrgDef110|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@122@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resPrmSumDef111|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@122@main $FPM) r)) :qid |qp.resTrgDef112|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef113|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@123@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@123@main $FVF<val>) r)) :qid |qp.psmValDef114|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@124@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@124@main $FPM) r)) :qid |qp.resPrmSumDef115|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef116|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef117|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@125@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmValDef118|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@125@main $FVF<next>) r)) :qid |qp.psmResTrgDef119|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@126@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resPrmSumDef120|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@126@main $FPM) r)) :qid |qp.resTrgDef121|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef122|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@127@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@127@main $FVF<val>) r)) :qid |qp.psmValDef123|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@128@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@128@main $FPM) r)) :qid |qp.resPrmSumDef124|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef125|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef126|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@129@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmValDef127|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@129@main $FVF<next>) r)) :qid |qp.psmResTrgDef128|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@130@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resPrmSumDef129|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@130@main $FPM) r)) :qid |qp.resTrgDef130|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef131|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@131@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@131@main $FVF<val>) r)) :qid |qp.psmValDef132|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@132@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@132@main $FPM) r)) :qid |qp.resPrmSumDef133|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef134|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef135|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@133@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmValDef136|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@133@main $FVF<next>) r)) :qid |qp.psmResTrgDef137|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@134@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resPrmSumDef138|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@134@main $FPM) r)) :qid |qp.resTrgDef139|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef140|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@135@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@135@main $FVF<val>) r)) :qid |qp.psmValDef141|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@136@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@136@main $FPM) r)) :qid |qp.resPrmSumDef142|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef143|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef144|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@137@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmValDef145|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@137@main $FVF<next>) r)) :qid |qp.psmResTrgDef146|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@103@main Int)) (! (and (=> (not (<= 0 i@103@main)) (and (not (<= 0 i@103@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@105@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@104@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@107@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@107@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (<= 0 i@103@main) (and (<= 0 i@103@main) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@109@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@108@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@111@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@111@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (or (<= 0 i@103@main) (not (<= 0 i@103@main))) (=> (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))) (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@113@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@112@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@115@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@115@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@116@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@116@main $FVF<next>) r)) :qid |quant-u-48|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@118@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@117@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@120@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@120@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@122@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@124@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@124@main $FPM) n@60@main) $Perm.Write))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (and (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) (and (< i@103@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@126@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@125@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@128@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@128@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@103@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@130@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@129@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@132@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@132@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@103@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) (or (not (< i@103@main (- (Seq_length nodes@74@main) 1))) (< i@103@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)))))) (=> (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@134@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@133@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@136@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@136@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (or (not (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main)))) (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@137@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(set-option :rlimit 0)
(push) ; 4
(assert (not (forall ((i@103@main Int)) (! (=> (and (<= 0 i@103@main) (< i@103@main (Seq_length nodes@74@main))) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@103@main)) (ite (< i@103@main (- (Seq_length nodes@74@main) 1)) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main (+ i@103@main 1))) (= ($FVF.lookup_next (as sm@121@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@137@main $FVF<next>) (Seq_index nodes@74@main i@103@main)) (Seq_index nodes@74@main i@103@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 6ms
; (get-info :all-statistics)
(push) ; 4
(assert (not false))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@138@main Int)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@138@main)))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@139@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef147|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef148|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef149|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmResTrgDef150|)))
(declare-const pm@140@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@140@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resPrmSumDef151|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resTrgDef152|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@140@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@141@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef153|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef154|)))
(declare-const pm@142@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@142@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@142@main $FPM) r)) :qid |qp.resPrmSumDef155|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@142@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@142@main $FPM) n@60@main) $Perm.Write))
(pop) ; 6
(set-option :rlimit 0)
(push) ; 6
(assert (<= 0 i@138@main))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@143@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef156|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef157|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef158|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmResTrgDef159|)))
(declare-const pm@144@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@144@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resPrmSumDef160|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resTrgDef161|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@144@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@145@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef162|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef163|)))
(declare-const pm@146@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@146@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@146@main $FPM) r)) :qid |qp.resPrmSumDef164|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@146@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@146@main $FPM) n@60@main) $Perm.Write))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef147|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef148|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef149|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmResTrgDef150|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@140@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resPrmSumDef151|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resTrgDef152|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef153|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef154|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@142@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@142@main $FPM) r)) :qid |qp.resPrmSumDef155|)))
(assert (=> (not (<= 0 i@138@main)) (and (not (<= 0 i@138@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@140@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@142@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@142@main $FPM) n@60@main) $Perm.Write))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef156|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef157|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef158|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmResTrgDef159|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@144@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resPrmSumDef160|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resTrgDef161|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef162|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef163|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@146@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@146@main $FPM) r)) :qid |qp.resPrmSumDef164|)))
(assert (=> (<= 0 i@138@main) (and (<= 0 i@138@main) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@144@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@146@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@146@main $FPM) n@60@main) $Perm.Write))))
(assert (or (<= 0 i@138@main) (not (<= 0 i@138@main))))
(set-option :rlimit 0)
(push) ; 5
(push) ; 6
(assert (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@147@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef165|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef166|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef167|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmResTrgDef168|)))
(declare-const pm@148@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@148@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resPrmSumDef169|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resTrgDef170|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@148@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@149@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef171|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef172|)))
(declare-const pm@150@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@150@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@150@main $FPM) r)) :qid |qp.resPrmSumDef173|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@150@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@150@main $FPM) n@60@main) $Perm.Write))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= i@138@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))
(declare-const ms@151@main $FVF<next>)
(assert (forall ((r $Ref)) (! (and (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@151@main $FVF<next>) r)) :qid |quant-u-50|)))
(declare-const sm@152@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef174|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef175|)))
(declare-const pm@153@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@153@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@153@main $FPM) r)) :qid |qp.resPrmSumDef176|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@153@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@153@main $FPM) n@60@main) $Perm.Write))
(declare-const sm@154@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next (as ms@151@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef177|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef178|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmResTrgDef179|)))
(declare-const pm@155@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@155@main $FPM) r) (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (/ (to_real 2) (to_real 1)) $Perm.No) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resPrmSumDef180|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resTrgDef181|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@155@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 8
(set-option :rlimit 0)
(push) ; 8
(assert (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 9
; 2ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@156@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef182|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef183|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef184|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmResTrgDef185|)))
(declare-const pm@157@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@157@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resPrmSumDef186|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resTrgDef187|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@157@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@158@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef188|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef189|)))
(declare-const pm@159@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@159@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@159@main $FPM) r)) :qid |qp.resPrmSumDef190|)))
(assert (<= ($FVF.perm_val (as pm@159@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@159@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(set-option :rlimit 0)
(push) ; 9
(push) ; 10
(assert (< i@138@main (- (Seq_length nodes@74@main) 1)))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@160@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef191|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef192|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef193|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmResTrgDef194|)))
(declare-const pm@161@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@161@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resPrmSumDef195|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resTrgDef196|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@161@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@162@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef197|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef198|)))
(declare-const pm@163@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@163@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@163@main $FPM) r)) :qid |qp.resPrmSumDef199|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@163@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@163@main $FPM) n@60@main) $Perm.Write))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@138@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (and (img@56@main (Seq_index nodes@74@main i@138@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@138@main))) (< (inv@55@main (Seq_index nodes@74@main i@138@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@138@main))) $Perm.No) (ite (= (Seq_index nodes@74@main i@138@main) n@60@main) $Perm.Write $Perm.No)) (ite (= (Seq_index nodes@74@main i@138@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 2ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 11
(assert (not (>= (+ i@138@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (+ i@138@main 1) (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(push) ; 10
(assert (not (< i@138@main (- (Seq_length nodes@74@main) 1))))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@164@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef200|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef201|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef202|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmResTrgDef203|)))
(declare-const pm@165@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@165@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resPrmSumDef204|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resTrgDef205|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@165@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@166@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef206|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef207|)))
(declare-const pm@167@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@167@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@167@main $FPM) r)) :qid |qp.resPrmSumDef208|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@167@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@167@main $FPM) n@60@main) $Perm.Write))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@138@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (and (img@56@main (Seq_index nodes@74@main i@138@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@138@main))) (< (inv@55@main (Seq_index nodes@74@main i@138@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@138@main))) $Perm.No) (ite (= (Seq_index nodes@74@main i@138@main) n@60@main) $Perm.Write $Perm.No)) (ite (= (Seq_index nodes@74@main i@138@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef191|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef192|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef193|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmResTrgDef194|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@161@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resPrmSumDef195|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resTrgDef196|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef197|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef198|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@163@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@163@main $FPM) r)) :qid |qp.resPrmSumDef199|)))
(assert (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) (and (< i@138@main (- (Seq_length nodes@74@main) 1)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@161@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@163@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@163@main $FPM) n@60@main) $Perm.Write))))
(assert (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef200|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef201|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef202|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmResTrgDef203|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@165@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resPrmSumDef204|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resTrgDef205|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef206|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef207|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@167@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@167@main $FPM) r)) :qid |qp.resPrmSumDef208|)))
(assert (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@165@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@167@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@167@main $FPM) n@60@main) $Perm.Write))))
(assert (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))))
(assert (or (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (< i@138@main (- (Seq_length nodes@74@main) 1))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef174|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef175|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@153@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@153@main $FPM) r)) :qid |qp.resPrmSumDef176|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next (as ms@151@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef177|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef178|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmResTrgDef179|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@155@main $FPM) r) (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (/ (to_real 2) (to_real 1)) $Perm.No) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resPrmSumDef180|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resTrgDef181|)))
(assert (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (forall ((r $Ref)) (! (and (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@151@main $FVF<next>) r)) :qid |quant-u-50|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@153@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@153@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@155@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef182|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef183|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef184|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmResTrgDef185|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@157@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resPrmSumDef186|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resTrgDef187|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef188|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef189|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@159@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@159@main $FPM) r)) :qid |qp.resPrmSumDef190|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef191|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef192|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef193|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmResTrgDef194|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@161@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resPrmSumDef195|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resTrgDef196|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef197|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef198|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@163@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@163@main $FPM) r)) :qid |qp.resPrmSumDef199|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef200|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef201|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef202|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmResTrgDef203|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@165@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resPrmSumDef204|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resTrgDef205|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef206|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef207|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@167@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@167@main $FPM) r)) :qid |qp.resPrmSumDef208|)))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@157@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@159@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@159@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) (and (< i@138@main (- (Seq_length nodes@74@main) 1)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@161@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@163@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@163@main $FPM) n@60@main) $Perm.Write))) (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@165@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@167@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@167@main $FPM) n@60@main) $Perm.Write))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (or (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (< i@138@main (- (Seq_length nodes@74@main) 1))))))
(assert (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)))))
(pop) ; 6
(push) ; 6
(assert (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@168@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef209|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef210|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef211|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmResTrgDef212|)))
(declare-const pm@169@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@169@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resPrmSumDef213|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resTrgDef214|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@169@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@170@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef215|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef216|)))
(declare-const pm@171@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@171@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@171@main $FPM) r)) :qid |qp.resPrmSumDef217|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@171@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@171@main $FPM) n@60@main) $Perm.Write))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef165|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef166|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef167|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmResTrgDef168|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@148@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resPrmSumDef169|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resTrgDef170|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef171|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef172|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@150@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@150@main $FPM) r)) :qid |qp.resPrmSumDef173|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef174|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef175|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@153@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@153@main $FPM) r)) :qid |qp.resPrmSumDef176|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next (as ms@151@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef177|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef178|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmResTrgDef179|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@155@main $FPM) r) (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (/ (to_real 2) (to_real 1)) $Perm.No) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resPrmSumDef180|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resTrgDef181|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef182|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef183|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef184|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmResTrgDef185|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@157@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resPrmSumDef186|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resTrgDef187|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef188|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef189|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@159@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@159@main $FPM) r)) :qid |qp.resPrmSumDef190|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef191|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef192|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef193|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmResTrgDef194|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@161@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resPrmSumDef195|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resTrgDef196|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef197|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef198|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@163@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@163@main $FPM) r)) :qid |qp.resPrmSumDef199|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef200|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef201|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef202|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmResTrgDef203|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@165@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resPrmSumDef204|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resTrgDef205|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef206|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef207|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@167@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@167@main $FPM) r)) :qid |qp.resPrmSumDef208|)))
(assert (=> (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))) (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@148@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@150@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@150@main $FPM) n@60@main) $Perm.Write))))
(assert (=> (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (forall ((r $Ref)) (! (and (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@151@main $FVF<next>) r)) :qid |quant-u-50|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@153@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@153@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@155@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@157@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@159@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@159@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) (and (< i@138@main (- (Seq_length nodes@74@main) 1)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@161@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@163@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@163@main $FPM) n@60@main) $Perm.Write))) (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@165@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@167@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@167@main $FPM) n@60@main) $Perm.Write))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (or (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (< i@138@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)))))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef209|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef210|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef211|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmResTrgDef212|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@169@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resPrmSumDef213|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resTrgDef214|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef215|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef216|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@171@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@171@main $FPM) r)) :qid |qp.resPrmSumDef217|)))
(assert (=> (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@169@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@171@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@171@main $FPM) n@60@main) $Perm.Write))))
(assert (or (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))))
(declare-const sm@172@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef218|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef219|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef220|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmResTrgDef221|)))
; [eval] this.nodes[i]
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef147|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef148|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@139@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmValDef149|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@139@main $FVF<next>) r)) :qid |qp.psmResTrgDef150|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@140@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resPrmSumDef151|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@140@main $FPM) r)) :qid |qp.resTrgDef152|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef153|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@141@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@141@main $FVF<val>) r)) :qid |qp.psmValDef154|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@142@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@142@main $FPM) r)) :qid |qp.resPrmSumDef155|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef156|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef157|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@143@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmValDef158|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@143@main $FVF<next>) r)) :qid |qp.psmResTrgDef159|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@144@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resPrmSumDef160|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@144@main $FPM) r)) :qid |qp.resTrgDef161|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef162|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@145@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@145@main $FVF<val>) r)) :qid |qp.psmValDef163|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@146@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@146@main $FPM) r)) :qid |qp.resPrmSumDef164|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef165|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef166|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@147@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmValDef167|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@147@main $FVF<next>) r)) :qid |qp.psmResTrgDef168|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@148@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resPrmSumDef169|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@148@main $FPM) r)) :qid |qp.resTrgDef170|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef171|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@149@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@149@main $FVF<val>) r)) :qid |qp.psmValDef172|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@150@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@150@main $FPM) r)) :qid |qp.resPrmSumDef173|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef174|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@152@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@152@main $FVF<val>) r)) :qid |qp.psmValDef175|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@153@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@153@main $FPM) r)) :qid |qp.resPrmSumDef176|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next (as ms@151@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef177|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@154@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmValDef178|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@154@main $FVF<next>) r)) :qid |qp.psmResTrgDef179|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@155@main $FPM) r) (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (/ (to_real 2) (to_real 1)) $Perm.No) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resPrmSumDef180|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@151@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@155@main $FPM) r)) :qid |qp.resTrgDef181|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef182|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef183|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmValDef184|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@156@main $FVF<next>) r)) :qid |qp.psmResTrgDef185|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@157@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resPrmSumDef186|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@157@main $FPM) r)) :qid |qp.resTrgDef187|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef188|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@158@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@158@main $FVF<val>) r)) :qid |qp.psmValDef189|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@159@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@159@main $FPM) r)) :qid |qp.resPrmSumDef190|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef191|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef192|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@160@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmValDef193|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@160@main $FVF<next>) r)) :qid |qp.psmResTrgDef194|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@161@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resPrmSumDef195|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@161@main $FPM) r)) :qid |qp.resTrgDef196|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef197|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@162@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@162@main $FVF<val>) r)) :qid |qp.psmValDef198|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@163@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@163@main $FPM) r)) :qid |qp.resPrmSumDef199|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef200|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef201|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@164@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmValDef202|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@164@main $FVF<next>) r)) :qid |qp.psmResTrgDef203|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@165@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resPrmSumDef204|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@165@main $FPM) r)) :qid |qp.resTrgDef205|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef206|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@166@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@166@main $FVF<val>) r)) :qid |qp.psmValDef207|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@167@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@167@main $FPM) r)) :qid |qp.resPrmSumDef208|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef209|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef210|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@168@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmValDef211|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@168@main $FVF<next>) r)) :qid |qp.psmResTrgDef212|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@169@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resPrmSumDef213|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@169@main $FPM) r)) :qid |qp.resTrgDef214|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef215|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@170@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@170@main $FVF<val>) r)) :qid |qp.psmValDef216|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@171@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@171@main $FPM) r)) :qid |qp.resPrmSumDef217|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef218|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef219|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@172@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmValDef220|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@172@main $FVF<next>) r)) :qid |qp.psmResTrgDef221|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@138@main Int)) (! (and (=> (not (<= 0 i@138@main)) (and (not (<= 0 i@138@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@140@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@139@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@142@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@142@main $FPM) n@60@main) $Perm.Write))) (=> (<= 0 i@138@main) (and (<= 0 i@138@main) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@144@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@143@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@146@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@146@main $FPM) n@60@main) $Perm.Write))) (or (<= 0 i@138@main) (not (<= 0 i@138@main))) (=> (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))) (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@148@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@147@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@150@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@150@main $FPM) n@60@main) $Perm.Write))) (=> (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (forall ((r $Ref)) (! (and (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@151@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@151@main $FVF<next>) r)) :qid |quant-u-50|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@153@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@153@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@155@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@154@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@157@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@159@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@159@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (and (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) (and (< i@138@main (- (Seq_length nodes@74@main) 1)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@161@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@160@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@163@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@163@main $FPM) n@60@main) $Perm.Write))) (=> (< i@138@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@165@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@164@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@167@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@167@main $FPM) n@60@main) $Perm.Write))) (=> (not (< i@138@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) (or (not (< i@138@main (- (Seq_length nodes@74@main) 1))) (< i@138@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)))))) (=> (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@169@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@168@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@171@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@171@main $FPM) n@60@main) $Perm.Write))) (or (not (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main)))) (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@172@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(set-option :rlimit 0)
(push) ; 4
(assert (not (forall ((i@138@main Int)) (! (=> (and (<= 0 i@138@main) (< i@138@main (Seq_length nodes@74@main))) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@138@main)) (ite (< i@138@main (- (Seq_length nodes@74@main) 1)) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main (+ i@138@main 1))) (= ($FVF.lookup_next (as sm@156@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@172@main $FVF<next>) (Seq_index nodes@74@main i@138@main)) (Seq_index nodes@74@main i@138@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 6ms
; (get-info :all-statistics)
(push) ; 4
(assert (not false))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 4
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@173@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@173@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@173@main $FVF<next>) r)) :qid |qp.psmValDef222|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@173@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@173@main $FVF<next>) r)) :qid |qp.psmValDef223|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@173@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@173@main $FVF<next>) r)) :qid |qp.psmValDef224|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@173@main $FVF<next>) r)) :qid |qp.psmResTrgDef225|)))
(declare-const pm@174@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@174@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@174@main $FPM) r)) :qid |qp.resPrmSumDef226|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@173@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@174@main $FPM) r)) :qid |qp.resTrgDef227|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@174@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@173@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@175@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@175@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@175@main $FVF<val>) r)) :qid |qp.psmValDef228|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@175@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@175@main $FVF<val>) r)) :qid |qp.psmValDef229|)))
(declare-const pm@176@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@176@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@176@main $FPM) r)) :qid |qp.resPrmSumDef230|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@176@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@176@main $FPM) n@60@main) $Perm.Write))
; [eval] (forall i: Int :: { this.nodes[i].next } 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null))
(declare-const i@177@main Int)
(set-option :rlimit 0)
(push) ; 4
; [eval] 0 <= i && i < |this.nodes| ==> (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] 0 <= i && i < |this.nodes|
; [eval] 0 <= i
(push) ; 5
(push) ; 6
(assert (not (<= 0 i@177@main)))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@178@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef231|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef232|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef233|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmResTrgDef234|)))
(declare-const pm@179@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@179@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resPrmSumDef235|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resTrgDef236|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@179@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@180@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef237|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef238|)))
(declare-const pm@181@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@181@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@181@main $FPM) r)) :qid |qp.resPrmSumDef239|)))
(assert (<= ($FVF.perm_val (as pm@181@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@181@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 6
(set-option :rlimit 0)
(push) ; 6
(assert (<= 0 i@177@main))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@182@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef240|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef241|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef242|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmResTrgDef243|)))
(declare-const pm@183@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@183@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resPrmSumDef244|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resTrgDef245|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@183@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@184@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef246|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef247|)))
(declare-const pm@185@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@185@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@185@main $FPM) r)) :qid |qp.resPrmSumDef248|)))
(assert (<= ($FVF.perm_val (as pm@185@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@185@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] i < |this.nodes|
; [eval] |this.nodes|
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef231|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef232|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef233|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmResTrgDef234|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@179@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resPrmSumDef235|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resTrgDef236|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef237|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef238|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@181@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@181@main $FPM) r)) :qid |qp.resPrmSumDef239|)))
(assert (=> (not (<= 0 i@177@main)) (and (not (<= 0 i@177@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@179@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@181@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@181@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef240|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef241|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef242|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmResTrgDef243|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@183@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resPrmSumDef244|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resTrgDef245|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef246|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef247|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@185@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@185@main $FPM) r)) :qid |qp.resPrmSumDef248|)))
(assert (=> (<= 0 i@177@main) (and (<= 0 i@177@main) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@183@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@185@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@185@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (or (<= 0 i@177@main) (not (<= 0 i@177@main))))
(set-option :rlimit 0)
(push) ; 5
(push) ; 6
(assert (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@186@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef249|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef250|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef251|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmResTrgDef252|)))
(declare-const pm@187@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@187@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resPrmSumDef253|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resTrgDef254|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@187@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@188@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef255|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef256|)))
(declare-const pm@189@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@189@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@189@main $FPM) r)) :qid |qp.resPrmSumDef257|)))
(assert (<= ($FVF.perm_val (as pm@189@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@189@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] (this.nodes[i] in this.nodes) && (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] (this.nodes[i] in this.nodes)
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= i@177@main 0)))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(push) ; 7
(push) ; 8
(assert (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))
(declare-const ms@190@main $FVF<next>)
(assert (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@190@main $FVF<next>) r)) :qid |quant-u-52|)))
(declare-const sm@191@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef258|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next (as ms@190@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef259|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmResTrgDef260|)))
(declare-const pm@192@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@192@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resPrmSumDef261|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resTrgDef262|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@192@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@193@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef263|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef264|)))
(declare-const pm@194@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@194@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@194@main $FPM) r)) :qid |qp.resPrmSumDef265|)))
(assert (<= ($FVF.perm_val (as pm@194@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@194@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 8
(set-option :rlimit 0)
(push) ; 8
(assert (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)))
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 9
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 9
; 0ms
; (get-info :all-statistics)
(assert (and (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(declare-const sm@195@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef266|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef267|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef268|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmResTrgDef269|)))
(declare-const pm@196@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@196@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resPrmSumDef270|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resTrgDef271|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@196@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@197@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef272|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef273|)))
(declare-const pm@198@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@198@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@198@main $FPM) r)) :qid |qp.resPrmSumDef274|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@198@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(assert (<= ($FVF.perm_val (as pm@198@main $FPM) n@60@main) $Perm.Write))
; [eval] (i < |this.nodes| - 1 ? this.nodes[i].next == this.nodes[i + 1] : this.nodes[i].next == null)
; [eval] i < |this.nodes| - 1
; [eval] |this.nodes| - 1
; [eval] |this.nodes|
(set-option :rlimit 0)
(push) ; 9
(push) ; 10
(assert (< i@177@main (- (Seq_length nodes@74@main) 1)))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@199@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef275|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef276|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef277|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmResTrgDef278|)))
(declare-const pm@200@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@200@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resPrmSumDef279|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resTrgDef280|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@200@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@201@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef281|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef282|)))
(declare-const pm@202@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@202@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@202@main $FPM) r)) :qid |qp.resPrmSumDef283|)))
(assert (<= ($FVF.perm_val (as pm@202@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@202@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] this.nodes[i].next == this.nodes[i + 1]
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@177@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (= (Seq_index nodes@74@main i@177@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= (Seq_index nodes@74@main i@177@main) n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main (Seq_index nodes@74@main i@177@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@177@main))) (< (inv@55@main (Seq_index nodes@74@main i@177@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@177@main))) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
; [eval] this.nodes[i + 1]
; [eval] i + 1
(push) ; 11
(assert (not (>= (+ i@177@main 1) 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(push) ; 11
(assert (not (< (+ i@177@main 1) (Seq_length nodes@74@main))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(pop) ; 10
(push) ; 10
(assert (not (< i@177@main (- (Seq_length nodes@74@main) 1))))
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@203@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef284|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef285|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef286|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmResTrgDef287|)))
(declare-const pm@204@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@204@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resPrmSumDef288|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resTrgDef289|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@204@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@205@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef290|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef291|)))
(declare-const pm@206@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@206@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@206@main $FPM) r)) :qid |qp.resPrmSumDef292|)))
(assert (<= ($FVF.perm_val (as pm@206@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@206@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
; [eval] this.nodes[i].next == null
; [eval] this.nodes[i]
(set-option :rlimit 0)
(push) ; 11
(assert (not (>= i@177@main 0)))
(check-sat)
; unsat
(pop) ; 11
; 0ms
; (get-info :all-statistics)
(assert ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main)))
(push) ; 11
(assert (not (< $Perm.No (+ (+ (ite (= (Seq_index nodes@74@main i@177@main) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= (Seq_index nodes@74@main i@177@main) n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main (Seq_index nodes@74@main i@177@main)) (and (<= 0 (inv@55@main (Seq_index nodes@74@main i@177@main))) (< (inv@55@main (Seq_index nodes@74@main i@177@main)) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main (Seq_index nodes@74@main i@177@main))) $Perm.No)))))
(check-sat)
; unsat
(pop) ; 11
; 1ms
; (get-info :all-statistics)
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef275|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef276|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef277|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmResTrgDef278|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@200@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resPrmSumDef279|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resTrgDef280|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef281|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef282|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@202@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@202@main $FPM) r)) :qid |qp.resPrmSumDef283|)))
(assert (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) (and (< i@177@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@200@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@202@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@202@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef284|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef285|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef286|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmResTrgDef287|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@204@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resPrmSumDef288|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resTrgDef289|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef290|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef291|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@206@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@206@main $FPM) r)) :qid |qp.resPrmSumDef292|)))
(assert (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@204@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@206@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@206@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))))
(assert (or (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (< i@177@main (- (Seq_length nodes@74@main) 1))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef258|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next (as ms@190@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef259|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmResTrgDef260|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@192@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resPrmSumDef261|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resTrgDef262|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef263|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef264|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@194@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@194@main $FPM) r)) :qid |qp.resPrmSumDef265|)))
(assert (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@190@main $FVF<next>) r)) :qid |quant-u-52|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@192@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@194@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@194@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef266|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef267|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef268|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmResTrgDef269|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@196@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resPrmSumDef270|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resTrgDef271|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef272|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef273|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@198@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@198@main $FPM) r)) :qid |qp.resPrmSumDef274|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef275|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef276|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef277|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmResTrgDef278|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@200@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resPrmSumDef279|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resTrgDef280|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef281|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef282|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@202@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@202@main $FPM) r)) :qid |qp.resPrmSumDef283|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef284|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef285|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef286|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmResTrgDef287|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@204@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resPrmSumDef288|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resTrgDef289|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef290|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef291|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@206@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@206@main $FPM) r)) :qid |qp.resPrmSumDef292|)))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@196@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@198@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@198@main $FPM) n@60@main) $Perm.Write))))
(assert (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) (and (< i@177@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@200@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@202@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@202@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@204@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@206@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@206@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (or (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (< i@177@main (- (Seq_length nodes@74@main) 1))))))
(assert (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)))))
(pop) ; 6
(push) ; 6
(assert (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))))
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 7
; 1ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ $Perm.Write (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No)))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (< $Perm.Write (+ (ite (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) $Perm.Write))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main) ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 100000)
(assert (not (and (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (not (= ($FVF.lookup_next (as sm@73@main $FVF<next>) (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) ($FVF.lookup_next (as sm@68@main $FVF<next>) n@60@main))))))
(check-sat)
; unsat
(pop) ; 7
; 0ms
; (get-info :all-statistics)
(assert (and (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main))))
(declare-const sm@207@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef293|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef294|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef295|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmResTrgDef296|)))
(declare-const pm@208@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@208@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resPrmSumDef297|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resTrgDef298|)))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@208@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)))
(declare-const sm@209@main $FVF<val>)
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef299|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef300|)))
(declare-const pm@210@main $FPM)
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@210@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@210@main $FPM) r)) :qid |qp.resPrmSumDef301|)))
(assert (<= ($FVF.perm_val (as pm@210@main $FPM) n@60@main) $Perm.Write))
(assert (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@210@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef249|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef250|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef251|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmResTrgDef252|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@187@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resPrmSumDef253|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resTrgDef254|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef255|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef256|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@189@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@189@main $FPM) r)) :qid |qp.resPrmSumDef257|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef258|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next (as ms@190@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef259|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmResTrgDef260|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@192@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resPrmSumDef261|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resTrgDef262|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef263|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef264|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@194@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@194@main $FPM) r)) :qid |qp.resPrmSumDef265|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef266|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef267|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef268|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmResTrgDef269|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@196@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resPrmSumDef270|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resTrgDef271|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef272|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef273|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@198@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@198@main $FPM) r)) :qid |qp.resPrmSumDef274|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef275|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef276|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef277|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmResTrgDef278|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@200@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resPrmSumDef279|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resTrgDef280|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef281|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef282|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@202@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@202@main $FPM) r)) :qid |qp.resPrmSumDef283|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef284|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef285|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef286|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmResTrgDef287|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@204@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resPrmSumDef288|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resTrgDef289|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef290|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef291|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@206@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@206@main $FPM) r)) :qid |qp.resPrmSumDef292|)))
(assert (=> (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))) (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@187@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@189@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@189@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (=> (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@190@main $FVF<next>) r)) :qid |quant-u-52|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@192@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@194@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@194@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@196@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@198@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@198@main $FPM) n@60@main) $Perm.Write))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) (and (< i@177@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@200@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@202@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@202@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@204@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@206@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@206@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (or (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (< i@177@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)))))))
; Joined path conditions
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef293|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef294|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef295|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmResTrgDef296|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@208@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resPrmSumDef297|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resTrgDef298|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef299|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef300|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@210@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@210@main $FPM) r)) :qid |qp.resPrmSumDef301|)))
(assert (=> (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@208@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@210@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@210@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))))
(assert (or (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))))
(declare-const sm@211@main $FVF<next>)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef302|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef303|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef304|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmResTrgDef305|)))
; [eval] this.nodes[i]
(pop) ; 4
; Nested auxiliary terms: globals (aux)
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef231|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef232|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@178@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmValDef233|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@178@main $FVF<next>) r)) :qid |qp.psmResTrgDef234|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@179@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resPrmSumDef235|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@179@main $FPM) r)) :qid |qp.resTrgDef236|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef237|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@180@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@180@main $FVF<val>) r)) :qid |qp.psmValDef238|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@181@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@181@main $FPM) r)) :qid |qp.resPrmSumDef239|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef240|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef241|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@182@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmValDef242|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@182@main $FVF<next>) r)) :qid |qp.psmResTrgDef243|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@183@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resPrmSumDef244|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@183@main $FPM) r)) :qid |qp.resTrgDef245|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef246|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@184@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@184@main $FVF<val>) r)) :qid |qp.psmValDef247|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@185@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@185@main $FPM) r)) :qid |qp.resPrmSumDef248|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef249|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef250|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@186@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmValDef251|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@186@main $FVF<next>) r)) :qid |qp.psmResTrgDef252|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@187@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resPrmSumDef253|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@187@main $FPM) r)) :qid |qp.resTrgDef254|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef255|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@188@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@188@main $FVF<val>) r)) :qid |qp.psmValDef256|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@189@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@189@main $FPM) r)) :qid |qp.resPrmSumDef257|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef258|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@191@main $FVF<next>) r) ($FVF.lookup_next (as ms@190@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmValDef259|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@191@main $FVF<next>) r)) :qid |qp.psmResTrgDef260|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@192@main $FPM) r) (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) (/ (to_real 2) (to_real 1)) $Perm.No))) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resPrmSumDef261|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as ms@190@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@192@main $FPM) r)) :qid |qp.resTrgDef262|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef263|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@193@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@193@main $FVF<val>) r)) :qid |qp.psmValDef264|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@194@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@194@main $FPM) r)) :qid |qp.resPrmSumDef265|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef266|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef267|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmValDef268|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.lookup_next (as sm@195@main $FVF<next>) r)) :qid |qp.psmResTrgDef269|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@196@main $FPM) r) (+ (+ (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No))) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resPrmSumDef270|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r)) :pattern (($FVF.perm_next (as pm@196@main $FPM) r)) :qid |qp.resTrgDef271|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef272|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@197@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@197@main $FVF<val>) r)) :qid |qp.psmValDef273|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@198@main $FPM) r) (+ (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@198@main $FPM) r)) :qid |qp.resPrmSumDef274|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef275|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef276|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@199@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmValDef277|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@199@main $FVF<next>) r)) :qid |qp.psmResTrgDef278|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@200@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resPrmSumDef279|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@200@main $FPM) r)) :qid |qp.resTrgDef280|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef281|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@201@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@201@main $FVF<val>) r)) :qid |qp.psmValDef282|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@202@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@202@main $FPM) r)) :qid |qp.resPrmSumDef283|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef284|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef285|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@203@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmValDef286|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@203@main $FVF<next>) r)) :qid |qp.psmResTrgDef287|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@204@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resPrmSumDef288|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@204@main $FPM) r)) :qid |qp.resTrgDef289|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef290|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@205@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@205@main $FVF<val>) r)) :qid |qp.psmValDef291|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@206@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@206@main $FPM) r)) :qid |qp.resPrmSumDef292|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef293|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef294|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@207@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmValDef295|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@207@main $FVF<next>) r)) :qid |qp.psmResTrgDef296|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_next (as pm@208@main $FPM) r) (+ (+ (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (- $Perm.Write (pTaken@72@main r)) $Perm.No) (ite (= r n@60@main) $Perm.Write $Perm.No)) (ite (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resPrmSumDef297|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.perm_next (as pm@208@main $FPM) r)) :qid |qp.resTrgDef298|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val (as sm@70@main $FVF<val>) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef299|)))
(assert (forall ((r $Ref)) (! (=> (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (= ($FVF.lookup_val (as sm@209@main $FVF<val>) r) ($FVF.lookup_val ($SortWrappers.$SnapTo$FVF<val> ($Snap.first ($Snap.second ($Snap.second ($Snap.first snapshot@45@main))))) r))) :pattern (($FVF.lookup_val (as sm@209@main $FVF<val>) r)) :qid |qp.psmValDef300|)))
(assert (forall ((r $Ref)) (! (= ($FVF.perm_val (as pm@210@main $FPM) r) (+ (ite (= r n@60@main) $Perm.Write $Perm.No) (ite (and (img@53@main r) (and (<= 0 (inv@52@main r)) (< (inv@52@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) $Perm.Write $Perm.No))) :pattern (($FVF.perm_val (as pm@210@main $FPM) r)) :qid |qp.resPrmSumDef301|)))
(assert (forall ((r $Ref)) (! (=> (ite (and (img@56@main r) (and (<= 0 (inv@55@main r)) (< (inv@55@main r) (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))))))) (< $Perm.No (- $Perm.Write (pTaken@72@main r))) false) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef302|)))
(assert (forall ((r $Ref)) (! (=> (= r n@60@main) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef303|)))
(assert (forall ((r $Ref)) (! (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as sm@211@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r))) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmValDef304|)))
(assert (forall ((r $Ref)) (! (and ($FVF.loc_next ($FVF.lookup_next ($SortWrappers.$SnapTo$FVF<next> ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first snapshot@45@main)))))) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@68@main $FVF<next>) r) r) ($FVF.loc_next ($FVF.lookup_next (as sm@73@main $FVF<next>) r) r)) :pattern (($FVF.lookup_next (as sm@211@main $FVF<next>) r)) :qid |qp.psmResTrgDef305|)))
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@177@main Int)) (! (and (=> (not (<= 0 i@177@main)) (and (not (<= 0 i@177@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@179@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@178@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@181@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@181@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (<= 0 i@177@main) (and (<= 0 i@177@main) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@183@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@182@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@185@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@185@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (or (<= 0 i@177@main) (not (<= 0 i@177@main))) (=> (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))) (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@187@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@186@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@189@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@189@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))) (and (=> (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (and (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main))) (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main) (forall ((r $Ref)) (! (and (=> (= r n@60@main) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@68@main $FVF<next>) r))) (=> (= r (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1))) (= ($FVF.lookup_next (as ms@190@main $FVF<next>) r) ($FVF.lookup_next (as sm@73@main $FVF<next>) r)))) :pattern (($FVF.lookup_next (as sm@68@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as sm@73@main $FVF<next>) r)) :pattern (($FVF.lookup_next (as ms@190@main $FVF<next>) r)) :qid |quant-u-52|)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@192@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@191@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@194@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@194@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@196@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@198@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@198@main $FPM) n@60@main) $Perm.Write))) (=> (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (and (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) (and (< i@177@main (- (Seq_length nodes@74@main) 1)) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@200@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@199@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@202@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@202@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (< i@177@main (- (Seq_length nodes@74@main) 1)) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (and (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@204@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@203@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@206@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@206@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (=> (not (< i@177@main (- (Seq_length nodes@74@main) 1))) ($FVF.loc_next ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) (or (not (< i@177@main (- (Seq_length nodes@74@main) 1))) (< i@177@main (- (Seq_length nodes@74@main) 1))))) (or (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (not (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)))))) (=> (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (and (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (not (= n@60@main (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)))) (not (= (Seq_index ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main))) (- (Seq_length ($SortWrappers.$SnapToSeq<$Ref> ($Snap.first ($Snap.first snapshot@45@main)))) 1)) n@60@main)) (forall ((r $Ref)) (! (<= ($FVF.perm_next (as pm@208@main $FPM) r) $Perm.Write) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@207@main $FVF<next>) r) r)) :qid |qp-fld-prm-bnd|)) (<= ($FVF.perm_val (as pm@210@main $FPM) n@60@main) $Perm.Write) (forall ((r $Ref)) (! (<= ($FVF.perm_val (as pm@210@main $FPM) r) $Perm.Write) :pattern ((inv@52@main r)) :qid |qp-fld-prm-bnd|)))) (or (not (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main)))) (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@211@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4-aux|)))
(set-option :rlimit 0)
(push) ; 4
(assert (not (forall ((i@177@main Int)) (! (=> (and (<= 0 i@177@main) (< i@177@main (Seq_length nodes@74@main))) (and (Seq_contains nodes@74@main (Seq_index nodes@74@main i@177@main)) (ite (< i@177@main (- (Seq_length nodes@74@main) 1)) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main (+ i@177@main 1))) (= ($FVF.lookup_next (as sm@195@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) $Ref.null)))) :pattern (($FVF.loc_next ($FVF.lookup_next (as sm@211@main $FVF<next>) (Seq_index nodes@74@main i@177@main)) (Seq_index nodes@74@main i@177@main))) :qid |prog./tmp/ferrum-reference-silicon/silver/src/test/resources/quantifiedpermissions/sequences/linked-list-qp-append.vpr@19@7@21@4|))))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 5ms
; (get-info :all-statistics)
(push) ; 4
(assert (not false))
(check-sat)
; unknown
(get-info :reason-unknown)
; (:reason-unknown "(incomplete quantifiers)")
(pop) ; 4
; 1ms
; (get-info :all-statistics)
(pop) ; 3
(pop) ; 2
(pop) ; 1
