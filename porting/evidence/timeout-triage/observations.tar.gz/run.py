#!/usr/bin/env python3
"""Bounded, fresh-session follow-up of the frozen compatibility timeouts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SELECTION = json.loads((ROOT / 'selection.json').read_text())
SETTINGS = json.loads(Path('/tmp/ferrum-stage4-corrected-inputs/settings-stdio.json').read_text())

def sha(path):
    return hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('backend', choices=['source', 'current', 'old'])
    p.add_argument('label')
    p.add_argument('--ids', default='5,6,2,0,1,3,4,7,8,9,10,11,12,13,14')
    p.add_argument('--seconds', type=int, default=30)
    p.add_argument('--cpus', default='0-3')
    p.add_argument('--extra', action='append', default=[])
    a = p.parse_args()
    out = ROOT / a.label
    out.mkdir()
    prefix = SETTINGS['source'] if a.backend == 'source' else SETTINGS['native']
    prefix = list(prefix)
    if a.backend == 'current':
        prefix[0] = str(ROOT / 'target/debug/examples/compatibility_session')
    env = os.environ.copy()
    for key in list(env):
        if key.startswith(('PRUSTI_', 'FERRUM_', 'Z3_')):
            env.pop(key)
    plan = {'backend': a.backend, 'label': a.label, 'seconds': a.seconds,
            'ids': [int(x) for x in a.ids.split(',')], 'extra': a.extra,
            'cpus': a.cpus, 'prefix': prefix, 'started': time.time(),
            'binary_sha256': sha(prefix[0]), 'z3_sha256': sha(prefix[-1]),
            'load': os.getloadavg(), 'runner_sha256': sha(__file__)}
    (out / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    results = []
    for index in plan['ids']:
        row = SELECTION[index]
        assert sha(row['path']) == row['sha256'], row['path']
        opts = list(row['options'])
        opts[opts.index('--timeout') + 1] = str(a.seconds)
        cmd = ['taskset', '-c', a.cpus] + prefix + opts + a.extra + ['--', row['path']]
        dest = out / f'{index:02d}.json'
        runner = [sys.executable, str(ROOT / 'source/tools/compatibility/run_session.py'),
                  '--timeout', str(a.seconds + 35), '--output', str(dest), '--'] + cmd
        print('START', a.label, index, row['key'], flush=True)
        with (out / f'{index:02d}.runner.log').open('w') as log:
            subprocess.run(runner, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        d = json.loads(dest.read_text())
        case_rows = [r for r in d['records'] if r.get('case') == row['path']]
        result = {'id': index, 'key': row['key'], 'session': d['outcome'],
                  'exit_code': d['exit_code'], 'records': case_rows,
                  'cleanup_pending': d['cleanup_pending'],
                  'protocol_errors': d['protocol_errors'], 'wall_seconds': d['wall_seconds'],
                  'result_sha256': sha(dest), 'load': os.getloadavg()}
        results.append(result)
        (out / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
        print('DONE', a.label, index, d['outcome'],
              [r['outcome'] for r in case_rows], round(d['wall_seconds'], 2), flush=True)
        assert sha(row['path']) == row['sha256'], row['path']
        assert not d['cleanup_pending'] and not d['protocol_errors'], result
    assert sha(prefix[0]) == plan['binary_sha256']
    assert sha(prefix[-1]) == plan['z3_sha256']
    (out / 'complete.json').write_text(json.dumps(results, indent=2) + '\n')

if __name__ == '__main__':
    main()
