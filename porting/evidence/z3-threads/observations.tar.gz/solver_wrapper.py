#!/usr/bin/env python3
"""Pass solver I/O directly through; vary only smt.threads and record resource use."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

count = int(os.environ['FERRUM_THREAD_TEST_THREADS'])
assert count in (1, 2, 4)
command = [os.environ['FERRUM_THREAD_TEST_REAL_Z3'], f'smt.threads={count}', *sys.argv[1:]]
folder = Path(os.environ['FERRUM_THREAD_TEST_METRICS'])
folder.mkdir(parents=True, exist_ok=True)
record = {'command': command, 'wrapper_pid': os.getpid(), 'smt_threads': count,
          'start_monotonic_ns': time.monotonic_ns(), 'affinity': sorted(os.sched_getaffinity(0)),
          'max_sampled_threads': 0, 'max_sampled_rss_kib': 0, 'samples': 0}
output = folder / f'{os.getpid()}.json'
child = subprocess.Popen(command)
record['solver_pid'] = child.pid
output.write_text(json.dumps(record, indent=2) + '\n')
finished = threading.Event()

def monitor():
    while not finished.is_set():
        try:
            data = {}
            for line in Path(f'/proc/{child.pid}/status').read_text().splitlines():
                key, _, value = line.partition(':')
                if key in ('Threads', 'VmRSS'):
                    data[key] = int(value.split()[0])
            record['max_sampled_threads'] = max(record['max_sampled_threads'], data.get('Threads', 0))
            record['max_sampled_rss_kib'] = max(record['max_sampled_rss_kib'], data.get('VmRSS', 0))
            record['samples'] += 1
        except (OSError, ValueError):
            pass
        finished.wait(0.1)

def stop(sig, frame):
    record['received_signal'] = sig
    try:
        os.kill(child.pid, sig)
    except ProcessLookupError:
        pass

for sig in (signal.SIGTERM, signal.SIGINT):
    signal.signal(sig, stop)
watcher = threading.Thread(target=monitor, daemon=True)
watcher.start()
while True:
    try:
        _, status, usage = os.wait4(child.pid, 0)
        break
    except InterruptedError:
        pass
child.returncode = os.waitstatus_to_exitcode(status)
finished.set()
watcher.join(timeout=1)
record.update(exit_code=child.returncode, end_monotonic_ns=time.monotonic_ns(),
              user_s=usage.ru_utime, system_s=usage.ru_stime, max_rss_kib=usage.ru_maxrss,
              complete=True)
temporary = output.with_suffix('.tmp')
temporary.write_text(json.dumps(record, indent=2) + '\n')
temporary.replace(output)
sys.exit(child.returncode if child.returncode >= 0 else 128 - child.returncode)
