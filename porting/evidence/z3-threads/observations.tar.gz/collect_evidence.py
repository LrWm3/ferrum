#!/usr/bin/env python3
"""Audit the completed screen and preserve raw records without correcting them."""
import gzip
import hashlib
import json
from pathlib import Path
import statistics
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/home/will/wk/exp/ferrum')
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = read(root / 'manifest.json')
trials = read(root / 'trials.json')
summary = read(root / 'summary.json')
supervisor = read(root / 'batch-supervisor.json')
assert summary['completed'] == summary['planned'] == len(trials) == 9
assert summary['postflight_errors'] == []
assert supervisor['outcome'] == 'completed' and supervisor['exit_code'] == 0
assert supervisor['cleanup_pending'] == supervisor['protocol_errors'] == []
assert [{k: row[k] for k in ('block', 'threads', 'label')} for row in trials] == manifest['schedule']
assert manifest['parameter_controls'] == [
    {'threads': n, 'exit': 0, 'stdout': f'{n}\n', 'stderr': ''} for n in (1, 2, 4)]
observations = []
for row in trials:
    result = row['result']
    folder = root / row['label']
    assert read(folder / 'result.json') == result
    assert result['dependency_check']['valid'] and result['timer_complete']
    assert result['client_cleanup'] and not result['timed_out']
    assert not any(result[k] for k in ('profile', 'trace', 'instructions'))
    service = result['service_cleanup']
    assert service['stopped'] and not service['cleanup_pending'] and service['error'] is None
    for name in ('clean', 'client'):
        session = read(folder / f'{name}.session.json')
        expected_exit = 0 if name == 'clean' else result['exit']
        assert session['exit_code'] == expected_exit
        assert session['outcome'] == ('completed' if expected_exit == 0 else 'process_error')
        assert not session['cleanup_pending'] and not session['protocol_errors']
    for key in ('source', 'client', 'server'):
        assert result[key + '_sha256'] == manifest['frozen_artifacts'][result[key]]
    for name, key in [('run_direct.py', 'runner_sha256'), ('solver_wrapper.py', 'solver_wrapper_sha256')]:
        assert result[key] == manifest['frozen_artifacts'][str(root / name)]
    assert result['smt_threads'] == row['threads']
    assert result['environment_overrides']['PRUSTI_EXTRA_VERIFIER_ARGS'] == '--timeout=60 --numberOfParallelVerifiers 1 --parallelizeBranches=false --snapshotSummaryOnlyTriggers=true'
    solvers = result['solver_metrics']
    assert len(solvers) == 1
    assert solvers[0]['command'][1:] == [f"smt.threads={row['threads']}", '-smt2', '-in']
    assert solvers[0]['affinity'] == [4, 5, 6, 7]
    assert not row['solver_metrics_complete'] and not solvers[0].get('complete')
    client = (folder / 'client.log').read_text()
    server = (folder / 'server.log').read_text()
    timeout = 'error: [Prusti: verification error] verification timed out after 60 seconds'
    if row['threads'] == 1:
        assert row['driver_exit'] == result['exit'] == 0
        assert result['classification'] == 'valid' and timeout not in client
        classification, diagnostic = 'verified', None
    else:
        assert row['driver_exit'] == 1 and result['exit'] == 101
        assert result['classification'] == 'unexpected_result'
        assert timeout in client
        assert 'Ferrum: timeout verification terminated: Cancelled' in server
        assert 'while verifying method `m_visit`' in server
        classification, diagnostic = 'verifier_timeout', timeout
    observations.append({
        'label': row['label'], 'block': row['block'], 'smt_threads': row['threads'],
        'classification': classification, 'raw_classification': result['classification'],
        'diagnostic': diagnostic, 'request_seconds': result['wall_s'],
        'phase_seconds': {k: [n / 1e9 for n in v] for k, v in result['phase_ns'].items()},
        'client_exit': result['exit'], 'outer_client_timeout': result['timed_out'],
        'dependency_check_valid': True, 'timer_complete': True,
        'client_cleanup_complete': True, 'service_cleanup_complete': True,
        'solver_command': solvers[0]['command'], 'solver_affinity': solvers[0]['affinity'],
        'solver_resource_metrics_complete': False, 'z3_cpu_seconds': None,
        'z3_peak_rss_kib': None, 'raw_result': str((folder / 'result.json').relative_to(root)),
        'raw_result_sha256': sha(folder / 'result.json'),
    })
aggregates = []
for threads in (1, 2, 4):
    rows = [r for r in observations if r['smt_threads'] == threads]
    assert len(rows) == 3
    verified = [r for r in rows if r['classification'] == 'verified']
    aggregates.append({'smt_threads': threads, 'runs': len(rows), 'verified': len(verified),
        'verifier_timeouts': sum(r['classification'] == 'verifier_timeout' for r in rows),
        'request_seconds': [r['request_seconds'] for r in rows],
        'median_successful_request_seconds': statistics.median(r['request_seconds'] for r in verified) if verified else None})
archive = repo / 'porting/evidence/z3-threads/observations.tar.gz'
archive.parent.mkdir(parents=True, exist_ok=True)
files = sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
# Fixed archive metadata makes the retained evidence reproducible from raw files.
with archive.open('wb') as destination:
    with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in files:
                info = tar.gettarinfo(str(path), arcname=str(path.relative_to(root)))
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as source:
                    tar.addfile(info, source)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(files)
    for path in files:
        assert tar.extractfile(str(path.relative_to(root))).read() == path.read_bytes()
primary = trials[0]['result']
identities = {k: {'path': primary[k], 'sha256': primary[k + '_sha256']} for k in ('source', 'client', 'server')}
for key in ('run_batch.py', 'run_direct.py', 'solver_wrapper.py'):
    identities[key] = {'path': str(root / key), 'sha256': manifest['frozen_artifacts'][str(root / key)]}
z3 = primary['solver_metrics'][0]['command'][0]
identities['z3'] = {'path': z3, 'sha256': manifest['frozen_artifacts'][z3], 'version': '4.16.0'}
evidence = {
    'date': '2026-11-01', 'case': 'mut_element_nested_pass', 'raw_root': str(root),
    'scope': 'Frozen historical Prusti fixture and trigger-refinement server; not current branch matrix or Silicon comparison.',
    'decision': 'Keep smt.threads=1 for this workload. All multithreaded observations are censored verifier timeouts.',
    'controls': {k: manifest[k] for k in ('verification_seconds', 'client_seconds', 'batch_seconds', 'ferrum_workers', 'parallel_branches', 'summary_only_triggers', 'cpu_affinity', 'cpu_note', 'timing_note', 'historical_source_revision')},
    'pcg_revision': 'c18a51899e37e0fa67f9b5f17f7d518ef2f5518c',
    'solver_policy': 'Only smt.threads varied; other solver options, resource limits and saturation retained.',
    'internal_caches': True, 'prusti_result_cache': False,
    'shared_host': {'cpu': 'Intel Core i5-1345U', 'logical_cpus': manifest['host']['cpu_count'], 'other_prusti_work_continued': True},
    'identities': identities, 'seed': manifest['seed'],
    'frozen_artifact_count': len(manifest['frozen_artifacts']),
    'preflight': manifest['preflight'], 'postflight_errors': summary['postflight_errors'],
    'parameter_controls': manifest['parameter_controls'],
    'live_thread_observation': read(root / 'live-thread-observation.json'),
    'schedule': manifest['schedule'], 'observations': observations, 'aggregates': aggregates,
    'batch_summary': summary,
    'batch_supervisor': {k: v for k, v in supervisor.items() if k != 'raw_output'},
    'limitations': [
        'Six raw unexpected_result labels corrected using the exact lowercase timeout diagnostic and server cancellation; raw records unchanged.',
        'Final solver resource records were not flushed; raw zero CPU/RSS counters are unavailable, not measured zeros. Derived resource fields are null.',
        'A single live RSS sample is not a peak or a comparison.',
        'Timeout durations are censored and cannot supply a completed-proof speed ratio.',
        'Shared host; historical CPU affinity differs; no claim about current full stdlib matrix.',
    ],
    'setup_failure': 'Initial Python syntax error fixed before preflight and all timed observations; retained separately in archive.',
    'raw_archive': {'path': str(archive.relative_to(repo)), 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'files': len(files)},
    'audit': 'Nine records match the predeclared schedule, binary/source/runner identities, options and affinity; each timeout is confirmed in both logs; dependencies, timers, cleanup and archive bytes audited.',
}
output = repo / 'porting/performance-z3-threads.json'
output.write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({'aggregates': aggregates, 'archive': evidence['raw_archive'], 'audit': 'passed'}, indent=2))
