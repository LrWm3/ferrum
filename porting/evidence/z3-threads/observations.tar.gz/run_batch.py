#!/usr/bin/env python3
"""Predeclared, bounded three-block SMT-thread screen on frozen Prusti inputs."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/will/wk/exp/ferrum')
spec = importlib.util.spec_from_file_location('bench', REPO / 'tools/performance/prusti/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
prepared = b.read('/tmp/ferrum-stage5-prusti-inputs/prepared-final.json')
previous = b.read(REPO / 'porting/snapshot-trigger-refinement.json')['direct_prusti']['trigger-prusti-nested']['result']
server = previous['server']
cfg = prepared['backends']['native']
seed = cfg['target_seeds']['iterator']
frozen = {previous[k]: previous[k + '_sha256'] for k in ('source', 'client', 'server')}
for k in ('prusti_driver', 'prusti_rustc'):
    p = cfg[k]
    frozen[p] = next(v['sha256'] for v in prepared['artifacts'].values() if v['path'] == p)
for k in ('z3', 'cargo', 'rustc'):
    item = prepared['artifacts'][k]
    frozen[item['path']] = item['sha256']
source_root = Path(prepared['source_snapshot'])
source_manifest = b.read(prepared['source_manifest'])
for rel, value in source_manifest['files'].items():
    frozen[str(source_root / rel)] = value
for rel, value in source_manifest['pcg_files'].items():
    frozen[str(source_root / 'pcg' / rel)] = value
for name in ('run_batch.py', 'run_direct.py', 'solver_wrapper.py'):
    frozen[str(ROOT / name)] = b.sha(ROOT / name)

def check_frozen():
    errors = [p for p, h in frozen.items() if b.sha(p) != h]
    if b.tree_hash(Path(seed['path'])) != seed['tree_sha256']:
        errors.append(seed['path'])
    return errors

schedule = [{'block': block, 'threads': count, 'label': f'block{block}-threads{count}'}
            for block, counts in enumerate(((1, 2, 4), (2, 4, 1), (4, 1, 2)), 1)
            for count in counts]
manifest = {'schedule': schedule, 'frozen_artifacts': frozen, 'seed': seed,
            'host': b.host_metadata(), 'started_wall_ns': time.time_ns(),
            'verification_seconds': 60, 'client_seconds': 100, 'batch_seconds': 1200,
            'ferrum_workers': 1, 'parallel_branches': False, 'summary_only_triggers': True,
            'cpu_affinity': [4, 5, 6, 7],
            'cpu_note': 'Four distinct efficiency cores; same affinity for all trials. Historical profile used CPUs 0-3.',
            'timing_note': 'Fresh server per trial. Request time excludes server startup, seed copy and cleaning. Solver I/O is inherited without a byte relay.',
            'historical_source_revision': 'a59ed917c1c3c4c4ca6ff1de12ad20d48491d021'}
errors = check_frozen()
assert not errors, errors
manifest['preflight'] = 'passed'
controls = []
for count in (1, 2, 4):
    env = dict(os.environ, FERRUM_THREAD_TEST_THREADS=str(count),
               FERRUM_THREAD_TEST_REAL_Z3=prepared['artifacts']['z3']['path'],
               FERRUM_THREAD_TEST_METRICS=str(ROOT / 'parameter-controls'))
    control = subprocess.run([str(ROOT / 'solver_wrapper.py'), '-in', '-smt2'], env=env,
                             input='(get-option :smt.threads)\n(exit)\n',
                             text=True, capture_output=True, timeout=10)
    controls.append({'threads': count, 'exit': control.returncode,
                     'stdout': control.stdout, 'stderr': control.stderr})
    assert control.returncode == 0 and control.stdout.strip() == str(count), controls[-1]
manifest['parameter_controls'] = controls
(ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('STARTED nine trials; only Z3 smt.threads varies', flush=True)
started = time.monotonic()
rows = []
for item in schedule:
    if time.monotonic() - started > 1050:
        print('Schedule stopped at batch time budget', flush=True)
        break
    (ROOT / 'progress.json').write_text(json.dumps({'active': item, 'completed': len(rows)}, indent=2) + '\n')
    cmd = [sys.executable, str(ROOT / 'run_direct.py'), item['label'], '--server', server,
           '--threads', str(item['threads'])]
    with (ROOT / (item['label'] + '.driver.log')).open('w') as log:
        proc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=155)
    path = ROOT / item['label'] / 'result.json'
    if not path.exists():
        rows.append({**item, 'driver_exit': proc.returncode, 'classification': 'setup_failure'})
        break
    result = b.read(path)
    row = {**item, 'driver_exit': proc.returncode, 'result': result}
    solvers = [s for s in result.get('solver_metrics', []) if '-in' in s['command']]
    row['solver_metrics_complete'] = bool(solvers) and all(s.get('complete') for s in solvers)
    row['z3_cpu_s'] = sum(s.get('user_s', 0) + s.get('system_s', 0) for s in solvers)
    row['z3_max_rss_kib'] = max((s.get('max_rss_kib', 0) for s in solvers), default=None)
    row['z3_max_sampled_threads'] = max((s['max_sampled_threads'] for s in solvers), default=None)
    rows.append(row)
    (ROOT / 'trials.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps({**item, 'classification': result.get('classification'),
                      'wall_s': result.get('wall_s'), 'z3_cpu_s': row['z3_cpu_s'],
                      'z3_max_sampled_threads': row['z3_max_sampled_threads']}), flush=True)
    if not result.get('dependency_check', {}).get('valid') or not result.get('service_cleanup') or result['service_cleanup']['cleanup_pending']:
        print('Stopped: invalid dependencies or cleanup', flush=True)
        break
postflight = check_frozen()
(ROOT / 'summary.json').write_text(json.dumps({'completed': len(rows), 'planned': len(schedule),
    'postflight_errors': postflight, 'elapsed_seconds': time.monotonic() - started,
    'finished_wall_ns': time.time_ns()}, indent=2) + '\n')
(ROOT / 'progress.json').write_text(json.dumps({'active': None, 'completed': len(rows)}, indent=2) + '\n')
print('COMPLETE', len(rows), 'trials; postflight errors', postflight, flush=True)
sys.exit(0 if len(rows) == 9 and not postflight else 1)
