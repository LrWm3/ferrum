#!/usr/bin/env python3
"""Bounded fresh Prusti client/server trial against an isolated native build."""
import argparse,importlib.util,json,os,pathlib,shutil,signal,socket,subprocess,sys,time,hashlib
P=pathlib.Path
def cpu(pid):
 fields=P(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
 hz=os.sysconf('SC_CLK_TCK')
 return {k:int(fields[i])/hz for k,i in [('user_s',11),('system_s',12),('child_user_s',13),('child_system_s',14)]}
ap=argparse.ArgumentParser();ap.add_argument('name');ap.add_argument('--server',required=True);ap.add_argument('--threads',type=int,choices=[1,2,4],required=True);ap.add_argument('--case',default='mut_element_nested_pass');ap.add_argument('--profile',action='store_true');ap.add_argument('--trace',action='store_true');ap.add_argument('--instructions',action='store_true');ap.add_argument('--options',default='');ap.add_argument('--expect-failure',action='store_true');ap.add_argument('--expected-line',type=int);a=ap.parse_args()
ROOT=P(__file__).resolve().parent
TOOLS=P('/home/will/wk/exp/ferrum/tools/performance')
spec=importlib.util.spec_from_file_location('bench',TOOLS/'prusti/run.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
prepared=b.read('/tmp/ferrum-stage5-prusti-inputs/prepared-final.json');cfg=prepared['backends']['native']
out=ROOT/a.name;out.mkdir();scratch=out/'scratch';scratch.mkdir();target=scratch/'target'
subprocess.run(['cp','-a','--reflink=auto',cfg['target_seeds']['iterator']['path'],str(target)],check=True)
b.ensure_scratch_cache_marker(target,scratch)
fixture=P(prepared['source_snapshot'])/'prusti-tests/tests/cargo_verify/stdlib_iterator_spec'
env={k:v for k,v in os.environ.items() if not k.startswith(('PRUSTI_','DEFAULT_PRUSTI_','FERRUM_')) and k not in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')}
env.update(prepared['environment']);env.update({'RUSTUP_TOOLCHAIN':'nightly-2026-08-15','PRUSTI_VERIFY_MODE':'verify','PRUSTI_VIPER_BACKEND':'Ferrum','PRUSTI_CHECK_OVERFLOWS':'true','PRUSTI_CHECK_PANICS':'true','PRUSTI_NO_VERIFY_DEPS':'true','PRUSTI_ENABLE_CACHE':'false','FERRUM_BENCH_PHASES':'1','FERRUM_BENCH_INTERNAL_CACHES':'on','PRUSTI_LOG':'info','CARGO_TERM_COLOR':'never','PRUSTI_CARGO_PATH':prepared['artifacts']['cargo']['path'],'PRUSTI_EXTRA_VERIFIER_ARGS':('--timeout=60 --numberOfParallelVerifiers 1 --parallelizeBranches=false --snapshotSummaryOnlyTriggers=true '+a.options).strip(),'CARGO_TARGET_DIR':str(target),'PRUSTI_DUMP_VIPER_PROGRAM':'false','PRUSTI_LOG_DIR':str(out/'verifier')})
env.update({'PRUSTI_VIPER_HOME':env['VIPER_HOME'],'PRUSTI_JAVA_HOME':env['JAVA_HOME'],'PRUSTI_SMT_SOLVER_PATH':env['Z3_EXE']})
if a.trace:env.update({'FERRUM_SMT_REAL_Z3':env['Z3_EXE'],'FERRUM_SMT_TRACE_ROOT':str(out/'smt'),'PRUSTI_SMT_SOLVER_PATH':str(TOOLS/'smt/trace_z3_v2.py')})
env.update({'FERRUM_THREAD_TEST_REAL_Z3':env['Z3_EXE'],'FERRUM_THREAD_TEST_THREADS':str(a.threads),'FERRUM_THREAD_TEST_METRICS':str(out/'solver-metrics'),'PRUSTI_SMT_SOLVER_PATH':str(ROOT/'solver_wrapper.py')})
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
env['PRUSTI_SERVER_ADDRESS']=f'127.0.0.1:{port}'
clean=[prepared['artifacts']['cargo']['path'],'clean','--locked','-p','stdlib_iterator_spec','--target-dir',str(target/'verify')]
cc=b.run_process(clean,fixture,env,120,out/'clean.log')
if cc[0]!=0 or not cc[-1]:raise RuntimeError(('clean',cc))
server=None;perf=None;result={};pf=None
serverlog=(out/'server.log').open('wb')
try:
 server=subprocess.Popen([sys.executable,str(TOOLS/'prusti/service_supervisor.py'),str(out/'cleanup.json'),'taskset','--cpu-list','4,5,6,7',a.server,'--port',str(port)],cwd=fixture,env=env,stdout=serverlog,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  if server.poll() is not None:raise RuntimeError('server exited')
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('server startup timeout')
 pid=int(P(f'/proc/{server.pid}/task/{server.pid}/children').read_text().strip())
 if a.profile or a.instructions:
  pf=(out/'perf.log').open('wb')
  events=['-e','instructions:u','-c','1000000'] if a.instructions else ['-e','cpu-clock:u','-F','99','--call-graph','dwarf,65528']
  perf=subprocess.Popen(['perf','record',*events,'-o',str(out/'perf.data'),'-p',str(pid)],stdout=pf,stderr=subprocess.STDOUT)
  time.sleep(.3)
  if perf.poll() is not None:raise RuntimeError('perf startup failed')
 cpu_before=cpu(pid)
 host=b.load_snapshot()
 command=[cfg['cargo_prusti'],'--locked','--offline','--bin',a.case]
 code,timed,wall,user,system,complete,cleanup=b.run_process(command,fixture,env,100,out/'client.log')
 cpu_after=cpu(pid)
 client=(out/'client.log').read_text();serverlog.flush();logs=client+'\n'+(out/'server.log').read_text()
 case={'expect':{'exit':101 if (a.expect_failure or a.case.endswith('_wrong')) else 0,'errors':['[Prusti: verification error] assertion might not hold'] if (a.expect_failure or a.case.endswith('_wrong')) else []}}
 if a.case=='mut_element_array_wrong':case['expect']['location']='mut_element_array_wrong.rs:8:'
 if a.expected_line:case['expect']['location']=f'{a.case}.rs:{a.expected_line}:'
 result={'smt_threads':a.threads,'solver_wrapper_sha256':b.sha(ROOT/'solver_wrapper.py'),'runner_sha256':b.sha(__file__),'server_cpu_s':{k:cpu_after[k]-v for k,v in cpu_before.items()},'case':a.case,'server':a.server,'server_sha256':b.sha(a.server),'client':cfg['cargo_prusti'],'client_sha256':b.sha(cfg['cargo_prusti']),'source':str(fixture/'src/bin'/f'{a.case}.rs'),'source_sha256':b.sha(fixture/'src/bin'/f'{a.case}.rs'),'command':command,'environment_overrides':{k:v for k,v in env.items() if k.startswith(('PRUSTI_','FERRUM_'))},'profile':a.profile,'instructions':a.instructions,'trace':a.trace,'exit':code,'timed_out':timed,'wall_s':wall,'client_user_s':user,'client_system_s':system,'phase_ns':b.phase_records(logs),'classification':b.status(code,timed,client,case),'dependency_check':b.dependency_events(client,'stdlib_iterator_spec'),'timer_complete':complete,'client_cleanup':cleanup,'host_before':host,'host_after':b.load_snapshot()}
finally:
 if perf is not None and perf.poll() is None:
  perf.send_signal(signal.SIGINT)
  try:perf.wait(timeout=8)
  except subprocess.TimeoutExpired:perf.kill();perf.wait()
 if pf:pf.close()
 if server is not None:b.terminate(server)
 serverlog.close()
 result['solver_metrics']=[b.read(p) for p in sorted((out/'solver-metrics').glob('*.json'))]
 result['service_cleanup']=b.read(out/'cleanup.json') if (out/'cleanup.json').exists() else None
 if result: (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 shutil.rmtree(scratch)
print(json.dumps({k:result[k] for k in ('case','classification','wall_s','phase_ns','dependency_check','service_cleanup')}),flush=True)
if result['classification']!='valid' or not result['dependency_check']['valid'] or result['service_cleanup']['cleanup_pending']:sys.exit(1)
